

<!doctype html>
<html>
    <head><title>Currency </title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class="text">
            <h3>EUR (Euro)  -The European Union*,    1 Euro = Rs 84.323</h3>
            <h3>USD (United States Dollar) -The United States,  1 USD = Rs 72.04</h3>
            <h3>GBP (British Pound) -United Kingdom,  1 GBP = Rs 94.762</h3>
            <h3>PKR (Pakistani Rupee) -Pakistan  1 PKR = Rs 0.5832</h3>
            <h3>MXN (Mexican Peso) -Mexico,    1 MXN = Rs 3.842</h3>

        </div>
         <div class='calc-contain'>
             <form name="currency" method="post" action="currency.php">
                    <h1 align="center">Currency Converter</h1>
                    <input type="text" name="answer"  >
                    <br>
            
                    <input type="button" value=" 1 " onclick="currency.answer.value += '1'" />
                    <input type="button" value=" 2 " onclick="currency.answer.value += '2'" />
                    <input type="button" value=" 3 " onclick="currency.answer.value += '3'" />
                    <input type="submit" value="EUR"  name="submit1" />
                    <br/>
            
                    <input type="button" value=" 4 " onclick="currency.answer.value += '4'" />
                    <input type="button" value=" 5 " onclick="currency.answer.value += '5'" />
                    <input type="button" value=" 6 " onclick="currency.answer.value += '6'" />
                    <input type="submit" value="USD" name="submit2" />
                    <br>
          
                    <input type="button" value=" 7 " onclick="currency.answer.value += '7'" />
                    <input type="button" value=" 8 " onclick="currency.answer.value += '8'" />
                    <input type="button" value=" 9 " onclick="currency.answer.value += '9'" />
                    <input type="submit" value="GBP" name="submit3" />
                    <br>
        
                    <input type="button" value=" c " onclick="currency.answer.value = ''" />
                    <input type="button" value=" 0 " onclick="currency.answer.value += '0'" />
                    <input type="submit" value=" PKR" name="submit4"/>
                    <input type="submit" value="MXN" name="submit5" />
                    <br>
                 
             </form>
               <?php
            if(isset($_POST['submit1']))
            {
                $answer=$_POST['answer'];
                $result=$answer*84.323;
                echo " <center><h5>Rs $result<h5></center> ";
//                echo "$result";
            }
            else if(isset($_POST['submit2']))
            {
                $answer=$_POST['answer'];
                $result=$answer*72.04;
                echo "<center> <h5> Rs $result<h5></center> ";
//                echo "$result";
            }
            else if(isset($_POST['submit3']))
            {
                $answer=$_POST['answer'];
                $result=$answer*94.762;
                echo " <center><h5> Rs $result<h5></center> ";
//                echo "$result";
            }
            else if(isset($_POST['submit4']))
            {
                $answer=$_POST['answer'];
                $result=$answer*0.5832;
                echo "<center> <h5> Rs $result<h5></center> ";
//                echo "$result";
            }
            else if(isset($_POST['submit5']))
            {
                $answer=$_POST['answer'];
                $result=$answer*3.842;
                echo "<center> <h5> Rs $result<h5></center>";
//                echo "$result";
            }
        ?>
  
        </div>
    </body>
</html>
