 




<html>
    <head><title> Index </title>
         <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
<!--        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
        <link rel="stylesheet" href="css/min.css" type="text/css">
        <!--        meta data-->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1 ">
        
<!--        bootstrap file-->
            <link rel="stylesheet" href="css/bootstrap.min.css" >
        
<!--        external css-->
            <link rel="stylesheet" type="text/css" href="custom.css">

<!--        animation file-->
        <link href="bootstrap/animation.css" type="text/css" rel="stylesheet">
        <script src="bootstrap/animation.js"></script>
<!--        owl carousel file-->
        
        
        
<!--        font awesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <style>
    #para
         {
             border: 1px solid black;
             width: 40%;
             margin-left: 4%;
             margin-top: 4%;
             padding: 18px;
             border-radius: 10px;
             box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.24);
              background-color:#e4e4f7;
         }
         input[type=button]
         {
             background-color: #051470;
             color: white;
             padding: 4px;
             border: 1px solid #051470;
             margin: 2%;
         }
    </style>   
  
        
    </head>
    <body>
<div class="container">
    <div class="row gutter">
      
            <?php                            
                            include("db_conn.php");
                            $me="SELECT * FROM register";
                            $c=mysqli_query($conn, $me);
                            $n=mysqli_num_rows($c);
                            if($n==0)
                            {
                                echo "no data found";
                            }   
                            else
                            {
 
                                while($fe= ($c->fetch_assoc()))
                                {  
                                    $sl=$fe['sl_no'];
                                    $name=$fe['name']; 
                                    $phone=$fe['phone']; 
                                    $alt_phone=$fe['alt_phone']; 
                                    $email=$fe['email'] ; 
                                    $gender=$fe['gender'];
                                    $add1=$fe['add1'] ; 
                                    $add2=$fe['add2'];
                                    $city=$fe['city'] ; 
                                    $district=$fe['district'];
                                    $state=$fe['state'] ; 
                                    $country=$fe['country'];
                                    $pincode=$fe['pincode'] ;   
                           ?>
             
         <div class="card" id="para"> <p><?php echo"<b>$sl</b>"; ?>&nbsp;&nbsp;<b> Name:</b><?php echo"$name";?><br><b>Phone Number:</b><?php echo"$phone";?><br>
         <b>Alernative Number:</b><?php echo"$alt_phone";?><br><b>Email:</b><?php echo"$email";?><br>
             <b>Gender:</b><?php echo" $gender";?><br>
             <b>Address:</b><?php echo"$add1";?>,&nbsp;<?php echo"$add2";?>,<br><?php echo"$city,";?>&nbsp;<?php echo"$district,";?>&nbsp;<?php echo"$state,";?><br><?php echo"$country";?>,&nbsp;<?php echo"$pincode.";?><br><a href="register_update.php?val1=<?php echo "$sl"; ?>"><input type="button" id="update" value="UPDATE"></a><a href="register_delete.php?val1=<?php echo "$sl"; ?>"><input type="button" id="delete" value="DELETE"></a><a href="index.php"><input type="button" id="update" value="BACK"></a></p></div>
            <?php
            }}?>
      </div> 
        </div>
    </body>
</html>

