<?php
include("db_conn.php");
 $r=$_GET['val1'];
$s2="DELETE FROM `register` WHERE sl_no='$r'";
  $res=mysqli_query($conn, $s2);
            if($res)
              {
           echo "<script>alert('deleted.. '); window.location='register_view.php';</script>";
              }
            else
            {
           echo "<script>alert('retry...'); window.location='register_view.php';</script>";
            } 
?>