<?php
require_once("db_conn.php");      
if(isset($_POST['submit']))
    {
        $sln=$_POST['sl'];
        $name=$_POST['name'];
        $phone=$_POST['phone']; 
        $alt_phone=$_POST['alt_phone']; 
        $email=$_POST['email'];
        $add1=$_POST['add1']; 
        $add2=$_POST['add2'];
        $country=$_POST['country'];
        $state=$_POST['state'];  
        $district=$_POST['district'];
        $city=$_POST['city'];
        $pincode=$_POST['pincode']; 
        date_default_timezone_set('Asia/Kolkata');
        $entry_date=date("Y-m-d h:i:s");
         $up="UPDATE register SET name='$name',phone='$phone',alt_phone='$alt_phone', email='$email', add1='$add1', add2='$add2',city='$city', district='$district', state='$state',country='$country',pincode='$pincode' WHERE sl_no='$sln'";
            $res=mysqli_query($conn, $up);
            if($res)
              {
           echo "<script>alert('updated.. '); window.location='register_view.php';</script>";
              }
            else
            {
           echo "<script>alert('retry...'); window.location='register_view.php';</script>";
            } 
}
?>
<?php
include("db_conn.php");
 $r=$_GET['val1'];
$s1="SELECT * FROM register WHERE sl_no='$r'";
$c=mysqli_query($conn, $s1);
$n=mysqli_num_rows($c);
 if($n==0)
                            {
                                echo "no data found";
                            }   
                            else
                            {

                                $fe= ($c->fetch_assoc());
                                {  
//                                    $sl=$fe['sl_no'];
                                    $name=$fe['name']; 
                                    $phone=$fe['phone'];
                                    $alt_phone=$fe['alt_phone']; 
                                    $email=$fe['email'] ; 
                                    $gender=$fe['gender'];
                                    $add1=$fe['add1'] ; 
                                    $add2=$fe['add2'];
                                    $city=$fe['city'] ; 
                                    $district=$fe['district'];
                                    $state=$fe['state'] ; 
                                    $country=$fe['country'];
                                    $pincode=$fe['pincode'] ; 
                                }
                            }
                            
?>
<html>
    <head><title>Registration Form</title>
      <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
        
        
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>

        
   <style type="text/css">
		#basic_information2,#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
       input[type=date]
       {
           height: auto;
           width: auto;
       }
	</style> 
        
        
    </head>
    <body>
        
    <div class="page-wrapper p-t-180 p-b-100 font-robo">
        <div class="wrapper wrapper--w960" style="margin-top:-12%;">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Staff Info</h2>
                    <form action="register_update.php" method="POST" id="myform" enctype="multipart/form-data">
                         <fieldset id="basic_information" class="">
                         <div class="row row-space">
                             <input type="hidden" name="sl" value="<?php echo"$r";?>">
                               <div class="col-2">
                                 <div class="input-group">Name
                                  <input class="input--style-2" type="text" placeholder="Name" value="<?php echo"$name";?>"  name="name" id="name">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Contact Number
                                 <input class="input--style-2"  type="number" value="<?php echo"$phone";?>"  id="phone" placeholder="Phone Number"  name="phone">
                                </div>
                            </div>
                        </div>
                           <div class="row row-space">
                               <div class="col-2">
                                <div class="input-group">Alternative Phone Number
                                    <input class="input--style-2" type="number" value="<?php echo"$alt_phone";?>"  placeholder="Customer alternative phone number" name="alt_phone" id="alt_phone" maxlength="10">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Email
                                  <input class="input--style-2" type="text" value="<?php echo"$email";?>"  placeholder="Mail Id" id="email" name="email">
                                </div> 
                            </div>
                        </div>
                          
                                
                               <div class="divbtn">
                            <button type="button" class="btn btn--radius btn--submit next2" >Next</button>
                            </div>
                        </fieldset>
                       
                        
                    <fieldset id="address_information" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" value="<?php echo"$add1";?>"  placeholder="Address Line-1" name="add1">
                                    <span class="error"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" value="<?php echo"$add2";?>"  placeholder="Address Line-2" name="add2">
                                </div>
                            </div>
                        </div>
                    
                        <div class="row row-space">
                             <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" value="<?php echo"$city";?>"  placeholder="City" name="city">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="text" value="<?php echo"$pincode";?>"  placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1"   class="input--style-2">
                                        <option value="<?php echo"$country";?>"><?php echo"$country";?></option>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1"   class="input--style-2">
                                    <option value="<?php echo"$state";?>"><?php echo"$state";?></option>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1"  class="input--style-2">
                                   <option value="<?php echo"$state";?>"><?php echo"$state";?></option>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit" >Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit" >Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
 
    
    </body>
     <script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 digit");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            
            
            	$(".next2").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
							required: true,
                            emailRegex: true,
						},
                      
                       dob: {
							required: true,
						},
                        
                        address1: {
							required: true,
						},
                        address2: {
							required: true,
						},
                        
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
						email: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                       
                        address1: {
							required: "required",
						},
                        address2: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
					}
				});
				if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#basic_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
                
			});
            
            $('#previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information');
				}else if ($('#basic_information').is(":visible")){
					current_fs = $('#basic_information');
					next_fs = $('#address_information');
				}
				next_fs.show();
				current_fs.hide();
			});

			
		});
	</script>
    
   
</html>
