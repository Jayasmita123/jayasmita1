<html>
    <head><title> Index </title>
         <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/index.css" type="text/css">
    </head>
    <body>
        <div class="contain" >
            <div class="wrapper">
                <div class="content">
      <!-- card -->
                    <div class="card">
                        <div class="container-notify">
                            <a id="stretched-link" href="#" target="_blank"></a>
                        </div>
                        <a href="register_view.php">  
                            <div class="icon" id="icon"><i class="material-icons md-36 fa fa-address-card" aria-hidden="true"></i></div>
                            <p class="title">View Details</p>
                        </a>
                    </div>
                </div>
                <div class="content">
                    <div class="card">
                        <div class="container-notify">
                            <a id="stretched-link" href="#" target="_blank"></a>
                        </div>
                        <a href="register.php"> 
                            <div class="icon" id="icon"><i class="material-icons md-36 fa fa-user-o" aria-hidden="true"></i></div>
                            <p class="title">Add Registration</p>
                        </a> 
                    </div>
                </div>
            </div>
            <div class="wrapper2">
                <img src="images/bg-01.jpg" width="100%" height="96%">
            </div>
        </div>
    </body>
</html>
