<html>
<head><title>Downloads</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .row{
            margin-top:20%;
            margin-left: 30%;
        }
    </style>
    </head>
<body>
    <div class="row">
    <a href="Student.zip" download>
<!--  <img src="/images/myw3schoolsimage.jpg" alt="W3Schools" width="104" height="142">-->
                
    <button class="button button-primary button-pipaluk" >DOWNLOAD 1</button>  
</a>
    
      <a href="student_work.zip" download>
<!--  <img src="/images/myw3schoolsimage.jpg" alt="W3Schools" width="104" height="142">-->
    <button class="button button-primary button-pipaluk">DOWNLOAD 2</button>  
</a> 

        </div>
</body>

</html>