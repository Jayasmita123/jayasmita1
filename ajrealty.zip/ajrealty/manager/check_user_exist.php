<?php 
  include("../Db_Conn.php");
  if (isset($_POST['phone'])) {
  	$phone = $_POST['phone'];
  	$sql = "SELECT * FROM `ajrealty_customer` WHERE `customer_phone`='$phone'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "exist";	
  	}else{
  	  echo 'not_exist';
  	}
      
  }else if(isset($_POST['email'])) {
  	$email = $_POST['email'];
  	$sql = "SELECT * FROM `ajrealty_customer` WHERE `customer_email`='$email'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "exist";	
  	}else{
  	  echo 'not_exist';
  	}
  }

?>