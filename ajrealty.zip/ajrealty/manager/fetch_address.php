<?php
include('../Db_Conn.php');

$cus_id=$_POST['cus_id']; 
$data = array();

$query3 = "SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$cus_id'";
$sql1 = mysqli_query($conn,$query3);
if($sql1){
$row=mysqli_fetch_array($sql1);
    $address1 = $row['customer_address_line1'];
    $address2 = $row['customer_address_line2'];
    $street = $row['street'];
    $landmark = $row['customer_landmark'];
    $pincode = $row['customer_pincode'];
    $city = $row['customer_city'];
    $district = $row['customer_district'];
    $state = $row['customer_state'];
    $country = $row['customer_country'];
    
    $data[] = array("address1" => $address1,"address2"=>$address2,"street"=>$street,
                   "landmark"=>$landmark,"pincode"=>$pincode,"city"=>$city,
                   "district"=>$district,"state"=>$state,"country"=>$country);
}
echo json_encode($data);
?>