<?php
include('../Db_Conn.php');
$staff_id = $_POST['staff_id']; 

$sel = "SELECT `customer_id`,`customer_name`,`customer_phone`,`customer_city` FROM `ajrealty_customer` WHERE `assigned_manager`='$staff_id'";
$con = mysqli_query($conn,$sel);
if($con){
    while($row=mysqli_fetch_array($con)){
        
        $customer_id = $row['customer_id'];
        $customer_name = $row['customer_name'];
        $customer_phone = $row['customer_phone'];
        $customer_city = $row['customer_city'];
        
    $qry = "SELECT `property_id` FROM `ajrealty_survey` WHERE `customer_id`='$customer_id' AND `property_status`='0'";
    $res = mysqli_query($conn,$qry);
    $fetch = mysqli_fetch_array($res);
    $prop_id = $fetch['property_id'];
            
?>
<li>
    <a href="customer_view.php?customer_id=<?php echo $customer_id;?>&prop_id=<?php echo $prop_id;?>">
        Customer details: 
        <h5><?php echo $customer_name;?></h5>
        <h5><?php echo $customer_phone;?></h5>
        <h5><?php echo $customer_city;?></h5>
        <button class="button">View</button>
    </a>
</li>
<?php
    }
}
?>