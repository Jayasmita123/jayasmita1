<?php
include('../Db_Conn.php');

$property=$_POST['property'];

if($property == 'Residential'){
        ?>
        <option value="">Select </option>
        <option value="Duplex">Duplex</option>
        <option value="Pent House">Pent House</option>
        <option value="Independent House">Independent House</option>
        <option value="Raw House">Raw House</option>
        <option value="Villa">Villa</option>
        <option value="Flat">Flat</option>
<?php
    }else if($property == 'Commercial'){
?>
        <option value="">Select </option>
        <option value="Office">Office</option>
        <option value="Showroom">Showroom</option>
        <option value="Godown">Godown</option>
        <option value="Warehouse">Warehouse</option>
<?php
    }else if($property == 'Land'){
?>
        <option value="">Select </option>
        <option value="Agricultural">Agricultural</option>
        <option value="Residential">Residential</option>
        <option value="Commercial">Commercial</option>
        <option value="Farm">Farm</option>
        <option value="Industrial">Industrial</option>
        <option value="Mixed">Mixed</option>
        <option value="Approved">Approved</option>
        <option value="Unapproved">Unapproved</option>
<?php
    }

?>
