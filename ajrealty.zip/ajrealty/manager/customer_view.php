<?php
include("../Db_Conn.php");
error_reporting(0);
session_start();
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
 $customer_id = $_REQUEST['customer_id'];
 $property_id = $_REQUEST['prop_id'];
    if(isset($_REQUEST['notify_id'])){
        $notify_id = $_REQUEST['notify_id'];
    }
    
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $staff_name = $row['staff_name'];
}
?>
<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Page-->
    <title>AJREALTY</title>
    <link rel="stylesheet" href="../css/form.css">
        
        <!--popup-->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    <style>
table {
    border-collapse: collapse;
    width:100%;
    margin-top: 10px;
}

td, th {
    border: 1px solid #ccc;
    padding: 3px;
    font-size:16px;
}
td:nth-child(1),td:nth-child(3),td:nth-child(5){
    width: 200px;
     font-weight:bold;
     font-size:16px;
}
td:nth-child(2),td:nth-child(4),td:nth-child(6){
    width: 300px;
     font-size:14px;
}
h4{
    color:#b224ef;
    text-align:left;
}
.loginbtn
        {
            margin-top: 10px;
            padding: 12px 20px;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
            background-color: powderblue;
            background-image: -webkit-gradient(linear, left top, left bottom, from(#07A8C3), to(#6EE4E8));
            background-image: -moz-linear-gradient(top left 90deg, #07A8C3 0%, #6EE4E8 100%);
            background-image: linear-gradient(top left 90deg, #07A8C3 0%, #6EE4E8 100%);
            border-radius: 30px;
            border: 1px solid #07A8C3;
            cursor: pointer;
            
        }
        .loginbtn:hover
        {
            background-image: -webkit-gradient(linear, left top, left bottom, from(#b6e2ff), to(#6ec2e8));
            background-image: -moz-linear-gradient(top left 90deg, #b6e2ff 0%, #6ec2e8 100%);
            background-image: linear-gradient(top left 90deg, #b6e2ff 0%, #6ec2e8 100%);
        }   

	@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	#table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	#table, #thead, #tbody,#th, #td, #tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	#thead #tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	#tr { border: 1px solid #ccc; }
	
	#td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	#td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);
		color: #000;
		font-weight: bold;
	}
}
.container {
  width: 100%;
  max-width: 1400px;
  text-align: left;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 auto; /* center hack */
  padding: 20px;
}
/*popup*/
        
.popup{
  position: fixed;
	top: 100%;
  width: 100%;
  height: 100%;
  z-index: 10001;
}
    
.main-btn-circle{
	position: relative;
	margin: 0;
	font-family: 'Roboto', sans-serif;
	color: #FFF;
	background-color: #3c5973;
	text-transform: uppercase;
	font-size: 25px;
	letter-spacing: 1px;	
	outline: none;
	cursor: pointer;
	z-index: 100;
}
    
.main-btn-circle{
	height: 40px;
	width: 40px;
	-webkit-border-radius: 50%;
	border-radius: 100%;
	line-height: 40px;
  -webkit-transition: box-shadow 0.3s;
  -o-transition: box-shadow 0.3s;
  transition: box-shadow 0.3s;
}
    
.main-btn-circle:hover{   
  -webkit-box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
  -moz-box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
  box-shadow: inset 2px 1px 0px 20px rgba(255, 255, 240, 0.2);
}
    
.popup.active{
  top:0;
  background-color: rgba(227,235,236,0.5);
  transition: background-color .2s ,opacity .2s;
}
    
.popup .main-btn-rect{
  padding: 10px 100px;
}
    
.popup .popup-content{
  position: absolute;
  top: 50%;
  left: 50%;
  height: auto;
  min-width: 350px;
  margin-top: 150px;
  padding: 25px;
  background-color: #FFF;
  color: #070000;
  -webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
  -ms-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
  -webkit-transform: translateX(-50%) translateY(-50%);
  -moz-transform: translateX(-50%) translateY(-50%);
  -o-transform: translateX(-50%) translateY(-50%);
  transition: margin .6s;
  -webkit-transition: margin .6s;
  -moz-transition: margin .6s;
  -o-transition: margin .6s;
}
.popup.active .popup-content{
  margin-top: 0px;
}
.popup-content h6{
  display: table;
  font-size: 16px;
  text-align: center;
  margin: 10px auto;
  font-family: 'Roboto',sans-serif;
  text-transform: uppercase;
  font-weight: 100;  
}
.popup .fade-out{
  position: absolute;
  top: -20px;
  right: -20px;
  text-align: center;
  font-size: 15px;
}
.popup-btn{
	position: absolute!important;
	top: 55%;
	left: 50%;
	transform: translate(-50%,-50%);
}
@media only screen and (max-width: 768px){
  .main-btn-rect {padding: 7px 60px; font-size: 14px;}
  .popup-btn{padding: 7px 60px; font-size: 14px;}
}
        textarea{
            border: 5px solid #eee;
            margin-bottom: 5px;
        }
        ul{
            margin-left: 30px;
            padding: 5px;
        }
    </style>
    </head>
<body>
     <?php
        include("nav.php");
        ?>
    <section>
        
    	<div class="container">
            <center>
                <button class="btn btn--radius btn--submit" data-popup="popup-reg" id="popup-btn">Add Remarks</button>
            <button class="btn btn--radius btn--submit" onclick="window.location='assigned_project_list.php'">Back</button>
            </center>
        <?php
            $sql="SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
    
            $result = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($result);
        
            $name=$row['customer_name'];
            $phone=$row['customer_phone'];
            $alt_phone=$row['alternative_phone'];
            $res_phone=$row['residence_phone'];
            $off_phone=$row['office_phone'];
            
            $gender=$row['gender'];
            $occupation=$row['customer_occupation'];
            $email=$row['customer_email'];
            $address1 = $row['customer_address_line1'];
            $address2 = $row['customer_address_line2'];
            $street = $row['street'];
            $landmark = $row['customer_landmark'];
            $pincode = $row['customer_pincode'];
            $city = $row['customer_city'];
            $district = $row['customer_district'];
            $state = $row['customer_state'];
            $country = $row['customer_country'];
            $manager_name = $row['manager_name'];
            $manager_id = $row['manager_id'];
            $entry_date = $row['entry_date'];
            
            $qry="SELECT *,`ajrealty_survey`.`entry_date` as entry_date FROM `ajrealty_survey` JOIN `ajrealty_survey_table2` WHERE `ajrealty_survey`.`customer_id`='$customer_id' AND `ajrealty_survey`.`property_id`='$property_id' AND `ajrealty_survey`.`property_id`=`ajrealty_survey_table2`.`property_id`";
    
            $res = mysqli_query($conn,$qry);
            $fetch = mysqli_fetch_array($res);
    
    $remark_date = date("Y-m-d H:i:s");
    $entry_date = $fetch['entry_date'];
    $property = $fetch['property'];
    $property_type = $fetch['property_type'];
    $type = $fetch['type'];
    $address_line1 = $fetch['address1'];
    $address_line2 = $fetch['address2'];
    $landmark1 = $fetch['landmark'];
    $pincode1 = $fetch['pincode'];
    $city1 = $fetch['city'];
    $state1 = $fetch['state'];
    $district1 = $fetch['district'];
    $country1 = $fetch['country'];
    $street1 = $fetch['street'];
    $land_area = $fetch['land_area'];
    $land_sqft = $fetch['land_sqft_rate'];
    $rate_sqft = $fetch['sqft_rate'];
    $remarks = $fetch['remarks'];
    $price = $fetch['price'];
    $deposit = $fetch['deposit'];
    $maintenance = $fetch['maintenance'];
    $exclusive_from = $fetch['exclusive_list_from'];
    $exclusive_to = $fetch['exclusive_list_to'];
    $water_facility = $fetch['water_facility'];
    $power_supply = $fetch['power_supply'];
    $amenities = $fetch['amenties'];
    $generator = $fetch['generator'];
    $elevators = $fetch['elevators'];
    $furnished = $fetch['furnished'];
    $car_park = $fetch['car_park'];
    $flooring = $fetch['flooring'];
    $bathroom = $fetch['bathrooms'];
    $bedroom = $fetch['bedrooms'];
    $room = $fetch['rooms'];
    $num_floors = $fetch['floors_num'];
    $building_age = $fetch['age_of_building'];
    $built_area = $fetch['built_area'];
    $tot_flats = $fetch['total_flats'];
    $building_name = $fetch['building_name'];
    $architect_name = $fetch['architect_name'];
    $builders_name = $fetch['builders_name'];
    $garden = $fetch['garden/terrace'];
    $servant_qtrs = $fetch['servant_qtrs'];
    $lease_type = $fetch['lease_type'];
    $lease_period = $fetch['lease_period'];
    
    $insp_name = $fetch['inspection_person_name'];
    $insp_phone = $fetch['inspection_person_phone'];
    $insp_email = $fetch['inspection_person_email'];
    $web_host = $fetch['website_hosting'];
    $keys_collected = $fetch['keys_collected'];
    $hrr_board = $fetch['hrr_board'];
    $listed = $fetch['listed'];
    $inspected = $fetch['inspected'];
    $source = $fetch['source'];
    
        ?>

    <!-- 2nd table-->
    <table>
    <tr> 
        <th colspan="4"><h4>i. Basic Details</h4></th>
    </tr>
    <tr>
        <td>Customer Name: </td>
        <td><?php echo $name;?></td>
        <td>Email Id: </td>
        <td><?php echo $email;?></td>
    </tr>

    <tr>
        <td>Contact Number</td>
        <td><?php echo  $phone;?></td>
        <td>Alternate Contact Number</td>
        <td><?php echo  $alt_phone;?></td>
    </tr>
    
    <tr>
        <td>Residence Number</td>
        <td><?php echo  $res_phone;?></td>
        <td>Office Number</td>
        <td><?php echo  $off_phone;?></td>
    </tr>
    
    <tr>
        <td>Occupation</td>
        <td><?php echo $occupation;?></td>
        <td>Gender</td>
        <td><?php echo $gender;?></td>
    </tr>
        
    </table>
    <!--3rd table-->
    <table>
        <tr>
            <th colspan="6"><h4>ii. Customer Address</h4></th>
        </tr>
        <tr>
            <td>Full Address: </td>
            <td colspan="5"><?php echo $address1." ".$address2.", ".$street;?></td>
        </tr>
        <tr>
            <td>Landmark: </td>
            <td><?php echo  $landmark;?></td>
            <td>City: </td>
            <td><?php echo  $city;?></td>
            <td>District: </td>
            <td><?php echo  $district;?></td>
        </tr>
        <tr>
            <td>State: </td>
            <td><?php echo  $state;?></td>
            <td>Country: </td>
            <td><?php echo  $country;?></td>
            <td>Pincode: </td>
            <td><?php echo  $pincode;?></td>
        </tr>
    </table>
            <!--4th table-->
    <table>
        <tr>
            <th colspan="6"><h4>iii. Property Details</h4></th>
        </tr>
        <tr>
            <td>Property </td>
            <td><?php echo $property;?></td>
            <td>Property type: </td>
            <td><?php echo $property_type;?></td>
            <td>Property mode: </td>
            <td><?php echo $type;?></td>
        </tr>
            <?php
            if($property == 'Land'){
                ?>
            <tr>
                <td>Built area: </td>
                <td colspan="2"><?php echo  $built_area;?></td>
                <td>Rate per sqft: </td>
                <td colspan="2"><?php echo  $rate_sqft;?></td>
            </tr>
        <?php
            }else{
            ?>
        <tr>
            <td>Name of building: </td>
            <td><?php echo $building_name;?></td>
            <td>Builder's name: </td>
            <td><?php echo $builders_name;?></td>
            <td>Architecture name: </td>
            <td><?php echo $architect_name;?></td>
        </tr>
        <tr>
            <td>Age of building: </td>
            <td><?php echo $building_age;?></td>
            <td>Car parking: </td>
            <td><?php echo $car_park;?></td>
            <td>Elevators: </td>
            <td><?php echo  $elevators;?></td>
        </tr>
        <tr>
            <td>Flooring: </td>
            <td><?php echo  $flooring;?></td>
            <td>Furnished: </td>
            <td><?php echo  $furnished;?></td>
            <td>Garden/Terrace: </td>
            <td><?php echo  $garden;?></td>
        </tr>
        <tr>
            <?php
                if($room == ''){
                    echo '<td>Bedrooms: </td>
                    <td><?php echo  $bedroom;?></td>';
                }else{
                    echo '<td>Rooms: </td>
                    <td><?php echo  $room;?></td>';
                }
            ?>
            
            <td>Bathroom: </td>
            <td><?php echo $bathroom;?></td>
            <td>Number of floors: </td>
            <td><?php echo $num_floors;?></td>
        </tr>
        <tr>
            <td>Generator: </td>
            <td><?php echo $generator;?></td>
            <td>Power supply: </td>
            <td><?php echo $power_supply;?></td>
            <td>Water facility: </td>
            <td><?php echo $water_facility;?></td>
        </tr>
        <?php
            }
            if($property_type == 'Flat'){
                ?>
                <tr><td>Total number of flats: </td>
                <td><?php echo  $tot_flats;?></td>
                <td>Amenities: </td>
                <td colspan="3"><?php echo  $amenities;?></td>
                </tr>
        <?php
            }
            ?>
        <tr>
            <td>Inspected: </td>
            <td><?php echo $inspected;?></td>
            <td>Listed: </td>
            <td><?php echo $listed;?></td>
            <td>HRR Board: </td>
            <td><?php echo $hrr_board;?></td>
        </tr>
        <tr>
            <td>Website hosting: </td>
            <td><?php echo $web_host;?></td>
            <td>Keys collected: </td>
            <td><?php echo $keys_collected;?></td>
            <td>Servant qtrs: </td>
            <td><?php echo $servant_qtrs;?></td>
        </tr>
        <tr>
            <?php
            if($type == 'Lease'){
                echo '
                <td>Lease type: </td>
            <td><?php echo $lease_type;?></td>
            <td>Lease period: </td>
            <td><?php echo $lease_period;?></td>
            <td>Source: </td>
            <td><?php echo $source;?></td>';
            }else{
            ?>
            <td>Source: </td>
            <td><?php echo $source;?></td>
            <?php
            }
            ?>
        </tr>
        <tr>
            <td>Exclusive listing from-to: </td>
            <td><?php echo $exclusive_from." - ".$exclusive_to;?></td>
            <td>Deposit: </td>
            <td><?php echo  $deposit;?></td>
            <td>Maintenance: </td>
            <td><?php echo $maintenance;?></td>
        </tr>
        <tr>
            <td>Price: </td>
            <td><?php echo $price;?></td>
            <td>Remarks: </td>
            <td colspan="3"><?php echo $remarks;?></td>
        </tr>
    </table>
    <!--5th table-->
    <table>
        <tr>
            <th colspan="6"><h4>iv. Property Address</h4></th>
        </tr>
        <tr>
            <td>Full Address: </td>
            <td colspan="5"><?php echo $address_line1." ".$address_line2.", ".$street1;?></td>
        </tr>
        <tr>
            <td>Landmark: </td>
            <td><?php echo $landmark1;?></td>
            <td>City: </td>
            <td><?php echo $city1;?></td>
            <td>District: </td>
            <td><?php echo $district1;?></td>
        </tr>
        <tr>
            <td>State: </td>
            <td><?php echo $state1;?></td>
            <td>Country: </td>
            <td><?php echo $country1;?></td>
            <td>Pincode: </td>
            <td><?php echo $pincode1;?></td>
        </tr>
    </table>
            <!--6th table-->
        <table>
        <tr>
            <th colspan="6"><h4>v. All Remarks</h4></th>
        </tr>
        <tr>
            <td colspan="6">
            <ul>
            <?php
                $remrk="SELECT * FROM `ajrealty_remarks` WHERE `customer_id`='$customer_id' AND `property_id`='$property_id' ORDER BY `Sl.No` DESC";

                $remrkcon = mysqli_query($conn,$remrk);
                while($display = mysqli_fetch_array($remrkcon)){
                    echo '
                    <li>By '.$display["staff_name"].' ('.$display["role"].') on '.$display["entry_date"].' - '.$display["remarks"].'</li>';
            }
            ?>
                    </ul>
            </td>
        </tr>
    </table>
        </div>
    </section>
    
    <!-- Modal content -->
  <div id="popup-reg" class="popup">
  <div class="popup-content">
    <div class="card-body">
        <h6 class="title">Brief Description of the proprty/Additional Information/Realtor's Remarks</h6>
                <form method="POST" action="customer_view.php" id="myform">
                        <input type="hidden" name="notify_id" id="notify_id" value="<?php echo $notify_id;?>">
                        <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                        <input type="hidden" name="manager_id" value="<?php echo $staff_id;?>">
                        <input type="hidden" name="manager_name" value="<?php echo $staff_name;?>">
                        <input type="hidden" name="property_id" value="<?php echo $property_id;?>">
                           
                        <div class="input-group">
                            <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks" id="remarks" required></textarea>
                    </div>
                        <div class="divbtn">
                            <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit">Submit</button>
                        </div>
                 </form>
            </div>
            <span class="fade-out main-btn-circle">╳</span>
        </div>
    </div>
           <?php
           include("footer.php");
           ?>
<?php

    if(isset($_POST['submit'])){
        $remarks = $_POST['remarks'];
        $entry_date = date("Y-m-d H:i:s");
        $customer_id = $_POST['customer_id'];
        $manager_id = $_POST['manager_id'];
        $manager_name = $_POST['manager_name'];
        $property_id = $_POST['property_id'];
        
        $sql = "INSERT INTO `ajrealty_remarks`(`customer_id`, `property_id`,`role`, `staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$customer_id','$property_id','manager','$manager_id','$manager_name','$remarks','$entry_date')";
        $con = mysqli_query($conn,$sql);
        if($con){
            $qry = mysqli_query($conn,"INSERT INTO `notification_status`(`customer_id`, `property_id`, `message`, `role`, `status`,`customer`, `entry_date`,`remark_from`) VALUES  ('$customer_id','$property_id','manager wrote remarks for assigned property','propriator',0,'old','$entry_date','manager')");
            if($qry){
                
                $upd_notify = mysqli_query($conn,"UPDATE `notification_status` SET `status`='1' WHERE `Sl.No`='$notify_id'");
                
                echo "<script>alert('Successfully inserted');window.location='index.php';</script>";
            }else{
                echo "<script>alert('failed');window.location='customer_view.php';</script>";
            }
        }
    }
?> 
<script>
    
$(document).ready(function(){
  $('#popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','.5').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 100);
      });
 });
});
    </script>
    
    <script>
$(document).ready(function(){
  $('#close').click(function(){
        
          $('.popup').removeClass('active');
          
      });
 });
    </script>
    </body>
</html>