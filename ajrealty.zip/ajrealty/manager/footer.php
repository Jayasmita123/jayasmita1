<!DOCTYPE html>
<html>
<head>
<style>
html {
    position: relative;
    min-height: 100%;
}
footer {
    position: absolute;
    left: 0;
    bottom: 0;
    height: 55px;
    width: 100%;
}
footer{background:#3b5998;text-align:center;}
footer p{color:#fff;display:inline-block; margin-top:1%;}
footer a{color:#fff;text-decoration:none;display:inline-block; margin-top:1%;}
footer a:hover { color : #4a93ed; }

@media only screen and (max-width : 769px) {
  footer a{font-size:22px;}
}
    </style>
  </head>
  <body>

    <footer>
        <p>
        <span>&copy;&nbsp;</span> AJ Realty<span class="copyright-year"></span>, Designed &amp; Developed by - <a href="https://www.brainlift.in/" target="_blank">BRAINLIFT TECHNOLOGIES PVT.LTD</a>  
        </p>
    </footer>
    <script>
      function footerAlign() {
  $('footer').css('height', '55px');
  var footerHeight = $('footer').outerHeight();
  $('body').css('padding-bottom', footerHeight);
  $('footer').css('height', footerHeight);
}


$(document).ready(function(){
  footerAlign();
});

$( window ).resize(function() {
  footerAlign();
});
    </script>
  </body>
</html>