<?php
include("../Db_Conn.php");
session_start();
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Page-->
    <title>AJREALTY</title>
    <style>
table {
    border-collapse: collapse;
    width:100%;
    margin-top: 10px;
}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #7791c7; 
	}

th { 
	background: #3b5998; 
	color: white; 
	font-weight: bold;
	text-align:left;
	align-items:center;
	height:40px;
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	font-size: 16px;
	width:auto;
	line-height:1.2;
	}
	td{
	    text-align: left; 
	}

h4{
    color:#b224ef;
    text-align:left;
}
  

	@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	#table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	#table, #thead, #tbody,#th, #td, #tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	#thead #tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	#tr { border: 1px solid #ccc; }
	
	#td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	#td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);
		color: #000;
		font-weight: bold;
	}
}
.container {
  width: 100%;
  max-width: 1400px;
  text-align: left;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 auto; /* center hack */
  padding: 20px;
}

    </style>
</head>
<body>
	<?php include("nav.php"); ?>
    
    <div class="container">
    <center><h1>Assigned Property/Customer</h1></center>
        <?php
        $selqry = "SELECT * FROM `assigned_manager` WHERE `assigned_staff_id`='$staff_id'";
            $conqry = mysqli_query($conn,$selqry);
            if(mysqli_num_rows($conqry) > 0){
                $i = 1;
        ?>
<table id="property">
  <tr>
    <th>Sl.No</th>
    <th>Customer name</th>
    <th>Contact number</th>
    <th>Property</th>
    <th>Property mode</th>
    <th>Property type</th>
    <th>Last visit</th>
    <th>Property_status</th>
    <th>View</th>
  </tr>
   <?php
        while($display = mysqli_fetch_array($conqry)){
        $cid = $display['customer_id'];
        $pid = $display['property_id'];
                
    $sel = "SELECT customer_name,customer_phone FROM `ajrealty_customer` WHERE `customer_id`='$cid'";
    $con = mysqli_query($conn,$sel);
    
    $fetch = mysqli_fetch_array($con);
    $name = $fetch['customer_name'];
    $contact = $fetch['customer_phone'];
        
    $sel2 = "SELECT property,type,property_type,property_status FROM `ajrealty_survey` WHERE property_id='$pid'";
    $con2 = mysqli_query($conn,$sel2);
    $fetch2 = mysqli_fetch_array($con2);
            
        $property= $fetch2['property'];
        $type = $fetch2['type'];
        $property_type = $fetch2['property_type'];
        $status= $fetch2['property_status'];

  $sel3 = "SELECT `entry_date` FROM `ajrealty_remarks` WHERE customer_id='$cid' AND property_id='$pid' ORDER BY `Sl.No` DESC";
    $con3 = mysqli_query($conn, $sel3);
    $fetch3 = mysqli_fetch_array($con3);
    $entry_date= $fetch3['entry_date'];


    ?>
  <tr>
  	<td hidden><?php echo $cid ?></td>
    <td hidden><?php echo $pid ?></td>
    <td><?php echo $i; ?></td>
    <td><?php echo $name; ?></td>
    <td><?php echo $contact; ?></td>
    <td><?php echo $property; ?></td>
    <td><?php echo $type; ?></td>
    <td><?php echo $property_type; ?></td>
    <td><?php echo $entry_date; ?></td>
    <?php if($status=='0'){
     echo "<td style='color:green;'>On Process</td>
     <td><a href='customer_view.php?customer_id=<?php echo $cid;?>&prop_id=<?php echo $pid;?>'><button>View</button></a></td>";
    } 
    else{
     echo "<td style='color:red;'>Sold</td>
     <td></td>";
    } 
    ?>
      
  </tr>
  <?php
        $i++;
        
}
                
?>
</table>
        <?php
            }
        ?>
        </div>
      <?php
            include("footer.php");
            ?>  
<!--onclick table go to next page to update-->
 <!--   <script>
        
        var table = document.getElementById('property');
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {
                         var cid = this.cells[0].innerHTML;
                         var pid = this.cells[1].innerHTML;
                        
                         window.location = 'customer_view.php?customer_id='+cid+'&prop_id='+pid;
                             
                    };
                }

</script>-->
</body>
</html>