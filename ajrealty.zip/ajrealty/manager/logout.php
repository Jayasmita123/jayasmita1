<?php
		
        session_start();
		unset($_SESSION['staff_id']);   // unset $_SESSION variable for the run-time
        session_destroy();   // destroy session data in storage
        echo "<script type='text/javascript'>alert('You have successfully logout');
        location.href ='../login.php';</script>";
?>
