<?php
include("../Db_Conn.php");
session_start();
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $manager_name = $row['staff_name'];
    
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Page-->
    <title>AJREALTY</title>
    <link href="../css/form.css" rel="stylesheet">
    
<style>
    
* {
  margin: 0;
  padding: 0;
}

html, body {
  font-family: Arial, Helvetica, sans-serif;
  font-weight: normal;
  font-size: 12px;
  color: #000000;
  line-height: 1.5em;
  background-color: #eeeeee;
}

h1 {
  margin-bottom: 20px;
}

h2 {
  width: 100%;
  border: 1px solid #ddd;
  background-color: #eeeeee;
  margin: 0 0 10px 0;
  padding: 10px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}

h3 {
  margin: 10px 0;
}

h4 {
  font-size: 16px;
}

.wrapper {
  width: 100%;
  text-align: center; /* center hack */
}

.container {
  width: 100%;
  max-width: 1100px;
  text-align: left;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 auto; /* center hack */
  padding: 20px;
}

.header {
  display: block;
  width: 100%;
  height: 80px;
  line-height: 40px;
  text-align: center;
  border: 1px solid #dddddd;
  background-color: #ffffff;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 0 20px 0;
  padding: 20px;
}

.main {
  word-wrap: break-word;
  border: 1px solid #dddddd;
  background-color: #ffffff;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  padding: 20px;
}

.two-column {
  float: none;
  width: 500px;
  overflow: hidden;
}

.side-a {
  float: left;
  position: relative;
  width: 500px;
  word-wrap: break-word;
  border: 1px solid #dddddd;
  background-color: #ffffff;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin-right: 20px;
  padding: 20px;
}

.main-menu ul {
  list-style: none;
}

.main-menu li {
  margin-bottom: 10px;
}

.main-menu li:last-child {
  margin-bottom: 0;
}

.main-menu a:link,
.main-menu a:visited {
  display: block;
  font-weight: bold;
  color: #000000;
  text-decoration: none;
  background-color: #dddddd;
  padding: 8px 10px;
}

.main-menu:hover {
  color: #ffffff;
  background-color: #cccccc;
}

/* media queries */
@media only screen and (max-width: 767px) {
  .container {
    width: 100%;
    max-width: 767px;
  }
  
  .side-a {
    float: none;
    position: static;
    width: 100%;
    margin-right: 0;
    margin-bottom: 20px;
  }
}

.col-sm-6 {
  background: #fff;
}

.other {
  background: #fff;
}
    button{
        margin-bottom: 10px;
    }

    </style>
</head>
    <body>
        <?php
        include("nav.php");
        ?>
    <div class="container">
        <center><button class="btn btn--radius btn--submit" onclick="window.location='add_new_customer.php'">Add New Customer</button></center>
  <div class="row">
      <span id="staff_id" hidden><?php echo $staff_id;?></span>
      <?php
            $sel = "SELECT `customer_id`,`customer`,`property_id`,`Sl.No` FROM `notification_status` WHERE `assigned_staff_id`='$staff_id' AND `role`='manager' AND `status`='0' AND `remark_from`='receptionist' ORDER BY `Sl.No` DESC";
            $con = mysqli_query($conn,$sel);
      $res1 = mysqli_num_rows($con);
            if($res1 > 0){
                ?>
        <div id="side-a" class="side-a">
         <h2>Notification</h2>
       <nav class="main-menu">
        <ul>
            <?php            
                while($row=mysqli_fetch_array($con)){
                    $customer_id = $row['customer_id'];
                    $customer_type = $row['customer'];
                    $property_id = $row['property_id'];
                    $notify_id = $row['Sl.No'];

                    $qry1 = "SELECT `customer_name`,`customer_phone` FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
                    $res1 = mysqli_query($conn,$qry1);
                    $fetch1 = mysqli_fetch_array($res1);
                    $customer_name = $fetch1['customer_name'];
                    $customer_phone = $fetch1['customer_phone'];

                        if($customer_type == "new"){
                ?>
                <li>
                    <a href="survey_form.php?customer_id=<?php echo $customer_id;?>&notify_id=<?php echo $notify_id;?>">New customer is arrived<br>
                        Customer details: 
                        <h5><?php echo $customer_name;?></h5>
                        <h5><?php echo $customer_phone;?></h5>
                        <button class="button">Attend</button>
                    </a>
                </li>
                <?php
                    }else{

                    $qry = "SELECT `property_id` FROM `ajrealty_survey` WHERE `customer_id`='$customer_id'";
                    $res = mysqli_query($conn,$qry);
                    $fetch = mysqli_fetch_array($res);
                    $prop_id = $fetch['property_id'];
                ?>
                <li>
                    <a href="customer_view.php?customer_id=<?php echo $customer_id;?>&prop_id=<?php echo $prop_id;?>&notify_id=<?php echo $notify_id;?>">Old customer walkin
                    <br>Customer details: 
                        <h5><?php echo $customer_name;?></h5>
                        <h5><?php echo $customer_phone;?></h5>
                        <button class="button">Attend</button>
                    </a>
                </li>
<?php
        }
    }
?>
        </ul>
      </nav><!-- /main-menu -->
    </div>
      <?php
            }
      
      $sel1 = "SELECT `customer_id`,`property_id`,`Sl.No` FROM `notification_status` WHERE `assigned_staff_id`='$staff_id' AND `role`='manager' AND `status`='0' AND `remark_from`='propriator' ORDER BY `Sl.No` DESC";
            $con1 = mysqli_query($conn,$sel1);
      $res = mysqli_num_rows($con1);
            if($res > 0){
        ?>
    <div id="main" class="main  two-column">
      <h2>Assigned Projects</h2>
        <nav id="main-menu" class="main-menu" role="navigation">
        <ul>
            <?php
            
                while($row=mysqli_fetch_array($con1)){

                    $customer_id = $row['customer_id'];
                    $prop_id = $row['property_id'];
                    $notify_id = $row['Sl.No'];

                $qry1 = "SELECT * FROM `ajrealty_survey` WHERE `property_id`='$prop_id' AND `property_status`='0'";
                $res1 = mysqli_query($conn,$qry1);
                    if(mysqli_num_rows($res1) > 0){
                
                    $qry = "SELECT `customer_name`,`customer_phone`,`customer_city` FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
                    $res = mysqli_query($conn,$qry);
                    
                     $fetch = mysqli_fetch_array($res);
                        $customer_name = $fetch['customer_name'];
                        $customer_phone = $fetch['customer_phone'];
                        $customer_city = $fetch['customer_city'];

            ?>
            <li>
                <a href="customer_view.php?customer_id=<?php echo $customer_id;?>&prop_id=<?php echo $prop_id;?>&notify_id=<?php echo $notify_id;?>">
                    Customer details: 
                    <h5><?php echo $customer_name;?></h5>
                    <h5><?php echo $customer_phone;?></h5>
                    <h5><?php echo $customer_city;?></h5>
                    <button class="button">View</button>
                </a>
            </li>
<?php
    }
}
?>
        </ul>
      </nav>
    </div>
      <?php
            }
      
      ?>
  </div>
</div>

        <?php
            include("footer.php");
            ?>
        <!-- $sel = "SELECT * FROM `assigned_manager` WHERE `assigned_staff_id`='$staff_id'";
            $con = mysqli_query($conn,$sel);
            if(mysqli_num_rows($con) > 0){
        ?>
    <div id="main" class="main  two-column">
      <h2>Assigned Projects</h2>
        <nav id="main-menu" class="main-menu" role="navigation">
        <ul>
            ?php
            
                while($row=mysqli_fetch_array($con)){

                    $customer_id = $row['customer_id'];
                    $prop_id = $row['property_id'];
                    
                $qry1 = "SELECT * FROM `ajrealty_survey` WHERE `customer_id`='$customer_id' AND `property_id`='$prop_id' AND `property_status`='0'";
                $res1 = mysqli_query($conn,$qry1);
                    if(mysqli_num_rows($res1) > 0){
                        
                        $qry = "SELECT `customer_name`,`customer_phone`,`customer_city` FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
                    $res = mysqli_query($conn,$qry);
                     $fetch = mysqli_fetch_array($res);
                        $customer_name = $fetch['customer_name'];
                        $customer_phone = $fetch['customer_phone'];
                        $customer_city = $fetch['customer_city'];-->
<!--<script>  
$(document).ready(function(){

    var staff_id = document.getElementById('staff_id').innerHTML;
    var dataString = 'staff_id='+ staff_id;
    
        $.ajax({
            type: "POST",
            url: "fetch_notification.php",
            cache: false,
            data: dataString,
            success: function (response) {
                document.getElementById("notify_list").innerHTML=response;
              }
           });    
});   
 </script>

<script>  
$(document).ready(function(){

    var staff_id = document.getElementById('staff_id').innerHTML;
    var dataString = 'staff_id='+ staff_id;
    
        $.ajax({
            type: "POST",
            url: "fetch_assign_project.php",
            cache: false,
            data: dataString,
            success: function (response) {
                document.getElementById("assgn_prj").innerHTML=response;
              }
           });    
});   
 </script>-->
    </body>
</html>