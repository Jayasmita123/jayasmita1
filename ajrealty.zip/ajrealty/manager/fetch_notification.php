<?php
include('../Db_Conn.php');
$staff_id = $_POST['staff_id']; 

$sel = "SELECT `customer_id`,`customer`,`property_id`,message,`Sl.No` FROM `notification_status` WHERE `assigned_staff_id`='$staff_id' AND `role`='manager' AND `status`='0' ORDER BY `Sl.No` DESC";
$con = mysqli_query($conn,$sel);
if($con){
    while($row=mysqli_fetch_array($con)){
        $customer_id = $row['customer_id'];
        $customer_type = $row['customer'];
        $property_id = $row['property_id'];
        $notify_id = $row['Sl.No'];
        
    $qry1 = "SELECT `customer_name`,`customer_phone` FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
    $res1 = mysqli_query($conn,$qry1);
    $fetch1 = mysqli_fetch_array($res1);
    $customer_name = $fetch1['customer_name'];
    $customer_phone = $fetch1['customer_phone'];
            
        if($customer_type == "new"){
?>
<li>
    <a href="survey_form.php?customer_id=<?php echo $customer_id;?>&notify_id=<?php echo $notify_id;?>">New customer is arrived<br>
        Customer details: 
        <h5><?php echo $customer_name;?></h5>
        <h5><?php echo $customer_phone;?></h5>
        <button class="button">Attend</button>
    </a>
</li>
<?php
    }else{
        
    $qry = "SELECT `property_id` FROM `ajrealty_survey` WHERE `customer_id`='$customer_id'";
    $res = mysqli_query($conn,$qry);
    $fetch = mysqli_fetch_array($res);
    $prop_id = $fetch['property_id'];
?>
<li>
    <a href="customer_view.php?customer_id=<?php echo $customer_id;?>&prop_id=<?php echo $prop_id;?>&notify_id=<?php echo $notify_id;?>">Old customer walkin
    <br>Customer details: 
        <h5><?php echo $customer_name;?></h5>
        <h5><?php echo $customer_phone;?></h5>
        <button class="button">Attend</button>
    </a>
</li>
<?php
        }
    }
}
?>