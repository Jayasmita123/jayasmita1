<?php
include("../Db_Conn.php");
//error_reporting(0);
if(isset($_POST['submit'])){
    
    date_default_timezone_set("Asia/Kolkata");
    
    $manager_id = $_POST['manager_id'];
    $manager_name = $_POST['manager_name'];
    //$notify_id = $_POST['notify_id'];
    $entry_date = date("Y-m-d H:i:s");
    
    $name = $_POST['owner_name'];
    $phone = $_POST['owner_phone'];
    $alt_phone = $_POST['alt_phone'];
    $res_phone = $_POST['residential'];
    $off_phone = $_POST['off_phone'];
    $email = $_POST['owner_email'];
    $property = $_POST['property'];
    $property_type = $_POST['property_type'];
    $type = $_POST['type'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $landmark = $_POST['landmark'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $country = $_POST['country'];
    $street = $_POST['street'];
    $land_area = $_POST['land_area'];
    $land_sqft = $_POST['land_sqft'];
    $rate_sqft = $_POST['rate_sqft'];
    
    $water_facility = implode(",",$_POST['water']);
    $power_supply = $_POST['power_supply'];
    $amenities = implode(",",$_POST['amenities']);
    $generator = $_POST['generator'];
    $elevators = $_POST['elevators'];
    $furnished = $_POST['furnished'];
    $car_park = $_POST['car_park'];
    $flooring = $_POST['flooring'];
    $bathroom = $_POST['bathroom'];
    $bedroom = $_POST['bedrooms'];
    $room = $_POST['rooms'];
    $num_floors = $_POST['floors'];
    $building_age = $_POST['building_age'];
    $built_area = $_POST['built_area'];
    $tot_flats = $_POST['flats'];
    $building_name = $_POST['building_name'];
    $architect_name = $_POST['architect_name'];
    $builders_name = $_POST['builders_name'];
    $garden = $_POST['garden'];
    $servant_qtrs = $_POST['servant_qtrs'];
    $lease_type = $_POST['lease_type'];
    $lease_period = $_POST['lease_period'];
    
    $insp_name = $_POST['key_name'];
    $insp_phone = $_POST['key_phone'];
    $insp_email = $_POST['key_email'];
    $web_host = $_POST['website'];
    $keys_collected = $_POST['keys'];
    $hrr_board = $_POST['hrrboard'];
    $listed = $_POST['listed'];
    $inspected = $_POST['inspected'];
    $source = implode(",",$_POST['source']);
    $occupation = $_POST['occupation'];
    $gender = $_POST['gender'];
    
    if($land_area == ''){
        $remarks = $_POST['remarks'];
        $price = $_POST['price'];
        $deposit = $_POST['deposit'];
        $maintenance = $_POST['maintenance'];
        $exclusive_from = $_POST['exclusive_from'];
        $exclusive_to = $_POST['exclusive_to'];
    }else{
        $remarks = $_POST['remarks1'];
        $price = $_POST['landprice'];
        $deposit = $_POST['deposit1'];
        $maintenance = $_POST['maintenance1'];
        $exclusive_from = $_POST['exclusive_from1'];
        $exclusive_to = $_POST['exclusive_to1'];
    }
    
    if(isset($_POST['check'])){
        $address1 = $_POST['address_line1'];
        $address2 = $_POST['address_line2'];
        $landmark1 = $_POST['landmark'];
        $pincode1 = $_POST['pincode'];
        $city1 = $_POST['city'];
        $state1 = $_POST['state'];
        $district1 = $_POST['district'];
        $country1 = $_POST['country'];
        $street1 = $_POST['street'];
    }else{
        $address1 = $_POST['address1_prop'];
        $address2 = $_POST['address2_prop'];
        $landmark1 = $_POST['landmarkprop'];
        $pincode1 = $_POST['pincodeprop'];
        $city1 = $_POST['cityprop'];
        $state1 = $_POST['stateprop'];
        $district1 = $_POST['districtprop'];
        $country1 = $_POST['countryprop'];
        $street1 = $_POST['streetprop'];
    }
    
    if($type == 'Purchase'){
        $typ = 'pr';
    }else if($type == 'Sale'){
        $typ = 'sl';
    }else if($type == 'Rent'){
        $typ = 'rt';
    }else if($type == 'Lease'){
        $typ = 'ls';
    }
    
    if($property_type == 'Flat'){
        $ptyp = 'fl';
    }else if($property_type == 'Duplex'){
        $ptyp = 'dpl';
    }else if($property_type == 'Pent House'){
        $ptyp = 'ph';
    }else if($property_type == 'Independent House'){
        $ptyp = 'ih';
    }else if($property_type == 'Raw House'){
        $ptyp = 'rwh';
    }else if($property_type == 'Villa'){
        $ptyp = 'vla';
    }else if($property_type == 'Office'){
        $ptyp = 'off';
    }else if($property_type == 'Showroom'){
        $ptyp = 'shr';
    }else if($property_type == 'Godown'){
        $ptyp = 'gdw';
    }else if($property_type == 'Warehouse'){
        $ptyp = 'wh';
    }else if($property_type == 'Agricultural'){
        $ptyp = 'agr';
    }else if($property_type == 'Residential'){
        $ptyp = 'res';
    }else if($property_type == 'Commercial'){
        $ptyp = 'com';
    }else if($property_type == 'Industrial'){
        $ptyp = 'ind';
    }else if($property_type == 'Mixed'){
        $ptyp = 'mx';
    }else if($property_type == 'Approved'){
        $ptyp = 'appr';
    }else if($property_type == 'Unapproved'){
        $ptyp = 'uapp';
    }else if($property_type == 'Farm'){
        $ptyp = 'frm';
    }
    
    /*check customer already existed or not*/
    $select = "SELECT * FROM `ajrealty_customer` WHERE `customer_phone`='$phone' AND `customer_email`='$email'";
    $selectcon = mysqli_query($conn,$select);
    if(mysqli_num_rows($selectcon) > 0){
        echo "<script>alert('Already this customer existed');window.location='add_new_customer.php';</script>";
    }else{
        
        $sqlcust = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'real_estate' AND TABLE_NAME = 'ajrealty_customer'";
            $concust = mysqli_query($conn,$sqlcust);
            $rowcust = mysqli_fetch_array($concust);
            $custid = $rowcust['AUTO_INCREMENT'];
            $customer_id = "aj_customer".$custid;
        
        /*if not insert customer details into table*/
        $insert = "INSERT INTO `ajrealty_customer`(`customer_id`,`gender`, `customer_name`, `customer_phone`, `alternative_phone`, `residence_phone`, `office_phone`, `customer_email`, `customer_occupation`, `customer_address_line1`, `customer_address_line2`, `street`, `customer_landmark`, `customer_city`, `customer_district`, `customer_state`, `customer_country`, `customer_pincode`, `manager_name`, `manager_id`, `entry_date`) VALUES ('$customer_id','$gender','$name','$phone','$alt_phone','$res_phone','$off_phone','$email','$occupation','$address_line1','$address_line2','$street','$landmark','$city','$district','$state','$country','$pincode','$manager_name','$manager_id','$entry_date')";
        $res = mysqli_query($conn,$insert);
        if($res){
            
            $id = $typ."_".$ptyp;
            $sql = "SELECT property_id FROM ajrealty_survey WHERE property_id LIKE '%$id%' ORDER BY property_id DESC LIMIT 1";
            $sqlcon = mysqli_query($conn,$sql);
            if(mysqli_num_rows($sqlcon) > 0){
            $row = mysqli_fetch_array($sqlcon);
            $slno = $row['property_id'];
            $p_id = $slno++;
            $property_id = $slno;
        
            }else{
                $val = $id.'_1';
                $property_id = $val;
            }
    
         /*insert customer property details to custome_survey table*/
        $insertsurvey = "INSERT INTO `ajrealty_survey`(`property_id`,`customer_id`, `staff_id`, `staff_name`, `property`, `type`, `property_type`, `owner_name`, `owner_phone`, `owner_email`, `office_phone`, `residence_phone`, `lease_type`, `lease_period`, `source`, `address1`, `address2`, `street`, `landmark`, `city`, `district`, `state`, `country`, `pincode`, `inspected`, `listed`, `hrr_board`, `keys_collected`, `website_hosting`,`servant_qtrs`,`entry_date`) VALUES ('$property_id','$customer_id','$manager_id','$manager_name','$property','$type','$property_type','$name','$phone','$email','$off_phone','$res_phone','$lease_type','$lease_period','$source','$address1','$address2','$street1','$landmark1','$city1','$district1','$state1','$country1','$pincode1','$inspected','$listed','$hrr_board','$keys_collected','$web_host','$servant_qtrs','$entry_date')";
        $ressurvey = mysqli_query($conn,$insertsurvey);
                
        $insert_qry = "INSERT INTO `ajrealty_survey_table2`(`property_id`, `inspection_person_name`, `inspection_person_phone`, `inspection_person_email`, `building_name`, `builders_name`, `architect_name`, `age_of_building`, `built_area`, `floors_num`, `bedrooms`, `rooms`, `bathrooms`, `flooring`, `generator`, `furnished`, `power_supply`, `water_facility`, `elevators`, `garden/terrace`, `car_park`, `amenties`, `total_flats`, `price`, `sqft_rate`, `land_sqft_rate`, `land_area`, `maintenance`, `deposit`, `exclusive_list_from`, `exclusive_list_to`, `remarks`, `entry_date`) VALUES ('$property_id','$insp_name','$insp_phone','$insp_email','$building_name','$builders_name','$architect_name','$building_age','$built_area','$num_floors','$bedroom','$room','$bathroom','$flooring','$generator','$furnished','$power_supply','$water_facility','$elevators','$garden','$car_park','$amenities','$tot_flats','$price','$rate_sqft','$land_sqft','$land_area','$maintenance','$deposit','$exclusive_from','$exclusive_to','$remarks','$entry_date')";
            
         $insert_qrycon = mysqli_query($conn,$insert_qry);
            
        if($ressurvey && $insert_qrycon){
            
                    /*insert remark detials to view for proprietor*/
                $remark = mysqli_query($conn, "INSERT INTO `ajrealty_remarks`(`customer_id`, `property_id`,`role` ,`staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES('$customer_id','$property_id','manager','$manager_id','$manager_name','added new customer with their property details','$entry_date')");
                    
                /*insert notification detials to view for proprietor*/
                $qry = mysqli_query($conn,"INSERT INTO `notification_status`(`customer_id`, `property_id`, `message`, `role`, `status`,`customer`, `entry_date`,`remark_from`) VALUES  ('$customer_id','$property_id','added new customer and their property details','propriator',0,'new','$entry_date','manager')");
                
                echo "<script>alert('Successfully inserted');window.location='index.php';</script>";
            }else{
                echo "<script>alert('failed');window.location='add_new_customer.php';</script>";
            }
        }
    }
}
?>