<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color:#3B5998;
}

.topnav a {
  float: right;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
    font-weight: bold;
}

.active {
/*  background-color: #4CAF50;*/
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
  float: right;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 17px;    
  border: none;
  outline: none;
  color: white;
  padding: 14px 20px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
    margin-right: 20px;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
/*  background-color: ;*/
  color: white;
}

.dropdown-content a:hover {
  background-color:#9152f8 ;
  color: white;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.img
    {
        width:50px;
        height:50px;
        float: left;
    }
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
      
  }
  .topnav a.icon {
    float: right;
    display: block;
     
  }
    .img
    {
        width:50px;
        height:50px;
    }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
    
  }
    .img
    {
        width:50px;
        height:50px;
    }
    
}
    @media screen and (max-width: 1024px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
      
  }
  .topnav a.icon {
    float: right;
    display: block;
     
  }
        .img
    {
        width:50px;
        height:50px;
    }
}

@media screen and (max-width: 1024px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
    
  }
    .img
    {
        width:50px;
        height:50px;
    }
}
    
      @media screen and (max-width: 900px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
       
  }
  .topnav a.icon {
    float: right;
    display: block;
     
  }
          .img
    {
        width:50px;
        height:50px;
    }
}

@media screen and (max-width: 900px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
    
  }
    .img
    {
        width:50px;
        height:50px;
    }
}
      @media screen and (max-width: 500px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
       
  }
  .topnav a.icon {
    float: right;
    display: block;
     
  }
          .img
    {
        width:50px;
        height:50px;
    }
}

@media screen and (max-width: 500px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: right;
    
  }
    .img
    {
        width:50px;
        height:50px;
    }
}
</style>
</head>
<body>

<?php
    
    $role = $_SESSION['role'];
    $staff_id = $_SESSION['staff_id'];
    $staff_phone = $_SESSION['staff_phone'];
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $staff_name = $row['staff_name'];
    
?>
<div class="topnav" id="myTopnav">
    <img src="../images/logo.png" class="img" onclick="window.location='index.php'">
    
    <div class="dropdown">
    <button class="dropbtn"> <?php echo $staff_name;?>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="edit_profile.php">Edit Profile</a>
      <a href="change_password.php">Change Password</a>
      <a href="logout.php">Logout</a>
    </div>
  </div> 
    <a href="assigned_project_list.php">All Assigned Project</a>
    <a href="index.php">Home</a>
    <a href="javascript:void(0);" style="font-size:40px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>



<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>

