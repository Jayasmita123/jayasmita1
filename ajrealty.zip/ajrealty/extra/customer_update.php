<?php
  include("Db_Conn.php");
    $customer_id = "ajcus3";
  $qry = "SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
  $qrycon = mysqli_query($conn,$qry);
  $display = mysqli_fetch_array($qrycon);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
	<style type="text/css">
		#personal_information,
		#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
	</style>
</head>

<body>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Customer Information</h2>
                    <form method="POST" action="customer_update.php" id="myform">
                        <fieldset id="basic_information" class="">
                            <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                        <div class="input-group">Full Name
                            <input class="input--style-2" type="text" id="name" placeholder="Customer Fullname" value="<?php echo $display['customer_name'];?>" name="name">
                            <span class="error"></span>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="email" id="email" value="<?php echo $display['customer_email'];?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer Phone" name="phone" id="phone" value="<?php echo $display['customer_phone'];?>"maxlength="10">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Gender
                                    <select name="gender" class="input--style-2">
                                        <option value="<?php echo $display['gender'];?>"><?php echo $display['gender'];?></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">Occupation
                                    <input class="input--style-2" type="text" placeholder="Occupation" value="<?php echo $display['customer_occupation'];?>" name="occupation">
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Assign Manager
                                    <select name="manager_id" class="input--style-2">
                                        <option value="<?php echo $display['manager_id'];?>"><?php echo $display['manager_name'];?></option>
                                        <option value="1">Amruta</option>
                                        <?php
                                           $sel = "SELECT staff_name, staff_id FROM `ajrealty_staffs` WHERE staff_role='Manager' GROUP BY staff_id";
                                           $selcon = mysqli_query($conn,$sel);
                                           while($fetch = mysqli_fetch_array($selcon)){
                                        ?>
                                        <option value="<?php echo $fetch['staff_id'];?>"><?php echo $fetch['staff_name'];?></option>
                                        <?php
                                           }
                                        ?>
                                    </select>
                                </div>
                            <div style="overflow:auto;">
                            <div style="float:right;">
                            <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" value="<?php echo $display['customer_address_line1'];?>" name="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" value="<?php echo $display['customer_address_line2'];?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" value="<?php echo $display['customer_landmark'];?>" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" value="<?php echo $display['customer_city'];?>" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" value="<?php echo $display['customer_pincode'];?>" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="<?php echo $display['customer_country'];?>"><?php echo $display['customer_country'];?></option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="<?php echo $display['customer_state'];?>"><?php echo $display['customer_state'];?></option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="<?php echo $display['customer_district'];?>"><?php echo $display['customer_district'];?></option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div style="overflow:auto;">
                            <div style="float:right;">
                                <button type="button" id="previous" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="update">Update</button>
                            </div>
                          </div>
                        </fieldset>
                          
                    </form>
                </div>
            </div>
        </div>
    </div>
    
   <script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([5]{1}[0-9]{5})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
							required: true,
                            emailRegex: true,
						},
                        gender: {
							required: true,
						},
                        occupation: {
							required: true,
						},
                        manager: {
							required: true,
						},
                        address1: {
							required: true,
						},
                        address2: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
						email: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        manager: {
							required: "required",
						},
                        address1: {
							required: "required",
						},
                        address2: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
					}
				});
				if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#basic_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information');
				}else if ($('#basic_information').is(":visible")){
					current_fs = $('#basic_information');
					next_fs = $('#address_information');
				}
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script> 
    
    <?php
    if(isset($_POST['update'])){
        $customer_id = $_POST['customer_id'];
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $occupation = $_POST['occupation'];
        $gender = $_POST['gender'];
        $address_line1 = $_POST['address_line1'];
        $address_line2 = $_POST['address_line2'];
        $landmark = $_POST['landmark'];
        $pincode = $_POST['pincode'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $district = $_POST['district'];
        $country = $_POST['country'];
        $manager_id = $_POST['manager_id'];
    
        $sel = "SELECT staff_name FROM `ajrealty_staffs` WHERE staff_id='$manager_id' GROUP BY staff_id";
        $selcon = mysqli_query($conn,$sel);
        $fetch = mysqli_fetch_array($selcon);
        $manager_name = "Amruta";//$_POST['staff_name'];

        $update = "UPDATE `ajrealty_customer` SET `gender`='$gender', `customer_name`='$name', `customer_phone`='$phone', `customer_email`='$email', `customer_occupation`='$occupation', `customer_address_line1`='$address_line1', `customer_address_line2`='$address_line2', `customer_landmark`='$landmark', `customer_city`='$city', `customer_district`='$district', `customer_state`='$state', `customer_country`='$country', `customer_pincode`='$pincode', `manager_name`='$manager_name', `manager_id`='$manager_id', `entry_date`=now() WHERE `customer_id`='$customer_id'";
        $res = mysqli_query($conn,$update);
        if($res){
                echo "<script>alert('Successfully updated');window.location='customer_entry.php';</script>";
            }else{
                echo "<script>alert('failed');window.location='customer_update.php?customer_id=$customer_id';</script>";
            }
    }
    ?>
</body>
</html>