<?php
include("../Db_Conn.php");
session_start();
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $manager_id = $_SESSION['staff_id'];
 $manager_phone = $_SESSION['staff_phone'];
    $customer_id = "aj_customer13";//$_REQUEST['customer_id'];
    $notify_id = '';//$_REQUEST['notify_id'];
    
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$manager_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $manager_name = $row['staff_name'];
    
    $sel = "SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
    $res = mysqli_query($conn,$sel);
    $fetch = mysqli_fetch_array($res);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
	<style type="text/css">
		#address_information,#inspection_information,#property_information,
        #property_information_land,#property_information_commercial,
        #property_information_flat,#price_information,#facility_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
        input[type="checkbox"]{
            padding-right: 20px;
        }
	</style>
</head>

<body>
     <?php
        include("nav.php");
        ?>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Details of the property - owner</h2>
                    <form method="POST" action="check.php" id="myform">
                        <fieldset id="basic_information" class="">
                            <input type="hidden" name="notify_id" id="notify_id" value="<?php echo $notify_id;?>">
                            <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $customer_id;?>">
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Property
                                <select name="property" id="property" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Residential">Residential</option>
                                    <option value="Commercial">Commercial</option>
                                    <option value="Land">Land</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Rental/sale
                                <select name="type" id="type" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Rental">Rental</option>
                                    <option value="Sale">Sale</option>
                                    <option value="Purchase">Purchase</option>
                                    <option value="Lease">Lease</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Property Type
                                <select name="property_type" id="property_type" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Flat">Flat</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        
                        <div class="input-group">Owner Name
                            <input class="input--style-2" type="text" placeholder="Property Owner Name" name="owner_name" id="name" value="<?php echo $fetch['customer_name'];?>" readonly>
                         </div>
                            
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer Phone" name="owner_phone" id="phone" value="<?php echo $fetch['customer_phone'];?>" maxlength="10" readonly>
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Owner Residential Number
                                    <input class="input--style-2" type="number" placeholder="Residential Phone" name="residential" id="residential" value="<?php echo $fetch['residence_phone'];?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Office Number
                                    <input class="input--style-2" type="number" placeholder="Office Phone" name="off_phone" id="off_phone" value="<?php echo $fetch['office_phone'];?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Property owner email" name="owner_email" id="email" value="<?php echo $fetch['customer_email'];?>">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                            <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="same_addr" value="yes" name="addr"> Property address is same as customer residential/current address
                                </div>
                            <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="street" id="street">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark" id="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city" id="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode/Zip
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                          </div>
                        </fieldset>
                          <!--tab 3-->
                        <fieldset id="inspection_information" class="">
                            <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Inspected
                                   <select name="inspected" id="inspected" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Listed
                                   <select name="listed" id="listed" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">HRR Board
                                   <select name="hrrboard" id="hrrboard" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Keys Collected
                                   <select name="keys" id="keys" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Website Hosting
                                   <select name="website" id="website" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Servant Qtrs
                                   <input class="input--style-2" type="text" placeholder="Servant Qtrs" name="servant_qtrs">
                                </div>
                            </div>
                        </div>
                        <h5>Contact person for inspection/Keys:</h5><br>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name/Address:
                                    <input class="input--style-2" type="text" placeholder="Name/Address" name="key_name" id="key_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Phone
                                    <input class="input--style-2" type="number" placeholder="Phone" name="key_phone" id="key_phone">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Email
                               <input class="input--style-2" type="text" placeholder="Email" name="key_email" id="key_email">
                            </div>
                            </div>
                        </div>
                        
                        <div class="row row-space" id="lease">
                            <div class="col-2">
                                <div class="input-group">Lease type
                                    <input class="input--style-2" type="text" placeholder="Lease type" name="lease_type" id="lease_type">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Lease period
                                    <input class="input--style-2" type="text" placeholder="Lease Period" name="lease_period" id="lease_period">
                                </div>
                            </div>
                        </div>
                        <h5>Source:</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Company" name="source[]"> Company
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="HRR Website" name="source[]"> HRR Website
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Quickr" name="source[]"> Quickr
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Paper" name="source[]"> Paper
                                </div>
                            </div>
                             <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Magic Bricks" name="source[]"> Magic Bricks
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Cold Call" name="source[]"> Cold Call
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="99 Acres" name="source[]"> 99 Acres
                                </div>
                            </div>
                             <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Just dial" name="source[]"> Just dial
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="other" value="Others" name="other"> Others
                                </div>
                            </div>
                            <div class="col-4" id="other_val">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="source" placeholder="Enter other source" name="source[]">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--residential tab 4-->
                        <fieldset id="property_information" class="residential">
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name of Building/Home
                                    <input class="input--style-2" type="text" placeholder="Building Name" name="building_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Architect Name
                                    <input class="input--style-2" type="text" placeholder="Architect Name" name="architect_name">
                                </div>
                            </div>
                           <div class="col-3">
                            <div class="input-group">Builder's Name
                               <input class="input--style-2" type="text" placeholder="Builder's Name" name="builders_name" id="builders_name">
                            </div>
                        </div> 
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Age of building
                               <input class="input--style-2" type="number" placeholder="Age of building" name="building_age" id="building_age">
                            </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Built up area
                                    <input class="input--style-2" type="text" placeholder="Built up area" name="built_area">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">No.of Floors
                                    <input class="input--style-2" type="text" placeholder="floors" name="floors">
                                </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Bedrooms
                                    <input class="input--style-2" type="text" placeholder="Number of Bedrooms" name="bedrooms">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Bathrooms
                                    <input class="input--style-2" type="text" placeholder="Total bathrooms" name="bathroom" id="bathroom">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Flooring
                               <input class="input--style-2" type="text" placeholder="Flooring" name="flooring" id="flooring">
                            </div>
                            </div>
                        </div>
                             <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Generator
                               <select name="generator" id="generator" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                               <div class="input-group">Furnished
                                <select name="furnished" id="furnished" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Fully">Fully</option>
                                    <option value="Semi">Semi</option>
                                    <option value="Not furnished">Not furnished</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Power Supply
                               <select name="power_supply" id="power_supply" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <fieldset id="facility_information" class="facility">
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Elevators
                               <input class="input--style-2" type="text" placeholder="Elevators" name="elevators" id="elevators">
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Garden/Terrace
                               <input class="input--style-2" type="text" placeholder="Garden/Terrace" name="garden" id="garden">
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Car park
                               <select name="car_park" id="car_park" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Covered">Covered</option>
                                    <option value="Open">Open</option>
                                   <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="row row-space" id="tot_flat">
                            <div class="col-2">
                                <div class="input-group">Total Number of Flats
                                    <input class="input--style-2" type="text" id="flats" placeholder="Total flats" name="flats">
                                </div>
                            </div>
                        </div>
                        <h5>Water Facility</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Metro" name="water[]"> Metro
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="water" value="Borewell" name="water[]"> Borewell
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Tanker" name="water[]"> Tanker
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2 waterval" type="checkbox" id="water" value="Others"> Others
                                </div>
                            </div>
                            <div class="col-4 water_other">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="water" name="water[]">
                                </div>
                            </div>
                        </div>
                            <h5 id="ament_text">Amenities</h5><br>
                        <div class="row row-space" id="ament">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Club House" name="amenities[]"> Club House
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Swimming Pool" name="amenities[]"> Swimming Pool
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Gym" name="amenities[]"> Gym
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Children's Play Area" name="amenities[]"> Children's Play Area
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Indoor Games" name="amenities[]"> Indoor Games
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="WIFI" name="amenities[]"> WIFI
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Walking Track" name="amenities[]"> Walking Track
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Multipurpose Hall" name="amenities[]"> Multipurpose Hall
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Tennis Court" name="amenities[]"> Tennis Court
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenitiesval" value="Others"> Others
                                </div>
                            </div>
                            <div class="col-4 amenties_other">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="amenities" name="amenities[]">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--commercial tab 4-->
                        <fieldset id="property_information_commercial" class="commercial">
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name of Building/Home
                                    <input class="input--style-2" type="text" placeholder="Building Name" name="building_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Architect Name
                                    <input class="input--style-2" type="text" placeholder="Architect Name" name="architect_name">
                                </div>
                            </div>
                           <div class="col-3">
                            <div class="input-group">Builder's Name
                               <input class="input--style-2" type="text" placeholder="Builder's Name" name="builders_name" id="builders_name">
                            </div>
                        </div> 
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Age of building
                               <input class="input--style-2" type="number" placeholder="Age of building" name="building_age" id="building_age">
                            </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Built up area
                                    <input class="input--style-2" type="text" placeholder="Built up area" name="built_area">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">No.of Floors
                                    <input class="input--style-2" type="text" placeholder="floors" name="floors">
                                </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Rooms
                                    <input class="input--style-2" type="text" placeholder="Number of Rooms" name="rooms">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Bathrooms
                                    <input class="input--style-2" type="text" placeholder="Total bathrooms" name="bathroom" id="bathroom">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Flooring
                               <input class="input--style-2" type="text" placeholder="Flooring" name="flooring" id="flooring">
                            </div>
                            </div>
                        </div>
                             <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Generator
                               <select name="generator" id="generator" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                               <div class="input-group">Furnished
                                <select name="furnished" id="furnished" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Fully">Fully</option>
                                    <option value="Semi">Semi</option>
                                    <option value="Not furnished">Not furnished</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Power Supply
                               <select name="power_supply" id="power_supply" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Car park
                               <select name="car_park" id="car_park" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Covered">Covered</option>
                                    <option value="Open">Open</option>
                                   <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <h5>Water Facility</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Metro" name="water[]"> Metro
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="water" value="Borewell" name="water[]"> Borewell
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Tanker" name="water[]"> Tanker
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2 waterval" type="checkbox" id="water" value="Others" name="water[]"> Others
                                </div>
                            </div>
                            <div class="col-4 water_other">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="water" name="water[]">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--for land tab4-->
                        <fieldset id="property_information_land" class="land">
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Land Area / UDS
                                    <input class="input--style-2" type="text" placeholder="Mobile" name="land_area" id="land_area">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Land value/sq.ft
                                    <input class="input--style-2" type="text" placeholder="land value per sq.ft" name="land_sqft" id="land_sqft">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                        <div class="col-3">
                            <div class="input-group">price
                               <input class="input--style-2" type="number" placeholder="Flooring" name="price" id="price">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">Exclusive Listing From
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing from" name="exclusive_from" id="exlusive_from">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">To
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing to" name="exclusive_to" id="exclusive_to">
                            </div>
                        </div>
                        </div>
                             <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Maintenance
                                    <input class="input--style-2" type="text" placeholder="Maintenance" name="maintenance" id="maintenance">
                                </div>
                            </div><div class="col-2">
                               <div class="input-group">Deposit
                                    <input class="input--style-2" type="text" placeholder="Deposit" name="deposit" id="deposit">
                                </div>
                            </div>
                        </div>
                             <div class="input-group">Brief Description of the proprty/Additional Information/Realtor's Remarks:
                                <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks" id="remarks"></textarea>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit">Submit</button>
                            </div>
                        </fieldset>
                        
                        <!--tab 6-->
                        <fieldset id="price_information" class="">
                        <div class="row row-space">
                        <div class="col-3">
                            <div class="input-group">Price
                               <input class="input--style-2" type="number" placeholder="Flooring" name="price" id="price">
                            </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Rate per sq.ft
                                    <input class="input--style-2" type="text" placeholder="Rate per sq.ft" name="rate_sqft" id="rate_sqft">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Maintenance
                                    <input class="input--style-2" type="text" placeholder="Maintenance" name="maintenance" id="maintenance">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                               <div class="input-group">Deposit
                                    <input class="input--style-2" type="text" placeholder="Deposit" name="deposit" id="deposit">
                                </div>
                            </div>
                                 <div class="col-3">
                            <div class="input-group">Exclusive Listing From
                               <input class="input--style-2" type="number" placeholder="Exclusive Listing from" name="exclusive_from" id="exlusive_from">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">Exclusive Listing To
                               <input class="input--style-2" type="number" placeholder="Exclusive Listing to" name="exclusive_to" id="exclusive_to">
                            </div>
                        </div>
                        </div>
                             <div class="input-group">Brief Description of the proprty/Additional Information/Realtor's Remarks:
                                <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks" id="remarks"></textarea>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
   <script type="text/javascript">
		$(document).ready(function(){
			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            
			$(".next").click(function(){
				var form = $("#myform");
				/*form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
                        key_email:{
                            emailRegex: true,
                        },
                        key_name:{
                            usernameRegex: true,
                        },
                        key_phone:{
                            phoneRegex: true,
                        },
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
                            emailRegex: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        street:{
                          required: true,  
                        },
                        remarks:{
                            required: true,  
                        },
                        price:{
                            required: true,  
                        },
                        property:{
                            required: true,  
                        },
                        type:{
                            required: true,  
                        },
                        property_type:{
                            required: true,  
                        },
                        lease_type:{
                            required: true, 
                        },
                        lease_period:{
                            required: true,  
                        }
                        
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        street:{
                          required: "required", 
                        },
                        remarks:{
                            required: "required", 
                        },
                        price:{
                            required: "required", 
                        },
                        property:{
                            required: "required", 
                        },
                        type:{
                            required: "required", 
                        },
                        property_type:{
                            required: "required",  
                        },
                        lease_type:{
                            required: "required",  
                        },
                        lease_period:{
                            required: "required",  
                        }
                        
					}
				});*/
				//if (form.valid() === true){
                if($('#property').val() == 'Commercial'){
                    if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information_commercial');
					}else if($('#property_information_commercial').is(":visible")){
						current_fs = $('#property_information_commercial');
						next_fs = $('#price_information');
					}
                }else if($('#property').val() == 'Land'){
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information_land');
					}
                }else if($('#property').val() == 'Residential'){
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information');
					}else if($('#property_information').is(":visible")){
						current_fs = $('#property_information');
						next_fs = $('#facility_information');
					}else if($('#facility_information').is(":visible")){
						current_fs = $('#facility_information');
						next_fs = $('#price_information');
					}
                }
                
					next_fs.show();
					current_fs.hide();
				//}
			});

			$('.previous').click(function(){
                if($('#property').val() == 'Commercial'){
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#inspection_information').is(":visible")){
                        current_fs = $('#inspection_information');
                        next_fs = $('#address_information');

                    }else if ($('#property_information_commercial').is(":visible")){
                        current_fs = $('#property_information_commercial');
                        next_fs = $('#inspection_information');

                    }else if ($('#price_information').is(":visible")){
                        current_fs = $('#price_information');
                        next_fs = $('#property_information_commercial');

                    }
                    
                }else if($('#property').val() == 'Land'){
                    
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#inspection_information').is(":visible")){
                        current_fs = $('#inspection_information');
                        next_fs = $('#address_information');

                    }else if ($('#property_information_land').is(":visible")){
                        current_fs = $('#property_information_land');
                        next_fs = $('#inspection_information');

                    }
                        
                }else if($('#property').val() == 'Residential'){
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#inspection_information').is(":visible")){
                        current_fs = $('#inspection_information');
                        next_fs = $('#address_information');

                    }else if ($('#property_information').is(":visible")){
                        current_fs = $('#property_information');
                        next_fs = $('#inspection_information');

                    }else if ($('#facility_information').is(":visible")){
                        current_fs = $('#facility_information');
                        next_fs = $('#property_information');

                    }else if ($('#price_information').is(":visible")){
                        current_fs = $('#price_information');
                        next_fs = $('#facility_information');

                    }
                }
				
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script>
    
   <!--display property type onchange property-->
<script>  
$('#property').change(function(){  
          
    var property = $(this).val();
    var dataString = 'property='+ property;

        $.ajax({
            type: "POST",
            url: "fetch_property_type.php",
            cache: false,
            data: dataString,
            success: function (response) {
            document.getElementById("property_type").innerHTML=response; 
              }
        });  
});   
 </script>
    
    <!--if checkbox is checked display same address from customer table-->
<script>  
$('#same_addr').click(function(){  
if($(this).is(":checked")) {

    var cus_id = document.getElementById('customer_id').value;
    var dataString = 'cus_id='+ cus_id;

        $.ajax({
            type: "POST",
            url: "fetch_address.php",
            cache: false,
            dataType: 'json',
            data: dataString,
            success: function (response) {
            var len = response.length;
                for(var i=0; i<len; i++){
                     /** assign json array values to specific var **/
                    var address1 = response[i].address1;
                    var address2 = response[i].address2;
                    var street = response[i].street;
                    var landmark = response[i].landmark;
                    var city = response[i].city;
                    var district = response[i].district;
                    var state = response[i].state;
                    var country = response[i].country;
                    var pincode = response[i].pincode;
                    var countrySel = "<option value="+country+" selected>"+country+"</option>";
                    var stateSel = "<option value="+state+" selected>"+state+"</option>";
                    var districtSel = "<option value="+district+" selected>"+district+"</option>";
                    
                    document.getElementById("address_line1").value=address1;
                    document.getElementById("address_line2").value=address2;
                    document.getElementById("street").value=street;
                    document.getElementById("landmark").value=landmark;
                    document.getElementById("city").value=city;
                    document.getElementById("pincode").value=pincode;
                    
                    $(countrySel).appendTo('#countrySel_work'); 
                    $(stateSel).appendTo('#stateSel_work'); 
                    $(districtSel).appendTo('#districtSel_work'); 
                    
                  }
              }
           });  
      }else{
          document.getElementById("address_line1").value='';
                    document.getElementById("address_line2").value='';
                    document.getElementById("street").value='';
                    document.getElementById("landmark").value='';
                    document.getElementById("city").value='';
                    document.getElementById("pincode").value='';
          
          var countrySel = "<option value=''>India</option>";
                    var stateSel = "<option value=' '>Select</option>";
                    var districtSel = "<option value=' '>Select</option>";
          
           $(countrySel).remove('#countrySel_work'); 
                    $(stateSel).remove('#stateSel_work'); 
                    $(districtSel).remove('#districtSel_work');
          
      }
});   
 </script>
    
<script>
    $("#other_val").hide();
    $("#other").click(function() {
    if($(this).is(":checked")) {
        $("#other_val").show();
    } else {
        $("#other_val").hide();
    }
});
    </script>
<script>
        $("#lease").hide();
    $("#type").change(function() {
    if($(this).val() == 'Lease') {
        $("#lease").show();
    } else {
        $("#lease").hide();
    }
});
    </script>
<script>
$("#lease").hide();
    $("#type").change(function() {
    if($(this).val() == 'Lease') {
        $("#lease").show();
    } else {
        $("#lease").hide();
    }
});
</script>
<script>
    $(".water_other").hide();
    $(".waterval").click(function() {
    if($(this).is(":checked")) {
        $(".water_other").show();
    } else {
        $(".water_other").hide();
    }
});
    </script>
<script>
    $(".amenties_other").hide();
    $("#amenitiesval").click(function() {
    if($(this).is(":checked")) {
        $(".amenties_other").show();
    } else {
        $(".amenties_other").hide();
    }
});
    </script>
    <script>
$('#property_type').change(function(){  
          
    var property =$('#property').val(); 
    var type = $(this).val();
    
    if(property == 'Residential' && type == 'Flat'){
        $("#ament").show();
        $("#ament_text").show();
        $("#tot_flat").show();
    }else{
        $("#ament").hide();
        $("#ament_text").hide();
        $("#tot_flat").hide();
    }

});   
 </script>
</body>
</html>
<!--<script>
           
        var staffid = document.getElementById('staffid').innerHTML;
        var dataString = 'staff_id='+ staffid;
          /* ajax function to get result from databse based on selection*/
        $.ajax({
            type: "POST",
            url: "fetch_result.php",
            data: dataString,
            cache: false,
            dataType: 'JSON',
            success: function (response) {
            
            /** get json value length from php **/
            var len = response.length;
            for(var i=0; i<len; i++){
                
                 /** assign json array values to specific var **/
                var cust_name = response[i].cust_name;
                var cust_phone = response[i].cust_phone;
                var alter_phone = response[i].alter_phone;
                var res_phone = response[i].res_phone;
                var off_phone = response[i].off_phone;
                var cus_id = response[i].cus_id;

                var tr_str = "<tr>" +
                    "<td>" + cus_id + "</td>" +
                    "<td>" + i + "</td>" +
                    "<td>" + cust_name + "</td>" +
                    "<td>" + cust_phone + "</td>" +
                    "<td>" + alter_phone + "</td>" +
                    "<td>" + res_phone + "</td>" +
                    "<td>" + off_phone + "</td>" +
                    "<td><button class='button popup-btn'>View and call</td>" +
                    "</tr>";
                $("#customer tbody").append(tr_str);
                
               /** append tr values to table blank tbody using table id **/
                
              }
            }
        });
</script>-->