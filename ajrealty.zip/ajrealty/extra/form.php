<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
	<style type="text/css">
		#property_information,#address_information,
        #inspection_information,#land_information,#price_information,#remarks_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
        input[type="checkbox"]{
            padding-right: 20px;
        }
	</style>
</head>

<body>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Details of the property - owner</h2>
                    <form method="POST" action="form.php" id="myform">
                        <fieldset id="basic_information" class="">
                            <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="name" placeholder="Customer Fullname" value="residential" name="type[]"> Residential
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="name" placeholder="Customer Fullname" value="commercial" name="type[]"> Commercial
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="name" placeholder="Customer Fullname" value="land" name="type[]"> Land
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="name" placeholder="Customer Fullname" value="rental" name="type[]"> Rental
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="name" placeholder="Customer Fullname" value="sale" name="type[]"> Sale
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Name
                                    <input class="input--style-2" type="text" id="name" placeholder="Customer Fullname" name="name">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="email" id="email">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer Phone" name="phone" id="phone" maxlength="10">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Owner Residential Number
                                    <input class="input--style-2" type="number" placeholder="Residential Phone" name="residential" id="residential">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Office Phone Number
                                    <input class="input--style-2" type="number" placeholder="Office Phone" name="off_phone" id="off_phone">
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">Inspected
                                   <select name="inspected" id="inspected" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Listed
                                   <select name="listed" id="listed" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">HRR Board
                                   <select name="hrrboard" id="hrrboard" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                            <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                          
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                            <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                            <div class="col-2">
                                
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="street" id="street">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                          </div>
                        </fieldset>
                          <!--tab 3-->
                        <fieldset id="inspection_information" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Keys Collected
                                   <select name="keys" id="keys" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">Website Hosting
                                   <select name="website" id="website" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        <h5>Source:</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="COMPANY" name="source[]"> COMPANY
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="HRR WEBSITE" name="source[]"> HRR WEBSITE
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="QUIKR" name="source[]"> QUIKR
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="PAPER" name="source[]"> PAPER
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="MAGIC BRICKS" name="source[]"> MAGIC BRICKS
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="COLD CALL" name="source[]"> COLD CALL
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="OTHERS" name="source[]"> OTHERS
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="99 ACRES" name="source[]"> 99 ACRES
                                </div>
                            </div>
                        </div>
                        <h5>Contact person for inspection/Keys:</h5><br>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Name/Address:
                                    <input class="input--style-2" type="text" placeholder="Name/Address" name="key_name">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Phone
                                    <input class="input--style-2" type="text" placeholder="Phone" name="key_phone">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Mobile
                                    <input class="input--style-2" type="number" placeholder="Mobile" name="key_mobile" id="key_mobile">
                                </div>
                            </div>
                            <div class="col-2">
                            <div class="input-group">Email
                               <input class="input--style-2" type="number" placeholder="Mobile" name="key_email" id="key_email">
                            </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab 4-->
                        <fieldset id="property_information" class="">
                        <h5>Property Type (Please put the tick mark)</h5><br>
                        <h5>Residential :</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="COMPANY" name="residential[]"> Flat
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="HRR WEBSITE" name="residential[]"> Duplex
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="QUIKR" name="residential[]"> Pent House
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="PAPER" name="residential[]"> Independent House
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="MAGIC BRICKS" name="residential[]"> Raw House
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="COLD CALL" name="residential[]"> Villa
                                </div>
                            </div>
                        </div>
                        <h5>Commercial :</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Office" name="commercial[]"> Office
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Showroom" name="commercial[]"> Showroom
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Godown" name="commercial[]"> Godown
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Warehouse" name="commercial[]"> Warehouse
                                </div>
                            </div>
                        </div>
                        <h5>Land :</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Agricultural" name="land[]"> Agricultural
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Residential" name="land]"> Residential
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Commercial" name="land[]"> Commercial
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Farm" name="land[]"> Farm
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Industrial" name="land[]"> Industrial
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Mixed" name="land]"> Mixed
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Approved" name="land[]"> Approved
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="Unapproved" name="land[]"> Unapproved
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name of Building
                                    <input class="input--style-2" type="text" placeholder="Building Name" name="building_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Architect Name
                                    <input class="input--style-2" type="text" placeholder="Architect Name" name="architect_name">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Land Area / UDS
                                    <input class="input--style-2" type="number" placeholder="Mobile" name="land_area" id="land_area">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Builder's Name
                               <input class="input--style-2" type="number" placeholder="Mobile" name="builders_name" id="builders_name">
                            </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Built up area
                                    <input class="input--style-2" type="text" placeholder="Built up area" name="built_area">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">No.of Floors
                                    <input class="input--style-2" type="text" placeholder="floors" name="floors">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab5-->
                        <fieldset id="land_information" class="">
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Bedrooms
                                    <input class="input--style-2" type="text" placeholder="Number of Bedrooms" name="bedrooms">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Bathrooms
                                    <input class="input--style-2" type="number" placeholder="Total bathrooms" name="bathroom" id="bathroom">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Age of building
                               <input class="input--style-2" type="number" placeholder="Mobile" name="building_age" id="building_age">
                            </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Flooring
                               <input class="input--style-2" type="number" placeholder="Flooring" name="flooring" id="flooring">
                            </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Total flats
                                    <input class="input--style-2" type="text" placeholder="Number of Flats" name="tot_flats" id="tot_flats">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Car park
                               <select name="car_park" id="car_park" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Covered">Covered</option>
                                    <option value="Open">Open</option>
                                </select>
                            </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Generator
                               <select name="generator" id="generator" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                               <div class="input-group">Furnished
                                    <select name="furnished" id="furnished" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Power Supply
                               <select name="power_supply" id="power_supply" size="1" class="input--style-2" required>
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Elevators
                               <input class="input--style-2" type="text" placeholder="Elevators" name="elevators" id="elevators">
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Servant Qtrs
                               <input class="input--style-2" type="text" placeholder="Servant Qtrs" name="qtrs" id="qtrs">
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Garden/Terrace
                               <input class="input--style-2" type="text" placeholder="Garden/Terrace" name="garden" id="garden">
                            </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab 6-->
                        <fieldset id="price_information" class="">
                            <h5>Water Facility</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Metro" name="water[]"> Metro
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="water" value="Borewell" name="water[]"> Borewell
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Tanker" name="water[]"> Tanker
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="water" value="Others" name="water[]"> Others
                                </div>
                            </div>
                        </div>
                            <h5>Amenities</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Club House" name="amenities[]"> Club House
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Swimming Pool" name="amenities[]"> Swimming Pool
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Gym" name="amenities[]"> Gym
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Children's Play Area" name="amenities[]"> Children's Play Area
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Indoor Games" name="amenities[]"> Indoor Games
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="WIFI" name="amenities[]"> WIFI
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Walking Track" name="amenities[]"> Walking Track
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Multipurpose Hall" name="amenities[]"> Multipurpose Hall
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Tennis Court" name="amenities[]"> Tennis Court
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Others" name="amenities[]"> Others
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                        <div class="col-3">
                            <div class="input-group">Sale Amount
                               <input class="input--style-2" type="number" placeholder="Flooring" name="sale_amt" id="sale_amt">
                            </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Rate per sq.ft
                                    <input class="input--style-2" type="text" placeholder="Rate per sq.ft" name="rate_sqft" id="rate_sqft">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Land value/sq.ft
                                    <input class="input--style-2" type="text" placeholder="land value per sq.ft" name="land_sqft" id="land_sqft">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab 7-->
                        <fieldset id="remarks_information" class="">
                            <div class="input-group">Brief Description of the proprty/Additional Information/Realtor's Remarks:
                                <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks" id="remarks"></textarea>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="add">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
   <script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				//var form = $("#myform");
				/*form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
                            emailRegex: true,
						},
                        gender: {
							required: true,
						},
                        occupation: {
							required: true,
						},
                        manager: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        manager: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        
					}
				});*/
				//if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information');
					}else if($('#property_information').is(":visible")){
						current_fs = $('#property_information');
						next_fs = $('#land_information');
					}else if($('#land_information').is(":visible")){
						current_fs = $('#land_information');
						next_fs = $('#price_information');
					}else if($('#price_information').is(":visible")){
						current_fs = $('#price_information');
						next_fs = $('#remarks_information');
					}
					
					next_fs.show();
					current_fs.hide();
				//}
			});

			$('.previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information');
                    
				}else if ($('#inspection_information').is(":visible")){
					current_fs = $('#inspection_information');
					next_fs = $('#address_information');
                    
				}else if ($('#property_information').is(":visible")){
					current_fs = $('#property_information');
					next_fs = $('#inspection_information');
                    
				}else if ($('#land_information').is(":visible")){
					current_fs = $('#land_information');
					next_fs = $('#property_information');
                    
				}else if ($('#price_information').is(":visible")){
					current_fs = $('#price_information');
					next_fs = $('#land_information');
                    
				}else if ($('#remarks_information').is(":visible")){
					current_fs = $('#remarks_information');
					next_fs = $('#price_information');
				}
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script> 
</body>
</html>