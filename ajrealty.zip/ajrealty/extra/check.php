<?php
include("../Db_Conn.php");
//error_reporting(0);
if(isset($_POST['submit'])){
    
  $amenities = "";
    $water_facility = "";
    $source = "";
    
    date_default_timezone_set("Asia/Kolkata");
    
    $manager_id = $_POST['manager_id'];
    $manager_name = $_POST['manager_name'];
    //$notify_id = $_POST['notify_id'];
    $entry_date = date("Y-m-d H:i:s");
    
    $name = $_POST['owner_name'];
    $phone = $_POST['owner_phone'];
    $alt_phone = $_POST['alt_phone'];
    $res_phone = $_POST['residential'];
    $off_phone = $_POST['off_phone'];
    $email = $_POST['owner_email'];
    $property = $_POST['property'];
    $property_type = $_POST['property_type'];
    $type = $_POST['type'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $landmark = $_POST['landmark'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $country = $_POST['country'];
    $street = $_POST['street'];
    $land_area = $_POST['land_area'];
    $land_sqft = $_POST['land_sqft'];
    $rate_sqft = $_POST['rate_sqft'];
    
    $water_facility = implode(',',$_POST['water']);
    $power_supply = $_POST['power_supply'];
    $amenities = implode(',',$_POST['amenities']);
    $generator = $_POST['generator'];
    $elevators = $_POST['elevators'];
    $furnished = $_POST['furnished'];
    $car_park = $_POST['car_park'];
    $flooring = $_POST['flooring'];
    $bathroom = $_POST['bathroom'];
    $bedroom = $_POST['bedrooms'];
    $room = $_POST['rooms'];
    $num_floors = $_POST['floors'];
    $building_age = $_POST['building_age'];
    $built_area = $_POST['built_area'];
    $tot_flats = $_POST['flats'];
    $building_name = $_POST['building_name'];
    $architect_name = $_POST['architect_name'];
    $builders_name = $_POST['builders_name'];
    $garden = $_POST['garden'];
    $servant_qtrs = $_POST['servant_qtrs'];
    $lease_type = $_POST['lease_type'];
    $lease_period = $_POST['lease_period'];
    
    $insp_name = $_POST['key_name'];
    $insp_phone = $_POST['key_phone'];
    $insp_email = $_POST['key_email'];
    $web_host = $_POST['website'];
    $keys_collected = $_POST['keys'];
    $hrr_board = $_POST['hrrboard'];
    $listed = $_POST['listed'];
    $inspected = $_POST['inspected'];
    $source = implode(",",$_POST['source']);
    $occupation = $_POST['occupation'];
    $gender = $_POST['gender'];
    
    if($land_area == ''){
        $remarks = $_POST['remarks'];
        $price = $_POST['price'];
        $deposit = $_POST['deposit'];
        $maintenance = $_POST['maintenance'];
        $exclusive_from = $_POST['exclusive_from'];
        $exclusive_to = $_POST['exclusive_to'];
    }else{
        $remarks = $_POST['remarks1'];
        $price = $_POST['landprice'];
        $deposit = $_POST['deposit1'];
        $maintenance = $_POST['maintenance1'];
        $exclusive_from = $_POST['exclusive_from1'];
        $exclusive_to = $_POST['exclusive_to1'];
    }
    $property_id = "sgs";
    echo "<script>alert('$building_age$building_name$builders_name$architect_name$furnished$garden$num_floors$tot_flats$lease_type$lease_period');</script>";
    
    $insert_qry = "INSERT INTO `ajrealty_survey_table2`(`property_id`, `inspection_person_name`, `inspection_person_phone`, `inspection_person_email`, `building_name`, `builders_name`, `architect_name`, `age_of_building`, `built_area`, `floors_num`, `bedrooms`, `rooms`, `bathrooms`, `flooring`, `generator`, `furnished`, `power_supply`, `water_facility`, `elevators`, `garden/terrace`, `car_park`, `amenties`, `total_flats`, `price`, `sqft_rate`, `land_sqft_rate`, `land_area`, `maintenance`, `deposit`, `exclusive_list_from`, `exclusive_list_to`, `remarks`, `entry_date`) VALUES ('$property_id','$insp_name','$insp_phone','$insp_email','$building_name','$builders_name','$architect_name','$building_age','$built_area','$num_floors','$bedroom','$room','$bathroom','$flooring','$generator','$furnished','$power_supply','$water_facility','$elevators','$garden','$car_park','$amenities','$tot_flats','$price','$rate_sqft','$land_sqft','$land_area','$maintenance','$deposit','$exclusive_from','$exclusive_to','$remarks','$entry_date')";
                
        $res_qry = mysqli_query($conn,$insert_qry);
    
}
?>