<?php
 $customer_id = "ajcus3"; //$_REQUEST['customer_id'];
$manager_id = "2";//$_REQUEST['manager_id'];
$manager_name = "amruta"; //$_REQUEST['manager_name']
?>
<html>
<head>
     <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
    
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
    
    <style>
      
html {
  width: 100%;
  height: 100%;
}

body {
  background: #efefef;
  color: #333;
  font-family: "Raleway";
  height: 100%;
}
body h1 {
  text-align: center;
  color: #428BFF;
  font-weight: 300;
  padding: 40px 0 20px 0;
  margin: 0;
}

.tabs {
  left: 50%;
  -webkit-transform: translateX(-50%);
          transform: translateX(-50%);
  position: relative;
  background: white;
  padding: 50px;
  padding-bottom: 80px;
  width: 70%;
    height: auto;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
  border-radius: 5px;
  min-width: 440px;
  max-height: 100%;
}
.tabs input[name="tab-control"] {
  display: none;
}
.tabs .content section h2,
.tabs ul li label {
  font-family: "Montserrat";
  font-weight: bold;
  font-size: 18px;
  color: #428BFF;
}
.tabs ul {
  list-style-type: none;
  padding-left: 0;
  display: flex;
  flex-direction: row;
  margin-bottom: 10px;
  justify-content: space-between;
  align-items: flex-end;
  flex-wrap: wrap;
}
.tabs ul li {
  box-sizing: border-box;
  flex: 1;
  width: 25%;
  padding: 0 10px;
  text-align: center;
}
.tabs ul li label {
  transition: all 0.3s ease-in-out;
  color: #929daf;
  padding: 5px auto;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  white-space: nowrap;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.tabs ul li label br {
  display: none;
}
.tabs ul li label svg {
  fill: #929daf;
  height: 1.2em;
  vertical-align: bottom;
  margin-right: 0.2em;
  transition: all 0.2s ease-in-out;
}
.tabs ul li label:hover, .tabs ul li label:focus, .tabs ul li label:active {
  outline: 0;
  color: #bec5cf;
}
.tabs ul li label:hover svg, .tabs ul li label:focus svg, .tabs ul li label:active svg {
  fill: #bec5cf;
}
.tabs .slider {
  position: relative;
  width: 25%;
  transition: all 0.33s cubic-bezier(0.38, 0.8, 0.32, 1.07);
}
.tabs .slider .indicator {
  position: relative;
  width: 50px;
  max-width: 100%;
  margin: 0 auto;
  height: 4px;
  background: #428BFF;
  border-radius: 1px;
}
.tabs .content {
  margin-top: 30px;
}
.tabs .content section {
  display: none;
  -webkit-animation-name: content;
          animation-name: content;
  -webkit-animation-direction: normal;
          animation-direction: normal;
  -webkit-animation-duration: 0.3s;
          animation-duration: 0.3s;
  -webkit-animation-timing-function: ease-in-out;
          animation-timing-function: ease-in-out;
  -webkit-animation-iteration-count: 1;
          animation-iteration-count: 1;
  line-height: 1.4;
}
.tabs .content section h2 {
  color: #428BFF;
  display: none;
}
.tabs .content section h2::after {
  content: "";
  position: relative;
  display: block;
  width: 30px;
  height: 3px;
  background: #428BFF;
  margin-top: 5px;
  left: 1px;
}
.tabs input[name="tab-control"]:nth-of-type(1):checked ~ ul > li:nth-child(1) > label {
  cursor: default;
  color: #428BFF;
}
.tabs input[name="tab-control"]:nth-of-type(1):checked ~ ul > li:nth-child(1) > label svg {
  fill: #428BFF;
}
@media (max-width: 600px) {
  .tabs input[name="tab-control"]:nth-of-type(1):checked ~ ul > li:nth-child(1) > label {
    background: rgba(0, 0, 0, 0.08);
  }
}
.tabs input[name="tab-control"]:nth-of-type(1):checked ~ .slider {
  -webkit-transform: translateX(0%);
          transform: translateX(0%);
}
.tabs input[name="tab-control"]:nth-of-type(1):checked ~ .content > section:nth-child(1) {
  display: block;
}
.tabs input[name="tab-control"]:nth-of-type(2):checked ~ ul > li:nth-child(2) > label {
  cursor: default;
  color: #428BFF;
}
.tabs input[name="tab-control"]:nth-of-type(2):checked ~ ul > li:nth-child(2) > label svg {
  fill: #428BFF;
}
@media (max-width: 600px) {
  .tabs input[name="tab-control"]:nth-of-type(2):checked ~ ul > li:nth-child(2) > label {
    background: rgba(0, 0, 0, 0.08);
  }
}
.tabs input[name="tab-control"]:nth-of-type(2):checked ~ .slider {
  -webkit-transform: translateX(100%);
          transform: translateX(100%);
}
.tabs input[name="tab-control"]:nth-of-type(2):checked ~ .content > section:nth-child(2) {
  display: block;
}
.tabs input[name="tab-control"]:nth-of-type(3):checked ~ ul > li:nth-child(3) > label {
  cursor: default;
  color: #428BFF;
}
.tabs input[name="tab-control"]:nth-of-type(3):checked ~ ul > li:nth-child(3) > label svg {
  fill: #428BFF;
}
@media (max-width: 600px) {
  .tabs input[name="tab-control"]:nth-of-type(3):checked ~ ul > li:nth-child(3) > label {
    background: rgba(0, 0, 0, 0.08);
  }
}
.tabs input[name="tab-control"]:nth-of-type(3):checked ~ .slider {
  -webkit-transform: translateX(200%);
          transform: translateX(200%);
}
.tabs input[name="tab-control"]:nth-of-type(3):checked ~ .content > section:nth-child(3) {
  display: block;
}
.tabs input[name="tab-control"]:nth-of-type(4):checked ~ ul > li:nth-child(4) > label {
  cursor: default;
  color: #428BFF;
}
.tabs input[name="tab-control"]:nth-of-type(4):checked ~ ul > li:nth-child(4) > label svg {
  fill: #428BFF;
}
@media (max-width: 600px) {
  .tabs input[name="tab-control"]:nth-of-type(4):checked ~ ul > li:nth-child(4) > label {
    background: rgba(0, 0, 0, 0.08);
  }
}
.tabs input[name="tab-control"]:nth-of-type(4):checked ~ .slider {
  -webkit-transform: translateX(300%);
          transform: translateX(300%);
}
.tabs input[name="tab-control"]:nth-of-type(4):checked ~ .content > section:nth-child(4) {
  display: block;
}
@-webkit-keyframes content {
  from {
    opacity: 0;
    -webkit-transform: translateY(5%);
            transform: translateY(5%);
  }
  to {
    opacity: 1;
    -webkit-transform: translateY(0%);
            transform: translateY(0%);
  }
}
@keyframes content {
  from {
    opacity: 0;
    -webkit-transform: translateY(5%);
            transform: translateY(5%);
  }
  to {
    opacity: 1;
    -webkit-transform: translateY(0%);
            transform: translateY(0%);
  }
}
@media (max-width: 1000px) {
  .tabs ul li label {
    white-space: initial;
      font-size: 14px;
  }
  .tabs ul li label br {
    display: initial;
  }
  .tabs ul li label svg {
    height: 1.5em;
  }
    .tabs{
        max-height: 200%;
    }
    body{
        overflow-x: hidden;
    }
}
@media (max-width: 600px) {
  .tabs ul li label {
    padding: 3px;
    border-radius: 5px;
    font-size: 12px;
      
  }
  .tabs ul li label span {
    display: block;
  }
  .tabs .slider {
    display: none;
  }
  .tabs .content {
    margin-top: 10px;
  }
  .tabs .content section h2 {
    display: block;
  }
    .tabs{
        max-height: 200%;
    }
 body{
    overflow-x: hidden;
  }
}
        
/*multi step form style*/
#property_information,#address_information,
        #property_information_purchase,#address_information_purchase,
        #property_information_rent,#address_information_rent,
        #property_information_lease,#address_information_lease{
    display:none;
}
.has-error{
    color: crimson;
    border: none;
}
        /*price range style*/
.slider-box {width: 90%; margin: 25px auto}
.slider {margin: 25px 0}
        
        /*Price range*/
.price-slider {
  width: 300px;
  margin: auto;
  text-align: center;
  position: relative;
  height: 6em;
}
.price-slider svg,
.price-slider input[type=range] {
  position: absolute;
  left: 0;
  bottom: 0;
}
input[type=range] {
  -webkit-appearance: none;
  width: 100%;
}
input[type=range]:focus {
  outline: none;
}
input[type=range]:focus::-webkit-slider-runnable-track {
  background: #1da1f2;
}
input[type=range]:focus::-ms-fill-lower {
  background: #1da1f2;
}
input[type=range]:focus::-ms-fill-upper {
  background: #1da1f2;
}
input[type=range]::-webkit-slider-runnable-track {
  width: 100%;
  height: 5px;
  cursor: pointer;
  animate: 0.2s;
  background: #1da1f2;
  border-radius: 1px;
  box-shadow: none;
  border: 0;
}
input[type=range]::-webkit-slider-thumb {
  z-index: 2;
  position: relative;
  box-shadow: 0px 0px 0px #000;
  border: 1px solid #1da1f2;
  height: 18px;
  width: 18px;
  border-radius: 25px;
  background: #a1d0ff;
  cursor: pointer;
  -webkit-appearance: none;
  margin-top: -7px;
}
input[type=range]::-moz-range-track {
  width: 100%;
  height: 5px;
  cursor: pointer;
  animate: 0.2s;
  background: #1da1f2;
  border-radius: 1px;
  box-shadow: none;
  border: 0;
}
input[type=range]::-moz-range-thumb {
  z-index: 2;
  position: relative;
  box-shadow: 0px 0px 0px #000;
  border: 1px solid #1da1f2;
  height: 18px;
  width: 18px;
  border-radius: 25px;
  background: #a1d0ff;
  cursor: pointer;
}
input[type=range]::-ms-track {
  width: 100%;
  height: 5px;
  cursor: pointer;
  animate: 0.2s;
  background: transparent;
  border-color: transparent;
  color: transparent;
}
input[type=range]::-ms-fill-lower,
input[type=range]::-ms-fill-upper {
  background: #1da1f2;
  border-radius: 1px;
  box-shadow: none;
  border: 0;
}
input[type=range]::-ms-thumb {
  z-index: 2;
  position: relative;
  box-shadow: 0px 0px 0px #000;
  border: 1px solid #1da1f2;
  height: 18px;
  width: 18px;
  border-radius: 25px;
  background: #a1d0ff;
  cursor: pointer;
}
    </style>
</head>
<body>
    <h1>Customer Survey</h1>
<div class="tabs">
  
  <input type="radio" id="tab1" name="tab-control" checked>
  <input type="radio" id="tab2" name="tab-control">
  <input type="radio" id="tab3" name="tab-control">  
  <input type="radio" id="tab4" name="tab-control">
  <ul>
    <li title="Sale"><label for="tab1" role="button"><svg viewBox="0 0 20 20">
							<path d="M17.671,13.945l0.003,0.002l1.708-7.687l-0.008-0.002c0.008-0.033,0.021-0.065,0.021-0.102c0-0.236-0.191-0.428-0.427-0.428H5.276L4.67,3.472L4.665,3.473c-0.053-0.175-0.21-0.306-0.403-0.306H1.032c-0.236,0-0.427,0.191-0.427,0.427c0,0.236,0.191,0.428,0.427,0.428h2.902l2.667,9.945l0,0c0.037,0.119,0.125,0.217,0.239,0.268c-0.16,0.26-0.257,0.562-0.257,0.891c0,0.943,0.765,1.707,1.708,1.707S10,16.068,10,15.125c0-0.312-0.09-0.602-0.237-0.855h4.744c-0.146,0.254-0.237,0.543-0.237,0.855c0,0.943,0.766,1.707,1.708,1.707c0.944,0,1.709-0.764,1.709-1.707c0-0.328-0.097-0.631-0.257-0.891C17.55,14.182,17.639,14.074,17.671,13.945 M15.934,6.583h2.502l-0.38,1.709h-2.312L15.934,6.583zM5.505,6.583h2.832l0.189,1.709H5.963L5.505,6.583z M6.65,10.854L6.192,9.146h2.429l0.19,1.708H6.65z M6.879,11.707h2.027l0.189,1.709H7.338L6.879,11.707z M8.292,15.979c-0.472,0-0.854-0.383-0.854-0.854c0-0.473,0.382-0.855,0.854-0.855s0.854,0.383,0.854,0.855C9.146,15.596,8.763,15.979,8.292,15.979 M11.708,13.416H9.955l-0.189-1.709h1.943V13.416z M11.708,10.854H9.67L9.48,9.146h2.228V10.854z M11.708,8.292H9.386l-0.19-1.709h2.512V8.292z M14.315,13.416h-1.753v-1.709h1.942L14.315,13.416zM14.6,10.854h-2.037V9.146h2.227L14.6,10.854z M14.884,8.292h-2.321V6.583h2.512L14.884,8.292z M15.978,15.979c-0.471,0-0.854-0.383-0.854-0.854c0-0.473,0.383-0.855,0.854-0.855c0.473,0,0.854,0.383,0.854,0.855C16.832,15.596,16.45,15.979,15.978,15.979 M16.917,13.416h-1.743l0.189-1.709h1.934L16.917,13.416z M15.458,10.854l0.19-1.708h2.218l-0.38,1.708H15.458z"></path>
						</svg><br><span>Sale</span></label></li>
    <li title="Purchase"><label for="tab2" role="button"><svg viewBox="0 0 20 20">
							<path d="M17.638,6.181h-3.844C13.581,4.273,11.963,2.786,10,2.786c-1.962,0-3.581,1.487-3.793,3.395H2.362c-0.233,0-0.424,0.191-0.424,0.424v10.184c0,0.232,0.191,0.424,0.424,0.424h15.276c0.234,0,0.425-0.191,0.425-0.424V6.605C18.062,6.372,17.872,6.181,17.638,6.181 M13.395,9.151c0.234,0,0.425,0.191,0.425,0.424S13.629,10,13.395,10c-0.232,0-0.424-0.191-0.424-0.424S13.162,9.151,13.395,9.151 M10,3.635c1.493,0,2.729,1.109,2.936,2.546H7.064C7.271,4.744,8.506,3.635,10,3.635 M6.605,9.151c0.233,0,0.424,0.191,0.424,0.424S6.838,10,6.605,10c-0.233,0-0.424-0.191-0.424-0.424S6.372,9.151,6.605,9.151 M17.214,16.365H2.786V7.029h3.395v1.347C5.687,8.552,5.332,9.021,5.332,9.575c0,0.703,0.571,1.273,1.273,1.273c0.702,0,1.273-0.57,1.273-1.273c0-0.554-0.354-1.023-0.849-1.199V7.029h5.941v1.347c-0.495,0.176-0.849,0.645-0.849,1.199c0,0.703,0.57,1.273,1.272,1.273s1.273-0.57,1.273-1.273c0-0.554-0.354-1.023-0.849-1.199V7.029h3.395V16.365z"></path>
						</svg><br><span>Purchase</span></label></li>
    <li title="Rent"><label for="tab3" role="button"><svg viewBox="0 0 24 24"><path d="M2,10.96C1.5,10.68 1.35,10.07 1.63,9.59L3.13,7C3.24,6.8 3.41,6.66 3.6,6.58L11.43,2.18C11.59,2.06 11.79,2 12,2C12.21,2 12.41,2.06 12.57,2.18L20.47,6.62C20.66,6.72 20.82,6.88 20.91,7.08L22.36,9.6C22.64,10.08 22.47,10.69 22,10.96L21,11.54V16.5C21,16.88 20.79,17.21 20.47,17.38L12.57,21.82C12.41,21.94 12.21,22 12,22C11.79,22 11.59,21.94 11.43,21.82L3.53,17.38C3.21,17.21 3,16.88 3,16.5V10.96C2.7,11.13 2.32,11.14 2,10.96M12,4.15V4.15L12,10.85V10.85L17.96,7.5L12,4.15M5,15.91L11,19.29V12.58L5,9.21V15.91M19,15.91V12.69L14,15.59C13.67,15.77 13.3,15.76 13,15.6V19.29L19,15.91M13.85,13.36L20.13,9.73L19.55,8.72L13.27,12.35L13.85,13.36Z" />
</svg><br><span>Rent</span></label></li>    
      <li title="Lease"><label for="tab4" role="button"><svg viewBox="0 0 24 24">
    <path d="M3,4A2,2 0 0,0 1,6V17H3A3,3 0 0,0 6,20A3,3 0 0,0 9,17H15A3,3 0 0,0 18,20A3,3 0 0,0 21,17H23V12L20,8H17V4M10,6L14,10L10,14V11H4V9H10M17,9.5H19.5L21.47,12H17M6,15.5A1.5,1.5 0 0,1 7.5,17A1.5,1.5 0 0,1 6,18.5A1.5,1.5 0 0,1 4.5,17A1.5,1.5 0 0,1 6,15.5M18,15.5A1.5,1.5 0 0,1 19.5,17A1.5,1.5 0 0,1 18,18.5A1.5,1.5 0 0,1 16.5,17A1.5,1.5 0 0,1 18,15.5Z" />
</svg><br><span>Lease</span></label></li>
  </ul>
  
  <div class="slider"><div class="indicator"></div></div>
  <div class="content">
    <section>
     <div class="page-wrapper bg-red p-t-20 p-b-20">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Sale Information</h2>
                    <form method="POST" action="customer_survey_insert.php" id="myform">
                        <fieldset id="basic_information" class="">
                            
                         <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            <input type="hidden" name="type" value="Sale">
                            
                        <div class="input-group">Property Owner Fullname
                             <input class="input--style-2" type="text" id="owner_name" placeholder="Customer Fullname" name="owner_name">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Property Owner Phone Number
                                    <input class="input--style-2" type="text" placeholder="Customer Phone" name="owner_phone" id="owner_phone">
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">Property Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="owner_email" id="owner_email">
                                </div>
                            </div>
                        </div>
                             <div class="input-group">Property
                               <select name="property" id="property" size="1" class="input--style-2" required>
                                   <option value="">Select property</option>
                                   <option value="Agriculture Land">Agriculture Land</option>
                                   <option value="Farm">Farm</option>
                                   <option value="Commercial Land">Commercial Land</option>
                                   <option value="Plot">Plot</option>
                               </select>
                            </div>
                            
                            <div class="divbtn">
                            <button type="button" class="btn btn--radius btn--submit next">Next</button>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                            <h2>Complete address of property</h2>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--property information-->
                        <fieldset id="property_information" class="">
                        <h2>Property Details</h2>
                            <div class="input-group">Price
                                    <input class="input--style-2" type="number" placeholder="Price" name="price" id="price">
                                </div>
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">area size
                                    <input class="input--style-2" type="text" placeholder="Area" name="area" id="area">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Customise area size
                                    <input class="input--style-2" type="text" placeholder="Size" name="size" id="size">
                                </div>
                            </div>
                        </div>
                        <div class="input-group">Remarks
                         <textarea type="text" placeholder="Write about this survey" row="10" name="remarks" id="remarks"></textarea>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="sale_submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
        </div>
      </section>
      <!--Purchase form-->
        <section>
          <div class="page-wrapper bg-red p-t-20 p-b-20">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Purchase Information</h2>
                    <form method="POST" action="customer_survey_insert.php" id="myform_purchase">
                        <fieldset id="basic_information_purchase" class="">
                        
                            <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            <input type="hidden" name="type" value="Purchase">
                            
                        <div class="input-group">Property purchaser Fullname
                             <input class="input--style-2" type="text" id="owner_name" placeholder="Customer Fullname" name="owner_name">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Property purchaser Phone Number
                                    <input class="input--style-2" type="text" placeholder="Customer Phone" name="owner_phone" id="owner_phone">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Property purchaser Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="owner_email" id="owner_email">
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Property
                               <select name="property" id="property" size="1" class="input--style-2" required>
                                   <option value="">Select property</option>
                                   <option value="Agriculture Land">Agriculture Land</option>
                                   <option value="Farm">Farm</option>
                                   <option value="Commercial Land">Commercial Land</option>
                                   <option value="Plot">Plot</option>
                               </select>
                            </div>
                            
                            <div class="divbtn">
                                <button type="button" class="btn btn--radius btn--submit next_purchase">Next</button>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information_purchase" class="">
                            <h2>Complete address of property</h2>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_purchase" class="btn btn--radius btn--submit">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next_purchase">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--property information-->
                        <fieldset id="property_information_purchase" class="">
                        <h2>Property Details</h2>
                        <div class="price-slider">
                            <div class="input-group">Price range<br>
                             <span>from
                             <input type="number" value="5000" min="0" max="10000000" name="price_min"/>	to
                                <input type="number" value="500000" min="0" max="10000000" name="price_max"/></span>
                          </div>
                            <div class="input-group">
                             <input value="25000" min="0" max="10000000" step="500" type="range"/>
                              <input value="500000" min="0" max="1000000" step="500" type="range"/>
                              <!--<svg width="100%" height="24">
                                <line x1="4" y1="0" x2="300" y2="0" stroke="#212121" stroke-width="12"></line>
                              </svg>-->
                        </div>
                            </div> 
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">required area
                                    <input class="input--style-2" type="text" placeholder="Area" name="area" id="area">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Customise area size
                                    <input class="input--style-2" type="text" placeholder="Size" name="size" id="size">
                                </div>
                            </div>
                        </div>
                        <div class="input-group">Remarks
                           <textarea class="input--style-2" type="text" placeholder="Write about this survey" row="50" name="remarks" id="remarks"></textarea>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_purchase" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="purchase_submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
        </div>
      </section>
      <section>
      <!--rent form-->
      <div class="page-wrapper bg-red p-t-20 p-b-20">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Rent Information</h2>
                    <form method="POST" action="customer_survey_insert.php" id="myform_rent">
                        <fieldset id="basic_information_rent" class="">
                        
                            <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            <input type="hidden" name="type" value="Rent">
                            
                        <div class="input-group">Owner Fullname
                             <input class="input--style-2" type="text" id="owner_name" placeholder="Customer Fullname" name="owner_name">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Phone Number
                                    <input class="input--style-2" type="text" placeholder="Customer Phone" name="owner_phone" id="owner_phone">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="owner_email" id="owner_email">
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Property
                               <select name="property" id="property" size="1" class="input--style-2" required>
                                   <option value="">Select property</option>
                                   <option value="Agriculture Land">Agriculture Land</option>
                                   <option value="Farm">Farm</option>
                                   <option value="Commercial Land">Commercial Land</option>
                                   <option value="Plot">Plot</option>
                               </select>
                            </div>
                            
                            <div class="divbtn">
                                <button type="button" class="btn btn--radius btn--submit next_rent">Next</button>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information_rent" class="">
                            <h2>Complete address of property</h2>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_rent" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_rent" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_rent" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_rent" class="btn btn--radius btn--submit">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next_rent">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--property information-->
                        <fieldset id="property_information_rent" class="">
                        <h2>Property Details</h2>
                        <div class="price-slider">
                            <div class="input-group">Price range<br>
                             <span>from
                             <input type="number" value="5000" min="0" max="10000000" name="price_min"/>	to
                                <input type="number" value="500000" min="0" max="10000000" name="price_max"/></span>
                          </div>
                            <div class="input-group">
                             <input value="25000" min="0" max="10000000" step="500" type="range"/>
                              <input value="500000" min="0" max="1000000" step="500" type="range"/>
                              <!--<svg width="100%" height="24">
                                <line x1="4" y1="0" x2="300" y2="0" stroke="#212121" stroke-width="12"></line>
                              </svg>-->
                        </div>
                            </div> 
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">required area
                                    <input class="input--style-2" type="text" placeholder="Area" name="area" id="area">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Customise area size
                                    <input class="input--style-2" type="text" placeholder="Size" name="size" id="size">
                                </div>
                            </div>
                        </div>
                        <div class="input-group">Remarks
                           <textarea class="input--style-2" type="text" placeholder="Write about this survey" row="50" name="remarks" id="remarks"></textarea>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_rent" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="rent_submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
        </div>
            </section>
      <!--lease form-->
    <section>
         <div class="page-wrapper bg-red p-t-20 p-b-20">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Lease Information</h2>
                    <form method="POST" action="customer_survey_insert.php" id="myform_lease">
                        <fieldset id="basic_information_lease" class="">
                        
                            <input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            <input type="hidden" name="type" value="Lease">
                            
                        <div class="input-group">Owner Fullname
                             <input class="input--style-2" type="text" id="owner_name" placeholder="Customer Fullname" name="owner_name">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Phone Number
                                    <input class="input--style-2" type="text" placeholder="Customer Phone" name="owner_phone" id="owner_phone">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="owner_email" id="owner_email">
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Property
                               <select name="property" id="property" size="1" class="input--style-2" required>
                                   <option value="">Select property</option>
                                   <option value="Agriculture Land">Agriculture Land</option>
                                   <option value="Farm">Farm</option>
                                   <option value="Commercial Land">Commercial Land</option>
                                   <option value="Plot">Plot</option>
                               </select>
                            </div>
                            <div class="divbtn">
                                <button type="button" class="btn btn--radius btn--submit next_lease">Next</button>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information_lease" class="">
                            <h2>Complete address of property</h2>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_lease" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_lease" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                            <div class="input-group">District
                               <select name="district" id="districtSel_lease" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_lease" class="btn btn--radius btn--submit">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next_lease">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--property information-->
                        <fieldset id="property_information_lease" class="">
                        <h2>Property Details</h2>
                        <div class="price-slider">
                            <div class="input-group">Price range<br>
                             <span>from
                             <input type="number" value="5000" min="0" max="10000000" name="price_min"/>	to
                             <input type="number" value="500000" min="0" max="10000000" name="price_max"/></span>
                          </div>
                            <div class="input-group">
                             <input value="25000" min="0" max="10000000" step="500" type="range"/>
                              <input value="500000" min="0" max="1000000" step="500" type="range"/>
                              <!--<svg width="100%" height="24">
                                <line x1="4" y1="0" x2="300" y2="0" stroke="#212121" stroke-width="12"></line>
                              </svg>-->
                        </div>
                            </div> 
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">required area
                                    <input class="input--style-2" type="text" placeholder="Area" name="area" id="area">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Customise area size
                                    <input class="input--style-2" type="text" placeholder="Size" name="size" id="size">
                                </div>
                            </div>
                        </div>
                        <div class="input-group">Remarks
                           <textarea class="input--style-2" type="text" placeholder="Write about this survey" row="50" name="remarks" id="remarks"></textarea>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous_lease" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="lease_submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </section>
  </div>
</div>
    
<script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						owner_name: {
							required: true,
							usernameRegex: true,
						},
						owner_phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						owner_email: {
							required: true,
                            emailRegex: true,
						},
                        pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
                        price: {
							required: true,
						},
                        size: {
							required: true,
						},
                        remarks : {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        address_line2:{
                            required: true,
                        },
						
					},
                    messages: {
						
						owner_phone : {
							required: "required",
						},
						owner_name: {
							required: "required",
						},
						owner_email: {
							required: "required",
						},
                        pincode : {
							required: "required",
						},
                        price: {
							required: "required",
						},
                        size: {
							required: "required",
						},
                        remarks : {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        address_line2:{
                            required: "required",
                        },
					}
				});
				if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#property_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information');
				}else if ($('#property_information').is(":visible")){
					current_fs = $('#property_information');
					next_fs = $('#address_information');
				}
				next_fs.show();
				current_fs.hide();
			});
		});
	</script> 
    
    <script>
    /**purchase form**/
        // Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

            $(".next_purchase").click(function(){
				var form1 = $("#myform_purchase");
				form1.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						owner_name: {
							required: true,
							usernameRegex: true,
						},
						owner_phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						owner_email: {
							required: true,
                            emailRegex: true,
						},
                        pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
                        price_min: {
							required: true,
						},
                        price_max:{
                            required : true,
                        },
                        size: {
							required: true,
						},
                        remarks : {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        address_line2:{
                            required: true,
                        },
						
					},
                    messages: {
						
						owner_phone : {
							required: "required",
						},
						owner_name: {
							required: "required",
						},
						owner_email: {
							required: "required",
						},
                        pincode : {
							required: "required",
						},
                        price_min: {
							required: "required",
						},
                        price_max:{
                            required : "required",
                        },
                        size: {
							required: "required",
						},
                        remarks : {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        address_line2:{
                            required: "required",
                        },
					}
				});
				if (form1.valid() === true){
					if ($('#basic_information_purchase').is(":visible")){
						current_fs = $('#basic_information_purchase');
						next_fs = $('#address_information_purchase');
					}else if($('#address_information_purchase').is(":visible")){
						current_fs = $('#address_information_purchase');
						next_fs = $('#property_information_purchase');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous_purchase_purchase').click(function(){
				if($('#address_information_purchase').is(":visible")){
					current_fs = $('#address_information_purchase');
					next_fs = $('#basic_information_purchase');
				}else if ($('#property_information_purchase').is(":visible")){
					current_fs = $('#property_information_purchase');
					next_fs = $('#address_information_purchase');
				}
				next_fs.show();
				current_fs.hide();
			});
    </script>
    
    <script>
    /**rent form**/
        // Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

            $(".next_rent").click(function(){
				var form1 = $("#myform_rent");
				form1.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						owner_name: {
							required: true,
							usernameRegex: true,
						},
						owner_phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						owner_email: {
							required: true,
                            emailRegex: true,
						},
                        pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
                        price_min: {
							required: true,
						},
                        price_max:{
                            required : true,
                        },
                        area: {
							required: true,
						},
                        remarks : {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        address_line2:{
                            required: true,
                        },
						
					},
                    messages: {
						
						owner_phone : {
							required: "required",
						},
						owner_name: {
							required: "required",
						},
						owner_email: {
							required: "required",
						},
                        pincode : {
							required: "required",
						},
                        price_min: {
							required: "required",
						},
                        price_max:{
                            required : "required",
                        },
                        area: {
							required: "required",
						},
                        remarks : {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        address_line2:{
                            required: "required",
                        },
					}
				});
				if (form1.valid() === true){
					if ($('#basic_information_rent').is(":visible")){
						current_fs = $('#basic_information_rent');
						next_fs = $('#address_information_rent');
					}else if($('#address_information_rent').is(":visible")){
						current_fs = $('#address_information_rent');
						next_fs = $('#property_information_rent');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous_purchase_rent').click(function(){
				if($('#address_information_rent').is(":visible")){
					current_fs = $('#address_information_rent');
					next_fs = $('#basic_information_rent');
				}else if ($('#property_information_rent').is(":visible")){
					current_fs = $('#property_information_rent');
					next_fs = $('#address_information_rent');
				}
				next_fs.show();
				current_fs.hide();
			});
    </script>
    
    <script>
    /**lease form**/
        // Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

            $(".next_lease").click(function(){
				var form1 = $("#myform_lease");
				form1.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						owner_name: {
							required: true,
							usernameRegex: true,
						},
						owner_phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						owner_email: {
							required: true,
                            emailRegex: true,
						},
                        pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
                        price_min: {
							required: true,
						},
                        price_max:{
                            required : true,
                        },
                        area: {
							required: true,
						},
                        remarks : {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        address_line2:{
                            required: true,
                        },
						
					},
                    messages: {
						
						owner_phone : {
							required: "required",
						},
						owner_name: {
							required: "required",
						},
						owner_email: {
							required: "required",
						},
                        pincode : {
							required: "required",
						},
                        price_min: {
							required: "required",
						},
                        price_max:{
                            required : "required",
                        },
                        area: {
							required: "required",
						},
                        remarks : {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        address_line2:{
                            required: "required",
                        },
					}
				});
				if (form1.valid() === true){
					if ($('#basic_information_lease').is(":visible")){
						current_fs = $('#basic_information_lease');
						next_fs = $('#address_information_lease');
					}else if($('#address_information_lease').is(":visible")){
						current_fs = $('#address_information_lease');
						next_fs = $('#property_information_lease');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous_purchase_lease').click(function(){
				if($('#address_information_lease').is(":visible")){
					current_fs = $('#address_information_lease');
					next_fs = $('#basic_information_lease');
				}else if ($('#property_information_lease').is(":visible")){
					current_fs = $('#property_information_lease');
					next_fs = $('#address_information_lease');
				}
				next_fs.show();
				current_fs.hide();
			});
    </script>
    
    <!--price range script-->
    <script>
    (function() {
 
  var parent = document.querySelector(".price-slider");
  if(!parent) return;
 
  var
    rangeS = parent.querySelectorAll("input[type=range]"),
    numberS = parent.querySelectorAll("input[type=number]");
 
  rangeS.forEach(function(el) {
    el.oninput = function() {
      var slide1 = parseFloat(rangeS[0].value),
        	slide2 = parseFloat(rangeS[1].value);
 
      if (slide1 > slide2) {
		[slide1, slide2] = [slide2, slide1];
      }
 
      numberS[0].value = slide1;
      numberS[1].value = slide2;
    }
  });
 
  numberS.forEach(function(el) {
    el.oninput = function() {
		var number1 = parseFloat(numberS[0].value),
		number2 = parseFloat(numberS[1].value);
		
      if (number1 > number2) {
        var tmp = number1;
        numberS[0].value = number2;
        numberS[1].value = tmp;
      }
 
      rangeS[0].value = number1;
      rangeS[1].value = number2;
 
    }
  });
 
})();
    </script>
    </body>
</html>

