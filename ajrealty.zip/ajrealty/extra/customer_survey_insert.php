<?php
include("Db_Conn.php");
if(isset($_POST['sale_submit']) || isset($_POST['purchase_submit']) || isset($_POST['rent_submit']) || isset($_POST['lease_submit'])){
    
    $customer_id = $_POST['customer_id'];
    $manager_id = $_POST['manager_id'];
    $manager_name = $_POST['manager_name'];
    $entry_date = date("Y-m-d H:i:s");
    $assign_md = "1";
    
    $name = $_POST['owner_name'];
    $phone = $_POST['owner_phone'];
    $email = $_POST['owner_email'];
    $property = $_POST['property'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $landmark = $_POST['landmark'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $country = $_POST['country'];
    $area = $_POST['area'];
    $size = $_POST['size'];
    $remarks = $_POST['remarks'];
    $type = $_POST['type'];
    if(isset($_POST['price'])){
        $price = $_POST['price'];
    }else{
        $price = $_POST['price_min']."-".$_POST['price_max'];
    }
    
        $insert = "INSERT INTO `ajrealty_customer_survey_sale` (`customer_id`, `manager_id`, `manager_name`, `type`, `property_owner_name`, `property_owner_phone`, `property_owner_email`, `property`, `price`, `area`, `customise_size`, `address_line1`, `address_line2`, `landmark`, `city`, `district`, `state`, `country`, `pincode`, `entry_date`) VALUES ('$customer_id','$manager_id','$manager_name','$type','$name','$phone','$email','$property','$price','$area','$size','$address_line1','$address_line2','$landmark','$city','$district','$state','$country','$pincode','$entry_date')";
        $res = mysqli_query($conn,$insert);
        if($res){
            $sql = "SELECT * FROM `ajrealty_customer_survey_sale` WHERE `property_owner_phone`='$phone' AND `property_owner_email`='$email' AND `customer_id`='$customer_id' AND `property`='$property' ORDER BY `Sl.No` DESC LIMIT 1";
            $sqlcon = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($sqlcon);
            $slno = $row['Sl.No'];
            $survey_id = "survey".$slno;
            
            $update = "UPDATE `ajrealty_customer_survey_sale` SET `survey_id`='$survey_id' WHERE `property_owner_phone`='$phone' AND `property_owner_email`='$email' AND `customer_id`='$customer_id' AND `property`='$property'";
            $updcon = mysqli_query($conn,$update);
            if($updcon){
                $message = "Manager <b>".$manager_name."</b> has been taken survey for the customer id ".$customer_id;
                
                $qry = mysqli_query($conn,"INSERT INTO `notification_status`(`staff_id`, `staff_name`, `assigned_staff_id`, `message`, `role`, `status`, `entry_date`) VALUES ('$manager_id','$manager_name','$assign_md','$message','managing director',0,'$entry_date')");
                echo "<script>alert('Successfully inserted');window.location='customer_survey.php';</script>";
            }else{
                echo "<script>alert('failed');window.location='customer_survey.php';</script>";
            }
        }
}
?>