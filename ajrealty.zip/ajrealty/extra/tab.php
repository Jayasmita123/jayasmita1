<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>
    
	<style type="text/css">
        body{
            padding: 20px;
        }
    label, a {
      cursor: pointer;
      user-select: none;
      text-decoration: none;
      display: inline-block;
      color: inherit;
      transition: border 0.2s;
      border-bottom: 5px solid rgba(142, 68, 173, 0.2);
      padding: 3px 2px;
    }
    label:hover, a:hover {
      border-bottom-color: #9b59b6;
    }

    .layout {
      display: grid;
      height: 100%;
      width: 80%;
      overflow: hidden;
      grid-template-rows: 50px 1fr;
      grid-template-columns: 1fr 1fr 1fr;
    }

    input[type="radio"] {
      display: none;
    }

    label.nav {
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      border-bottom: 2px solid #8e44ad;
      background: #ecf0f1;
      user-select: none;
      transition: background 0.4s, padding-left 0.2s;
      padding-left: 0;
    }
    input[type="radio"]:checked + .page + label.nav {
      background: #9b59b6;
      color: #ffffff;
      padding-left: 20px;
    }
    input[type="radio"]:checked + .page + label.nav span {
      padding-left: 20px;
    }
    input[type="radio"]:checked + .page + label.nav svg {
      opacity: 1;
    }
    label.nav span {
      padding-left: 0px;
      position: relative;
    }
    label.nav svg {
      left: 0;
      top: -3px;
      position: absolute;
      width: 15px;
      opacity: 0;
      transition: opacity 0.2s;
    }

    .page {
      grid-column-start: 1;
      grid-row-start: 2;
      grid-column-end: span 3;
      padding: 0px 20px;
      display: flex;
      align-items: center;
    }

    .page-contents > * {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.2s, transform 0.2s;
    }
    .page-contents > *:nth-child(1) {
      transition-delay: 0.4s;
    }
    .page-contents > *:nth-child(2) {
      transition-delay: 0.6s;
    }
    .page-contents > *:nth-child(3) {
      transition-delay: 0.8s;
    }
    .page-contents > *:nth-child(4) {
      transition-delay: 1s;
    }
    .page-contents > *:nth-child(5) {
      transition-delay: 1.2s;
    }
    .page-contents > *:nth-child(6) {
      transition-delay: 1.4s;
    }
    .page-contents > *:nth-child(7) {
      transition-delay: 1.6s;
    }
    .page-contents > *:nth-child(8) {
      transition-delay: 1.8s;
    }
    .page-contents > *:nth-child(9) {
      transition-delay: 2s;
    }
    .page-contents > *:nth-child(10) {
      transition-delay: 2.2s;
    }
    .page-contents > *:nth-child(11) {
      transition-delay: 2.4s;
    }
    .page-contents > *:nth-child(12) {
      transition-delay: 2.6s;
    }
    .page-contents > *:nth-child(13) {
      transition-delay: 2.8s;
    }
    .page-contents > *:nth-child(14) {
      transition-delay: 3s;
    }
    .page-contents > *:nth-child(15) {
      transition-delay: 3.2s;
    }
    .page-contents > *:nth-child(16) {
      transition-delay: 3.4s;
    }
    .page-contents > *:nth-child(17) {
      transition-delay: 3.6s;
    }
    .page-contents > *:nth-child(18) {
      transition-delay: 3.8s;
    }
    .page-contents > *:nth-child(19) {
      transition-delay: 4s;
    }
    .page-contents > *:nth-child(20) {
      transition-delay: 4.2s;
    }

    input[type="radio"] + .page {
      transition: transform 0.2s;
      transform: translateX(100%);
    }

    input[type="radio"]:checked + .page {
      transform: translateX(0%);
    }
    input[type="radio"]:checked + .page .page-contents > * {
      opacity: 1;
      transform: translateY(0px);
    }

    .page-contents {
      width: 100%;
      margin: 0 auto;
    }
</style>
</head>

<body>
<div class="layout">
  <input name="nav" type="radio" class="nav home-radio" id="sale" checked="checked" />
  <div class="page home-page">
    <div class="page-contents">
        Sale
    </div>
  </div>
  <label class="nav" for="sale">
    <span>
      <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
      Sale
    </span>
  </label>

  <input name="nav" type="radio" class="about-radio" id="purchase" />
  <div class="page about-page">
    <div class="page-contents">
      <h1>About</h1>
      <p>Amet consectetur adipisicing elit. Sed ipsam ad exercitationem, quo quae ullam, quidem laudantium corporis quis minima debitis nesciunt repellat. Quos dolore ex quis voluptas, minus ut?</p>
    </div>
  </div>
  <label class="nav" for="purchase">
    <span>
    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12" y2="17"></line></svg>
    purchase
      </span>
    </label>

  <input name="nav" type="radio" class="contact-radio" id="rent" />
  <div class="page contact-page">
    <div class="page-contents">
      <h1>Contact</h1>
      <p>Eaque accusamus magnam error unde nam, atque provident omnis fugiat quam necessitatibus vel nulla sed quibusdam fuga veritatis assumenda alias quidem asperiores?</p>
      <p><a href="#">Get in touch</a></p>
    </div>
  </div>
  <label class="nav" for="rent">
    <span>
    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
    Rent
      </span>
    
  </label>
</div>
</body>
</html>