<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
</head>

<body>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Customer Information</h2>
                    <form method="POST" action="customer_entry_insert.php" id="regForm">
                        <div class="tab">
                        <div class="input-group">Full Name
                            <input class="input--style-2" type="text" id="name" placeholder="Customer Fullname" name="name">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="email">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Phone Number
                                    <input class="input--style-2" type="text" placeholder="Customer Phone" name="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Gender
                                    <select name="gender" class="input--style-2">
                                        <option value="">Select Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                                <div class="col-2">
                                <div class="input-group">Occupation
                                    <input class="input--style-2" type="text" placeholder="Occupation" name="occupation">
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Assign Manager
                                    <select name="manager_id" class="input--style-2">
                                        <option value="">Select Manager</option>
                                        <option value="1">Amruta</option>
                                        <?php
                                           $sel = "SELECT staff_name, staff_id FROM `ajrealty_staffs` WHERE staff_role='Manager' GROUP BY staff_id";
                                           $selcon = mysqli_query($conn,$sel);
                                           while($fetch = mysqli_fetch_array($selcon)){
                                        ?>
                                        <option value="<?php echo $fetch['staff_id'];?>"><?php echo $fetch['staff_name'];?></option>
                                        <?php
                                           }
                                        ?>
                                    </select>
                                </div>
                        </div>
                        <!--tab 2-->
                        <div class="tab">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="text" placeholder="Pincode" name="pincode">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div style="overflow:auto;">
                            <div style="float:right;">
                              <button type="button" id="prevBtn" class="btn btn--radius btn--submit" onclick="nextPrev(-1)">Previous</button>
                              <button type="button" id="nextBtn" class="btn btn--radius btn--submit" onclick="nextPrev(1)">Next</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="add">Submit</button>
                            </div>
                          </div>
                          <!-- Circles which indicates the steps of the form: -->
                          <div style="text-align:center;" class="p-t-20">
                            <span class="step"></span>
                            <span class="step"></span>
                          </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
      document.getElementById("add").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").style.display = "none";
      document.getElementById("add").style.display = "inline";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, z, j, valid = true;
    var namepattern = /^[a-zA-Z., ]+$/;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  z = x[currentTab].getElementsByTagName("select");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
    
 for (j = 0; j < z.length; j++) {
    // If a field is empty...
    if (z[j].innerHTML == "") {
      // add an "invalid" class to the field:
      z[j].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
    <script type="text/javascript" src="jquery.validate.js"></script>
<script type="text/javascript">
jQuery().ready(function() {
 
  var v = jQuery("#regForm").validate({
      rules: {
        name: {
          required: true,
          minlength: 2,
          maxlength: 16
        },
        email: {
          required: true,
          minlength: 2,
          email: true,
          maxlength: 100,
        },
        phone: {
          required: true,
          minlength: 10,
          maxlength: 110,
        }
 
      },
      errorElement: "span",
      errorClass: "help-inline",
    });
 
});
</script>
    
</body>
</html>
