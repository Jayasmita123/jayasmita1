<?php
include("Db_Conn.php");
if(isset($_POST['sale_submit']) || isset($_POST['purchase_submit']) || isset($_POST['rent_submit']) || isset($_POST['lease_submit']){
    
    $customer_id = $_POST['customer_id'];
    $manager_id = $_POST['manager_id'];
    $manager_name = $_POST['manager_name'];
    $entry_date = date("Y-m-d H:i:s");
    $assign_md = "1";
    
    $name = $_POST['owner_name'];
    $phone = $_POST['owner_phone'];
    $email = $_POST['owner_email'];
    $property = $_POST['property'];
    $property_type = $_POST['property_type'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $landmark = $_POST['landmark'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $country = $_POST['country'];
    $floor = $_POST['floor'];
    $bhk = $_POST['bhk'];
    $furnished = $_POST['furnished'];
    $water = $_POST['water_supply'];
    $power = $_POST['power_supply'];
    $take_care = $_POST['take_care'];
    $add_info = implode(",",$_POST['add_info']);
    $remarks = $_POST['remarks'];
    $type = $_POST['type'];
    $price = $_POST['price_min']."-".$_POST['price_max'];
    
        $insert = "INSERT INTO `ajrealty_building_survey`(`customer_id`, `manager_id`, `manager_name`, `type`, `owner_name`, `owner_phone`, `owner_email`, `property`, `property_type`, `price`, `bhk`, `furnished`, `water_supply`, `power_supply`, `take_care_property`, `additional_information`, `address_line1`, `address_line2`, `floor_number`, `landmark`, `city`, `district`, `state`, `country`, `pincode`, `entry_date`) VALUES ('$customer_id','$manager_id','$manager_name','$type','$name','$phone','$email','$property','$property_type','$price','$bhk','$furnished','$water',$power','$take_care','$add_info','$address_line1','$address_line2','$floor','$landmark','$city','$district','$state','$country','$pincode','$entry_date')";
        $res = mysqli_query($conn,$insert);
        if($res){
            $sql = "SELECT * FROM `ajrealty_building_survey` WHERE `owner_phone`='$phone' AND `owner_email`='$email' AND `customer_id`='$customer_id' AND `property`='$property' ORDER BY `Sl.No` DESC LIMIT 1";
            
            $sqlcon = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($sqlcon);
            $slno = $row['Sl.No'];
            $survey_id = "survey".$slno;
            
            $update = "UPDATE `ajrealty_building_survey` SET `survey_id`='$survey_id' WHERE `owner_phone`='$phone' AND `owner_email`='$email' AND `customer_id`='$customer_id' AND `property`='$property'";
            $updcon = mysqli_query($conn,$update);
            if($updcon){
                $message = "Manager <b>".$manager_name."</b> has been taken survey for the customer id ".$customer_id;
                
                $qry = mysqli_query($conn,"INSERT INTO `notification_status`(`staff_id`, `staff_name`, `assigned_staff_id`, `message`, `role`, `status`, `entry_date`) VALUES ('$manager_id','$manager_name','$assign_md','$message','managing director',0,'$entry_date')");
                echo "<script>alert('Successfully inserted');window.location='customer_building_survey.php';</script>";
            }else{
                echo "<script>alert('failed');window.location='customer_building_survey.php';</script>";
            }
            
    /*function customer_id_generate(){
        $result = substr($string, 0, 5);
    }
    function random_username($string) {
        $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0,3);
        $nrRand = rand(0, 100);

        $username = trim($firstPart).trim($nrRand);
        return $username;
    }*/
}
?>