<?php
include('Db_Conn.php'); 

$sql="UPDATE notification SET status=1 WHERE status=0 AND role='Manager'";	
$result=mysqli_query($conn, $sql);

$sql="select * from notification WHERE role='Manager' ORDER BY `Sl.No` DESC limit 5";
$result=mysqli_query($conn, $sql);

$response='';

while($row=mysqli_fetch_array($result)) {
    
    $date=date('d-m-Y h:i A', strtotime($row["notify_date"]));
    
    $response = $response . 
	'<a class="dropdown-item" href="notification_view.php">' .  $row["Subject"]  . '<br>' . $date  . '</a>';
	/*'<li class="notification-item"><a href="notification_view.php">' .  $row["Subject"]  . '<br>' . $date  . '</a></li>';*/
	
}

if(!empty($response)) {
	print $response;
}
?>