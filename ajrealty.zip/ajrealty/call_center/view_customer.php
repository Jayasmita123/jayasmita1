<?php
include("../Db_Conn.php");
session_start();
date_default_timezone_set("Asia/Kolkata");
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
 
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $staff_name = $row['staff_name'];
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Page-->
    <title>AJREALTY</title>
    <link href="../css/form.css" rel="stylesheet">
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <style>
table {
    border-collapse: collapse;
    width:100%;
    margin-top: 10px;
}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #7791c7; 
	}

th { 
	background: #3b5998; 
	color: white; 
	font-weight: bold;
	text-align:left;
	align-items:center;
	height:40px;
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	font-size: 16px;
	width:auto;
	line-height:1.2;
	}
	td{
	    text-align: left; 
	}

h4{
    color:#b224ef;
    text-align:left;
}
  

	@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	#table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	#table, #thead, #tbody,#th, #td, #tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	#thead #tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	#tr { border: 1px solid #ccc; }
	
	#td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	#td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);
		color: #000;
		font-weight: bold;
	}
}
.container {
  width: 100%;
  max-width: 1400px;
  text-align: left;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  margin: 0 auto; /* center hack */
  padding: 20px;
}

    </style>
</head>
    <body>
    <?php
        include("nav.php");
    ?>
        <!--display staff id in span to get customer details using ajax-->
        <span hidden id="staffid"><?php echo $staff_id;?></span>
    <div class="container">
    <table id="customer">
        <thead>
            <tr>
                <th>Sl.No</th>
                <th>Customer Name</th>
                <th>Phone Number</th>
                <th>Alternate phone</th>
                <th>Residence phone</th>
                <th>Office phone number</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $sel = "SELECT * FROM `ajrealty_callcenter` WHERE staff_id='$staff_id'";
            $con = mysqli_query($conn,$sel);
            $i = 1;
            while($row = mysqli_fetch_array($con)){
            $cus_id=$row['customer_id']; 
            $prop_id = $row['property_id'];

            $query3 = "SELECT * FROM `ajrealty_customer` JOIN `ajrealty_survey` WHERE `ajrealty_customer`.`customer_id`='$cus_id' AND `ajrealty_survey`.`customer_id`='$cus_id' AND `ajrealty_survey`.`property_id`='$prop_id' AND `ajrealty_survey`.`property_status`='0'";
            $sql1 = mysqli_query($conn,$query3);
            if(mysqli_num_rows($sql1) > 0){
            $fetch=mysqli_fetch_array($sql1);
                $cust_name=$fetch['customer_name'];
                $customer_phone=$fetch['customer_phone'];
                $alternative_phone=$fetch['alternative_phone'];
                $residence_phone=$fetch['residence_phone'];
                $office_phone=$fetch['office_phone'];
                
    ?>
            <tr>
                <td hidden><?php echo $cus_id;?></td>
                <td hidden><?php echo $prop_id;?></td>
                <td><?php echo $i;?></td>
                <td><?php echo $cust_name;?></td>
                <td><?php echo $customer_phone;?></td>
                <td><?php echo $alternative_phone;?></td>
                <td><?php echo $residence_phone;?></td>
                <td><?php echo $office_phone;?></td>
                <td><input type="button" value="View and add remarks" class="button"></td>
            </tr>
        <?php
                $i++;
             }
            }
            ?>
         
        </tbody>
    </table>
    </div>
        <?php
            include("footer.php");
            ?>
        <script>
        
        var table = document.getElementById('customer');
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {
                        var cid = this.cells[0].innerHTML;
                        var pid = this.cells[1].innerHTML;
                        window.location='view_remarks.php?customer_id='+cid+'&property_id='+pid;
                };
            }

</script>
        
<script>
    
$(document).ready(function(){
  $('.popup-btn').click(function(){ 
    var popupBlock = $('#'+$(this).data('popup'));
    popupBlock.addClass('active')
      .find('.fade-out').click(function(){
        popupBlock.css('opacity','.5').find('.popup-content').css('margin-top','350px');        
        setTimeout(function(){
          $('.popup').removeClass('active');
          popupBlock.css('opacity','').find('.popup-content').css('margin-top','');
        }, 100);
      });
 });
});
    </script>
    
    <script>
$(document).ready(function(){
  $('#close').click(function(){
        
          $('.popup').removeClass('active');
          
      });
 });
    </script>
        
<script>  
$(document).ready(function(){

    var staff_id = document.getElementById('staff_id').innerHTML;
    var dataString = 'staff_id='+ staff_id;
    
        $.ajax({
            type: "POST",
            url: "fetch_customer_data.php",
            cache: false,
            data: dataString,
            success: function (response) {
                document.getElementById("notify_list").innerHTML=response;
              }
           });    
});   
 </script>
    </body>
</html>