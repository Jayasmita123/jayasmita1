<?php
include('../Db_Conn.php');
$staff_id = $_POST['staff_id']; 
$curdate = date('Y-m-d');
$tomdate = date('Y-m-d', strtotime('+1 day'));
$sel = "SELECT `customer_id` FROM `ajrealty_callcenter` WHERE `next_call_date` BETWEEN '$curdate' AND '$tomdate'";
$con = mysqli_query($conn,$sel);
if($con){
    while($row = mysqli_fetch_array($con)){
        
        $customer_id = $row['customer_id'];
        
    $qry1 = "SELECT `customer_name`,`customer_phone` FROM `ajrealty_customer` WHERE `customer_id`='$customer_id'";
    $res1 = mysqli_query($conn,$qry1);
    $fetch1 = mysqli_fetch_array($res1);
    $customer_name = $fetch1['customer_name'];
    $customer_phone = $fetch1['customer_phone'];
?>
<li>
    <a href="view_remarks.php?customer_id=<?php echo $customer_id;?>">
        Customer details: 
        <h5><?php echo $customer_name;?></h5>
        <h5><?php echo $customer_phone;?></h5>
        <button class="button">View and call</button>
    </a>
</li>
<?php
    }
}
?>