<?php
include('../Db_Conn.php');
$staff_id = $_POST['staff_id'];
$data = array();

$sel = "SELECT * FROM `ajrealty_callcenter` WHERE staff_id='$staff_id'";
$con = mysqli_query($conn,$sel);
while($row = mysqli_fetch_array($con)){
$cus_id=$row['customer_id']; 

$query3 = "SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$cus_id'";
$sql1 = mysqli_query($conn,$query3);
if($sql1){
$fetch=mysqli_fetch_array($sql1);
    $cust_name=$fetch['customer_name'];
    $customer_phone=$fetch['customer_phone'];
    $alternative_phone=$fetch['alternative_phone'];
    $residence_phone=$fetch['residence_phone'];
    $office_phone=$fetch['office_phone'];
    
    $data[] = array("cust_name" => $cust_name,"cust_phone"=>$customer_phone,"alter_phone"=>$alternative_phone,
                   "res_phone"=>$residence_phone,"off_phone"=>$office_phone,"cus_id"=>$cus_id);
 }
}
echo json_encode($data);
?>