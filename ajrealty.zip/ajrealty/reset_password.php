<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Real Estate</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg4.png');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="reset_password.php" method="post">
					<span class="login100-form-logo">
						<img src="images/logo.jpg" height="80" width="80">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Login
					</span>

					<div class="wrap-input100" data-validate = "Enter OTP">
						<input class="input100" type="text" name="otp" placeholder="OTP" maxlength="6" required>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="wrap-input100" data-validate="Enter new password">
						<input class="input100" type="password" name="new_password" placeholder="New Password" required>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<a class="txt1" href="login.php">
							Don't want to reset password? Back to login
						</a>
					</div>

					<div class="container-login100-form-btn">
						<input type="submit" name="reset" value="Reset Password" class="login100-form-btn">
					</div>
				</form>
			</div>
		</div>
	</div>

<?php
include("Db_Conn.php");
if(isset($_POST['email']) && isset($_POST['otp']) && isset($_POST['new_password'])){
// array for JSON response
$response = array();
date_default_timezone_set("Asia/Kolkata");
  $curDate = date("Y-m-d H:i:s");

    $otp = $_POST['otp'];
    $new_pwd = md5($_POST['new_password']);
    $email = $_POST['email'];
    $time = $_POST['time'];
 
    $sel = "SELECT * FROM real_estate_login WHERE `otp`='$otp' AND `email`='$email' AND `expiry_date` >= '$curDate'";
    $res = mysqli_query($conn,$sel);
    
    if(mysqli_num_rows($res) > 0){
        
    $sql = "UPDATE `real_estate_login` SET `password`='$new_pwd' WHERE `otp`='$otp' AND `email`='$email'";
    $result = mysqli_query($conn,$sql);
    
    if ($result == "TRUE") {
       
        echo "<script>
  swal({
    title: 'Password reset successfully',
    type: 'success',
  }).then(function() {
    window.location = 'login.php';
});
        </script>";
        
    } 
}else {
         echo "<script>
  swal({
    title: 'OTP is invalid / expired',
    type: 'error',
  }).then(function() {
    window.location = 'login.php';
});
        </script>";
       
    }
}
?>
</body>
</html>