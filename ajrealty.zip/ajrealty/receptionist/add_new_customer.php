<?php
include("../Db_Conn.php");
session_start();
date_default_timezone_set("Asia/Kolkata");
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $manager_id = $_SESSION['staff_id'];
 $manager_phone = $_SESSION['staff_phone'];
    
    
    $sql = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$manager_id'";
    $con = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($con);
    $manager_name = $row['staff_name'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>
    <!--input validation using js-->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
	<style type="text/css">
		#address_information,#inspection_information,#property_information,
        #property_information_land,#price_information,#facility_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
        input[type="checkbox"]{
            padding-right: 20px;
        }
	</style>
</head>

<body>
     <?php
        include("nav.php");
        ?>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Details of the property - owner</h2>
                    <form method="POST" action="add_new_customer_insert.php" id="myform">
                       
                        <fieldset id="basic_information" class="">
                            
                            <input type="hidden" name="manager_id" value="<?php echo $manager_id;?>">
                            <input type="hidden" name="manager_name" value="<?php echo $manager_name;?>">
                            
                            <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Property
                                <select name="property" id="property" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Residential">Residential</option>
                                    <option value="Commercial">Commercial</option>
                                    <option value="Land">Land</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Rental/sale
                                <select name="type" id="type" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Rental">Rental</option>
                                    <option value="Sale">Sale</option>
                                    <option value="Purchase">Purchase</option>
                                    <option value="Lease">Lease</option>
                                </select>
                                </div>
                                </div>
                                <div class="col-3">
                            <div class="input-group">Property Type
                                <select name="property_type" id="property_type" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                </select>
                            </div>
                        </div>
                            
                        </div>
                            <h5>Basic Information</h5>
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Name
                                    <input class="input--style-2" type="text" placeholder="Property Owner Name" name="owner_name" id="owner_name">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Email-id
                                    <input class="input--style-2" type="text" placeholder="Property owner email" name="owner_email" id="owner_email" onblur="mailExist()">
                                    <span id="exist_eml"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Owner Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer Phone" name="owner_phone" id="owner_phone" maxlength="10" onblur="phoneExist()">
                                    <span id="exist_ph"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Alternate Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer alternate phone" name="alt_phone" id="alt_phone" maxlength="10">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Owner Residential Number
                                    <input class="input--style-2" type="number" placeholder="Residential Phone" name="residential" id="residential">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Owner Office Number
                                    <input class="input--style-2" type="number" placeholder="Office Phone" name="off_phone" id="off_phone">
                                </div>
                            </div>
                        </div>
                            <div class="row row-space">
                             <div class="col-2">
                                <div class="input-group">Occupation
                                    <input class="input--style-2" type="text" placeholder="Occupation" name="occupation" id="occupation">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Gender
                                    <select name="gender" class="input--style-2" id="gender">
                                        <option value="">Select Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                            <h4>Owner Address</h4>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address Line-1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                               
                            </div>
                             <div class="col-2">
                                
                                <div class="input-group">Address Line-1
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                            
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Street" name="street" id="street">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark" id="landmark">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city" id="city">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode/Zip
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <h4>Property Address</h4>
                            <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="same_addr" value="yes" name="check"> Property address is same as customer residential/current address
                                </div>
                            <div id="prop_adr">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address1_prop" id="address1prop">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address2_prop" id="address2_prop">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Street" name="streetprop" id="street_prop">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmarkprop" id="landmark_prop">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="cityprop" id="city_prop">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode/Zip
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincodeprop" id="pincode_prop">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Country
                               <select name="countryprop" id="countrySel" size="1" class="input--style-2">
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">State
                                <select name="stateprop" id="stateSel" size="1" class="input--style-2">
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">District
                               <select name="districtprop" id="districtSel" size="1" class="input--style-2">
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                                </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                          </div>
                        </fieldset>
                        
                          <!--tab 5-->
                        <fieldset id="inspection_information" class="">
                            <div class="row row-space">
                                <div class="col-3">
                                <div class="input-group">Inspected
                                   <select name="inspected" id="inspected" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                                <div class="col-3">
                                <div class="input-group">Listed
                                   <select name="listed" id="listed" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                                <div class="col-3">
                                <div class="input-group">HRR Board
                                   <select name="hrrboard" id="hrrboard" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Keys Collected
                                   <select name="keys" id="keys" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Website Hosting
                                   <select name="website" id="website" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Servant Qtrs
                                   <input class="input--style-2" type="text" placeholder="Servant Qtrs" name="servant_qtrs">
                                </div>
                            </div>
                        </div>
                        <h5>Contact person for inspection/Keys:</h5><br>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name/Address:
                                    <input class="input--style-2" type="text" placeholder="Name/Address" name="key_name" id="key_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Phone
                                    <input class="input--style-2" type="number" placeholder="Phone" name="key_phone" id="key_phone">
                                </div>
                            </div>
                             <div class="col-3">
                            <div class="input-group">Email
                               <input class="input--style-2" type="text" placeholder="Email" name="key_email" id="key_email">
                            </div>
                            </div>
                        </div>
                        <div class="row row-space" id="leasediv">
                            <div class="col-2">
                                <div class="input-group">Lease type
                                    <input class="input--style-2" type="text" placeholder="Lease type" name="lease_type" id="lease_type">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Lease period
                                    <input class="input--style-2" type="text" placeholder="Lease Period" name="lease_period" id="lease_period">
                                </div>
                            </div>
                        </div>
                            <h5>Source:</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Company" name="source[]"> Company
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="HRR Website" name="source[]"> HRR Website
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Quickr" name="source[]"> Quickr
                                </div>
                            </div>
                                <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Paper" name="source[]"> Paper
                                </div>
                            </div>
                             <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Magic Bricks" name="source[]"> Magic Bricks
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Cold Call" name="source[]"> Cold Call
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="source" value="99 Acres" name="source[]"> 99 Acres
                                </div>
                            </div>
                             <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="source" value="Just dial" name="source[]"> Just dial
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="other" value="Others" name="other"> Others
                                </div>
                            </div>
                            <div class="col-4" id="other_val">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="source" placeholder="Enter other source" name="source[]">
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--residential tab 6-->
                        <fieldset id="property_information" class="">
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Name of Building/Home
                                    <input class="input--style-2" type="text" placeholder="Building Name" name="building_name" id="building_name">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Architect Name
                                    <input class="input--style-2" type="text" placeholder="Architect Name" name="architect_name" id="architect_name">
                                </div>
                            </div>
                           <div class="col-3">
                            <div class="input-group">Builder's Name
                               <input class="input--style-2" type="text" placeholder="Builder's Name" name="builders_name" id="builders_name">
                            </div>
                        </div> 
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Age of building
                               <input class="input--style-2" type="number" placeholder="Age of building" name="building_age" id="building_age">
                            </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Built up area
                                    <input class="input--style-2" type="text" placeholder="Built up area" name="built_area">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">No.of Floors
                                    <input class="input--style-2" type="text" placeholder="floors" name="floors" id="floors">
                                </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-3" id="res_bedroom">
                                <div class="input-group">Bedrooms
                                    <input class="input--style-2" type="text" placeholder="Number of Bedrooms" name="bedrooms">
                                </div>                                
                            </div>
                            <div class="col-3" id="com_room">
                                <div class="input-group">Rooms
                                    <input class="input--style-2" type="text" placeholder="Number of Rooms" name="rooms">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Bathrooms
                                    <input class="input--style-2" type="text" placeholder="Total bathrooms" name="bathroom" id="bathroom">
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Flooring
                               <input class="input--style-2" type="text" placeholder="Flooring" name="flooring" id="flooring">
                            </div>
                            </div>
                        </div>
                             <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Generator
                               <select name="generator" id="generator" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                               <div class="input-group">Furnished
                                <select name="furnished" id="furnished" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Fully">Fully</option>
                                    <option value="Semi">Semi</option>
                                    <option value="Not furnished">Not furnished</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                            <div class="input-group">Power Supply
                               <select name="power_supply" id="power_supply" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <fieldset id="facility_information" class="">
                        <div class="row row-space">
                            <div class="col-3">
                            <div class="input-group">Elevators
                                <select name="elevators" id="elevators" id="power_supply" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Garden/Terrace
                                <select name="garden" id="garden" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Garden">Garden</option>
                                    <option value="Terrace">Terrace</option>
                                    <option value="Both">Both</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                                <div class="col-3">
                            <div class="input-group">Car park
                               <select name="car_park" id="car_park" size="1" class="input--style-2">
                                    <option value="">Select </option>
                                    <option value="Covered">Covered</option>
                                    <option value="Open">Open</option>
                                   <option value="No">No</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="row row-space" id="tot_flat">
                            <div class="col-2">
                                <div class="input-group">Total Number of Flats
                                    <input class="input--style-2" type="text" id="flats" placeholder="Total flats" name="flats">
                                </div>
                            </div>
                        </div>
                        <h5>Water Facility</h5><br>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Metro" name="water[]"> Metro
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="water" value="Borewell" name="water[]"> Borewell
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="water" value="Tanker" name="water[]"> Tanker
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2 waterval" type="checkbox" id="water" value="Others"> Others
                                </div>
                            </div>
                            <div class="col-4 water_other">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="water" name="water[]">
                                </div>
                            </div>
                        </div>
                            <h5 id="ament_text">Amenities</h5><br>
                            <div id="ament">
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Club House" name="amenities[]"> Club House
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Swimming Pool" name="amenities[]"> Swimming Pool
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Gym" name="amenities[]"> Gym
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Children Play Area" name="amenities[]"> Children's Play Area
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Indoor Games" name="amenities[]"> Indoor Games
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="WIFI" name="amenities[]"> WIFI
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Walking Track" name="amenities[]"> Walking Track
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                    <input class="input--style-2" type="checkbox" id="amenities" value="Multipurpose Hall" name="amenities[]"> Multipurpose Hall
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenities" value="Tennis Court" name="amenities[]"> Tennis Court
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="input-group">
                                   <input class="input--style-2" type="checkbox" id="amenitiesval" value="Others"> Others
                                </div>
                            </div>
                            <div class="col-4 amenties_other">
                                <div class="input-group">
                                    <input class="input--style-2" type="text" id="amenities" name="amenities[]">
                                </div>
                            </div>
                        </div>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="button" class="btn btn--radius btn--submit next">Next</button>
                            </div>
                        </fieldset>
                        
                        <!--for land tab4-->
                        <fieldset id="property_information_land" class="">
                        <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Land Area / UDS
                                    <input class="input--style-2" type="text" placeholder="Land area" name="land_area" id="land_area">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Land value/sq.ft
                                    <input class="input--style-2" type="text" placeholder="land value per sq.ft" name="land_sqft" id="land_sqft">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                        <div class="col-3">
                            <div class="input-group">price
                               <input class="input--style-2" type="number" placeholder="Amount" name="landprice" id="landprice">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">Exclusive Listing From
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing from" name="exclusive_from1" id="exlusive_from1">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">To
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing to" name="exclusive_to1" id="exclusive_to1">
                            </div>
                        </div>
                        </div>
                             <div class="row row-space">
                            <div class="col-2">
                               <div class="input-group">Maintenance
                                    <input class="input--style-2" type="text" placeholder="Maintenance" name="maintenance1" id="maintenance1">
                                </div>
                            </div><div class="col-2">
                               <div class="input-group">Deposit
                                    <input class="input--style-2" type="text" placeholder="Deposit" name="deposit1" id="deposit1">
                                </div>
                            </div>
                        </div>
                             <div class="input-group">Brief Description of the proprty/Additional Information/Realtor's Remarks (20 to 500 characters):
                                <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks1" id="remarks1" minLength="20" maxLength="500"></textarea>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit">Submit</button>
                            </div>
                        </fieldset>
                        
                        <!--tab 6-->
                        <fieldset id="price_information" class="">
                        <div class="row row-space">
                        <div class="col-3">
                            <div class="input-group">Price
                               <input class="input--style-2" type="number" placeholder="Amount" name="price" id="price">
                            </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Rate per sq.ft
                                    <input class="input--style-2" type="text" placeholder="Rate per sq.ft" name="rate_sqft" id="rate_sqft">
                                </div>
                            </div>
                            <div class="col-3">
                               <div class="input-group">Maintenance
                                    <input class="input--style-2" type="text" placeholder="Maintenance" name="maintenance" id="maintenance">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                               <div class="input-group">Deposit
                                    <input class="input--style-2" type="text" placeholder="Deposit" name="deposit" id="deposit">
                                </div>
                            </div>
                                 <div class="col-3">
                            <div class="input-group">Exclusive Listing From
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing from" name="exclusive_from" id="exlusive_from">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="input-group">Exclusive Listing To
                               <input class="input--style-2" type="text" placeholder="Exclusive Listing to" name="exclusive_to" id="exclusive_to">
                            </div>
                        </div>
                        </div>
                             <div class="input-group">Brief Description of the proprty/Additional Information/Realtor's Remarks (20 to 500 characters):
                                <textarea class="input--style-2" type="text" placeholder="Remarks" name="remarks" id="remarks" minLength="20" maxLength="500"></textarea>
                            </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit previous">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit">Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
      <?php
            include("footer.php");
            ?>
   <script type="text/javascript">
		$(document).ready(function(){
			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            
			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						owner_name: {
							required: true,
							usernameRegex: true,
						},
						owner_phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
                        alt_phone : {
							phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
                        key_email:{
                            emailRegex: true,
                        },
                        key_name:{
                            usernameRegex: true,
                        },
                        key_phone:{
                            phoneRegex: true,
                        },
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						owner_email: {
                            emailRegex: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        remarks:{
                            required: true,  
                        },
                        price:{
                            required: true,  
                        },
                        property:{
                            required: true,  
                        },
                        type:{
                            required: true,  
                        },
                        property_type:{
                            required: true,  
                        },
                        lease_type:{
                            required: true, 
                        },
                        lease_period:{
                            required: true,  
                        },
                        gender:{
                            required: true,  
                        }, 
					},
                    messages: {
						
						owner_phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						owner_name: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        remarks:{
                            required: "required", 
                        },
                        price:{
                            required: "required", 
                        },
                        property:{
                            required: "required", 
                        },
                        type:{
                            required: "required", 
                        },
                        property_type:{
                            required: "required",  
                        },
                        lease_type:{
                            required: "required",  
                        },
                        lease_period:{
                            required: "required",  
                        },
                        gender:{
                            required: "required",  
                        },
                        
					}
				});
				if (form.valid() === true){
                 if($('#property').val() == 'Land' && $('#type').val() == 'Purchase'){
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#property_information_land');
					}
                }else if($('#type').val() == 'Purchase'){
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#price_information');
					}
                }else if($('#property').val() == 'Land'){
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information_land');
					}
                }else {
                   if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#inspection_information');
					}else if($('#inspection_information').is(":visible")){
						current_fs = $('#inspection_information');
						next_fs = $('#property_information');
					}else if($('#property_information').is(":visible")){
						current_fs = $('#property_information');
						next_fs = $('#facility_information');
					}else if($('#facility_information').is(":visible")){
						current_fs = $('#facility_information');
						next_fs = $('#price_information');
					}
                }
                
					next_fs.show();
					current_fs.hide();
				}
			});

			$('.previous').click(function(){
                if($('#property').val() == 'Land' && $('#type').val() == 'Purchase'){
                    
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#property_information_land').is(":visible")){
                        current_fs = $('#property_information_land');
                        next_fs = $('#address_information');

                    }
                        
                }else if($('#type').val() == 'Purchase'){
                    
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#price_information').is(":visible")){
                        current_fs = $('#price_information');
                        next_fs = $('#address_information');

                    }
                        
                }else if($('#property').val() == 'Land'){
                    
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#inspection_information').is(":visible")){
                        current_fs = $('#inspection_information');
                        next_fs = $('#address_information');

                    }else if ($('#property_information_land').is(":visible")){
                        current_fs = $('#property_information_land');
                        next_fs = $('#inspection_information');

                    }
                        
                }else {
                    if($('#address_information').is(":visible")){
                        current_fs = $('#address_information');
                        next_fs = $('#basic_information');
                    
                    }else if ($('#inspection_information').is(":visible")){
                        current_fs = $('#inspection_information');
                        next_fs = $('#address_information');

                    }else if ($('#property_information').is(":visible")){
                        current_fs = $('#property_information');
                        next_fs = $('#inspection_information');

                    }else if ($('#facility_information').is(":visible")){
                        current_fs = $('#facility_information');
                        next_fs = $('#property_information');

                    }else if ($('#price_information').is(":visible")){
                        current_fs = $('#price_information');
                        next_fs = $('#facility_information');

                    }
                }
				
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script>
    
    <script> 
$('#same_addr').click(function(){  
if($(this).is(":checked")) {
    $("#prop_adr").hide();
} else {
    $("#prop_adr").show();
}
});   
 </script>
    
<!--display property type onchange property-->
<script>  
$('#property').change(function(){  
          
    var property = $(this).val();
    var dataString = 'property='+ property;
    
        $.ajax({
            type: "POST",
            url: "fetch_property_type.php",
            cache: false,
            data: dataString,
            success: function (response) {
            document.getElementById("property_type").innerHTML=response; 
              }
        });  
});   
 </script>
    <!--water onclick other display input -->
<script>
    $("#other_val").hide();
    $("#other").click(function() {
    if($(this).is(":checked")) {
        $("#other_val").show();
    } else {
        $("#other_val").hide();
    }
});
</script>
    <!--if type is lease show lease type and period text field-->
<script>
$("#leasediv").hide();
    $("#type").change(function() {
    if($(this).val() == 'Lease') {
        $("#leasediv").show();
    } else {
        $("#leasediv").hide();
    }
});
</script>
    <!--onclick water facility other option show other text field-->
<script>
    $(".water_other").hide();
    $(".waterval").click(function() {
    if($(this).is(":checked")) {
        $(".water_other").show();
    } else {
        $(".water_other").hide();
    }
});
    </script>
    <!--onclick amenities other option show other text field-->
<script>
    $(".amenties_other").hide();
    $("#amenitiesval").click(function() {
    if($(this).is(":checked")) {
        $(".amenties_other").show();
    } else {
        $(".amenties_other").hide();
    }
});
    </script>
<!--onchange property_type hide/show flats & amenities field-->
    <script>
$('#property_type').change(function(){  
          
    var type = $(this).val();
    
    if(type == 'Flat'){
        $("#ament").show();
        $("#ament_text").show();
        $("#tot_flat").show();
    }else{
        $("#ament").hide();
        $("#ament_text").hide();
        $("#tot_flat").hide();
    }
    
});   
 </script>
    <!--onchange property hide/show bedroom/room-->
    <script>
$('#property').change(function(){  
          
    var property =$(this).val();
    
    if(property == 'Residential'){
        $("#res_bedroom").show();
        $("#com_room").hide();
        
    }else if(property == 'Commercial'){
        $("#res_bedroom").hide();
        $("#com_room").show();
    }

});   
 </script>
  <!--check phone number already existed or not-->
<script>  
$function phoneExist() {
    var phone = document.getElementById("owner_phone").value;
    var dataString = 'phone='+ phone;

        $.ajax({
            type: "POST",
            url: "check_user_exist.php",
            cache: false,
            data: dataString,
            success: function (response) {
                if (response == 'exist' ) {
                  var text = 'Sorry... phone number already taken';
                    document.getElementById("exist_ph").innerHTML=text; 
                }else if (response == 'not_exist') {
                   var text = 'Sorry... phone number already taken';
                   document.getElementById("exist_ph").innerHTML=text;  
                }
              }
        });  
}   
 </script>  
    <!--check email already existed or not-->
<script>  
$function mailExist() {
    var email = document.getElementById("owner_email").value;
    var dataString = 'email='+ email;

        $.ajax({
            type: "POST",
            url: "check_user_exist.php",
            cache: false,
            data: dataString,
            success: function (response) {
                if (response == 'exist' ) {
                  var text = 'Sorry... email already existed';
                    document.getElementById("exist_eml").innerHTML=text; 
                }else if (response == 'not_exist') {
                   var text = 'Sorry... email already existed';
                   document.getElementById("exist_eml").innerHTML=text;  
                }
              }
        });  
}   
 </script>
    
 <!--begin disable enter key-->
   <script>
    document.getElementById("form").onkeypress = function(e) {
  var key = e.charCode || e.keyCode || 0;     
  if (key == 13) {
    e.preventDefault();
  }
}
</script> 
<!--end disable enter key-->
</body>
</html>