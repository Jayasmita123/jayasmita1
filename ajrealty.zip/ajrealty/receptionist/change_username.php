<?php
include("../Db_Conn.php");
session_start();
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>AJREALTY</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
<!--===============================================================================================-->
  
</head>
<body>

	<div class="limiter">
		<div class="container-login100" style="background-image: url('../images/bg4.png');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="change_username.php" method="post">
					<span class="login100-form-logo">
						<img src="../images/logo.png" height="80" width="80">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Change Username
					</span>

					<div class="wrap-input100" data-validate = "Enter new username">
						<input class="input100" type="text" name="usrname" placeholder="New Username" pattern="[a-zA-z0-9]{1,}" title="enter only characters and numbers" required>
                        
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="wrap-input100" data-validate="Enter current password">
						<input class="input100" type="password" name="cur_pwd" placeholder="Current Password" required>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<a class="txt1" href="index.php">
							Back to main page
						</a>
					</div>

					<div class="container-login100-form-btn">
						<input type="submit" name="change" value="Change" class="login100-form-btn">
					</div>
				</form>
			</div>
		</div>
	</div>

<?php
if(isset($_POST['change'])){

    $cpwd=$_POST['cur_pwd'];
    $usrname=$_POST['usrname'];
    
    $user_check_query = "SELECT * FROM `real_estate_login` WHERE `password`='$cpwd' AND `user_id`='$staff_id'";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['password'] == $cpwd && $user['user_id'] == $staff_id) {
     
        $sql="UPDATE `real_estate_login` SET `username`='$usrname' WHERE `password`='$cpwd' AND `user_id`='$staff_id'";
    $res=mysqli_query($conn,$sql);
    
    if($res){
         session_destroy();
         echo "<script>alert('Username changed Sucessfully');window.location = '../login.php';</script>";
    }else{
         echo "<script>alert('Username not changed');window.location = 'change_username.php';</script>";
    }
    
    }

  } else {
      echo "<script>alert('Password not matched with username');window.location = 'change_username.php';</script>";
  }
}
?>
</body>
</html>