        <?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}
?>
<?php
        require_once("../Db_Conn.php");      
        if(isset($_POST['submit']))
        {
            $staff_id=$_SESSION['staff_id'];
            $sphone=$_POST['contact']; 
            $salt_phone=$_POST['alt_phone']; 
            $semail=$_POST['email'];
            $add1=$_POST['add1']; 
            $add2=$_POST['add2'];
            $country=$_POST['country'];
            $state=$_POST['state']; 
            $street=$_POST['street']; 
            $district=$_POST['district'];
            $city=$_POST['city'];
            $pincode=$_POST['pincode']; 
            $landmark=$_POST['landmark'];
            $up="UPDATE ajrealty_staffs SET staff_phone='$sphone',staff_alternate_phone='$salt_phone', staff_email='$semail', staff_address_line1='$add1', staff_address_line2='$add2', street='$street', staff_landmark='$landmark', staff_city='$city', staff_district='$district', staff_state='$state',staff_country='$country',staff_pincode='$pincode' WHERE staff_id='$staff_id'";
            $res=mysqli_query($conn, $up);
            if($res)
              {
           echo "<script>alert('updated.. ');</script>";
              }
            else
            {
           echo "<script>alert('retry...');</script>";
            }      
        } 
?>
<?php

        $staff_id=$_SESSION['staff_id'];
         $role=$_SESSION['role'];
        $display="SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
         $c=mysqli_query($conn, $display);
         $n=mysqli_num_rows($c);
         if($n==0)
         {
             echo"No data found";
         }
        else
        {
           while($fe= ($c->fetch_assoc()))
        {     
 
            $phone=$fe['staff_phone'];
            $exp=$fe['staff_experience'];
            $alt_phone=$fe['staff_alternate_phone'];
            $email=$fe['staff_email'] ; 
            $add1=$fe['staff_address_line1'] ; 
            $add2=$fe['staff_address_line2'] ; 
            $street=$fe['street'];
            $city=$fe['staff_city'] ; 
            $land=$fe['staff_landmark'] ; 
            $district=$fe['staff_district'] ; 
            $state=$fe['staff_state'] ; 
            $country=$fe['staff_country'] ; 
            $pincode=$fe['staff_pincode'] ;  
?>

<html>
    <head>
    <title>Edit Profile</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="../js/country_state_district_dropdown.js"></script>
        <!--input validation--->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
        
   <style type="text/css">
		#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
	</style> 
    </head>
    <body>
        <?php include("nav.php"); ?>
     <div class="page-wrapper p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">MY PROFILE</h2>
                    <form action="edit_profile.php" method="POST" id="myform" enctype="multipart/form-data">
                           <fieldset id="basic_information" class="">
                           <div class="row row-space">
                               <div class="col-3">
                                <div class="input-group">Contact Number
                                    
                                 <input class="input--style-2"  type="number" id="phone" placeholder="Phone Number"   name="contact" value="<?php echo"$phone"; ?>" required>
                                    <span class="error"></span>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">Alternative Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer alternative phone number" name="alt_phone" id="alt_phone" value="<?php echo"$alt_phone"; ?>" maxlength="10">
                                </div>
                            </div>
                               <div class="col-3">
                                <div class="input-group">Email
                                  <input class="input--style-2" type="text" placeholder="Mail Id" id="email" name="email" value="<?php echo"$email"; ?>" required>
                                    <span class="error"></span>
                                </div>
                            </div>
                        </div>
                           
                               <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="add1" value="<?php echo"$add1"; ?>">
                                    <span class="error"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="add2" value="<?php echo"$add2"; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                           <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="street" id="street" value="<?php echo"$street"; ?>">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark" value="<?php echo"$land"; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                             <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city" value="<?php echo"$city"; ?>">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="text" placeholder="Pincode" maxlength="6" name="pincode" id="pincode" value="<?php echo"$pincode"; ?>">
                                </div>
                            </div>
                             
                        </div>
                        <div class="row row-space">
                           <div class="col-3">
                                <div class="input-group">Country

                            <select class="input--style-2" name="country" id="countrySel_work" size="1">
                            <option value="<?php echo"$country"; ?>" selected="selected"><?php echo"$country"; ?></option>
                            </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">State
                                    <select class="input--style-2" name="state" id="stateSel_work" size="1">
                                    <option value="<?php echo"$state"; ?>" selected="selected"><?php echo"$state"; ?></option>
                                    </select>
                                </div>
                            </div>
                              <div class="col-3">
                            <div class="input-group">District
                                <select class="input--style-2" name="district" id="districtSel_work" size="1">
                                    <option value="<?php echo"$district"; ?>" selected="selected"><?php echo"$district"; ?></option>
                                    </select>
                                </div>
                            </div>
                            </div>
                        
                            <div class="divbtn">
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit" >Submit</button>
                                <a href="index.php" class="btn btn--radius btn--submit" style="text-decoration:none;">Back</a>
                            </div>
                        </fieldset>
          
                    </form>
                    <?php
                }
        }

            ?>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 digit");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([5]{1}[0-9]{5})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
							required: true,
                            emailRegex: true,
						},
                        gender: {
							required: true,
						},
                        occupation: {
							required: true,
						},
                        manager: {
							required: true,
						},
                        address1: {
							required: true,
						},
                        address2: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
						email: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        manager: {
							required: "required",
						},
                        address1: {
							required: "required",
						},
                        address2: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
					}
				});
				
			});

	
			
		});
	</script> 


<?php include("footer.php"); ?>
    </body>
</html>