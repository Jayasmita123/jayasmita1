<?php
require_once("../Db_Conn.php"); 
session_start();
if(isset($_SESSION['staff_id']))
{
    date_default_timezone_set("Asia/Kolkata");
    $entry_date = date("Y-m-d H:i:s");
    
    $role = $_SESSION['role'];
        $staff_id = $_SESSION['staff_id'];
        $staff_phone = $_SESSION['staff_phone'];
    
    $SR="SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
            $sql1 = mysqli_query($conn,$SR);
            
              $row=mysqli_fetch_array($sql1);
              $name= $row['staff_name']; 
} else
{
    header("location: ../login.php");
}

if(isset($_POST['submit1']))
    {
        
         $cid=$_POST['cid'];
         $pid=$_POST['pid'];
         $mid=$_POST['mg_id'];
         $mname=$_POST['mg_name'];
         
            $s1="INSERT INTO `ajrealty_remarks`(`customer_id`,`property_id`, `role`, `staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES('$cid','$pid','receptionist','$staff_id','$name','old customer walkin to meet assigned manager','$entry_date')";
            $chkcon = mysqli_query($conn, $s1);
              
             $sw="INSERT INTO `notification_status`(`customer_id`,`property_id`,`assigned_staff_name`, `assigned_staff_id`, `message`, `role`, `status`, `customer`, `entry_date`, `remark_from`) VALUES('$cid','$pid','$mname','$mid','old customer walkin','manager',0,'old','$entry_date','receptionist')";
            $qrychk = mysqli_query($conn, $sw);
            if($chkcon && $qrychk)
              {
                  echo "<script>alert('Success'); </script>";
              }
            else{
                echo "<script>alert('retry...');/script>";
            } 
     }
?>
     

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <style>
@font-face {
  font-family: "Muli-Regular";
  src: url("../fonts/muli/Muli-Regular.ttf"); }
@font-face {
  font-family: "Muli-SemiBold";
  src: url("../fonts/muli/Muli-SemiBold.ttf"); }
@font-face {
  font-family: "Poppins-Regular";
  src: url("../fonts/poppins/Poppins-Regular.ttf"); }
@font-face {
  font-family: "Poppins-Medium";
  src: url("../fonts/poppins/Poppins-Medium.ttf"); }
* {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box; }

body {
  font-family: "Poppins-Regular";
  font-size: 13px;
  margin: 0;
  color: #999; }

input, textarea, select {
  font-family: "Muli-Regular";
  font-size: 13px;
  color: #666; }

p, h1, h2, h3, h4, h5, h6, ul {
  margin: 0; }

img {
  max-width: 100%; }

ul {
  padding-left: 0;
  margin-bottom: 0; }

a {
  text-decoration: none; }

:focus {
  outline: none; }

.wrapper {
  min-height: 100vh;
  position: relative;
  background: url("../images/bg-registration-form-9.jpg") no-repeat right center;
  background-size: cover; }

.inner {
  position: absolute;
  top: 50%;
  left: 11.07%;
  transform: translateY(-50%);
  width: 380px;
    height: 400px;
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -ms-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -o-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  background: url("../images/bg-inner.png") repeat;
  padding: 7px; }

#form{
  width: 100%;
  padding: 57px 46px 55px;
  background: #fff; }

select {
  -moz-appearance: none;
  -webkit-appearance: none;
  cursor: pointer; }

h3 {
  text-transform: uppercase;
  font-size: 17px;
  font-family: "Poppins-Medium";
  color: #3e91f7;
  letter-spacing: 1px;
  margin-bottom: 22px;
  font-weight: 700; }

.form-row {
  display: flex;
  margin-bottom: 25px; }
  .form-row.last {
    margin-bottom: 22px; }
  .form-row .form-wrapper {
    width: 100%; }
    .form-row .form-wrapper:first-child {
      margin-right: 25px; }

.form-wrapper {
  position: relative; }
  .form-wrapper label {
    display: block;
    font-family: "Muli-SemiBold";
    font-size: 15px;
    color: #4c4c4c;
    margin-bottom: 8px; }
  .form-wrapper i.zmdi-chevron-down {
    position: absolute;
    right: 16px;
    top: 42px;
    font-size: 15px;
    color: #666; }
  .form-wrapper span.lnr-calendar-full {
    position: absolute;
    left: 16px;
    font-size: 15px;
    color: #666;
    top: 43px; }

.form-control {
  border: 1px solid #e6e6e6;
  display: block;
  width: 100%;
  height: 42px;
  padding: 0 14px; }
  .form-control.datepicker-here {
    padding-left: 39px; }

.checkbox {
  position: relative;
  padding-left: 22px; }
  .checkbox label {
    cursor: pointer; }
  .checkbox input {
    position: absolute;
    opacity: 0;
    cursor: pointer; }
  .checkbox input:checked ~ .checkmark:after {
    display: block; }

input[type=submit]
            {
                border: none;
  width: 173px;
  height: 42px;
  margin-top: 30px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  background: #3e91f7;
  color: #fff;
  text-transform: uppercase;
  font-family: "Muli-SemiBold";
  font-size: 15px;
  position: relative;
  transition: all 0.3s ease;
            }

button {
  border: none;
  width: 173px;
  height: 42px;
  margin-top: 30px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  background: #3e91f7;
  color: #fff;
  text-transform: uppercase;
  font-family: "Muli-SemiBold";
  font-size: 15px;
  position: relative;
  transition: all 0.3s ease; }
  button span {
    letter-spacing: 3px;
    -webkit-transition: all 0.3s;
    -moz-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s; }
  button:after {
    content: attr(data-text);
    position: absolute;
    width: 100%;
    height: 100%;
    top: 50%;
    left: 0;
    opacity: 0;
    letter-spacing: 3px;
    -webkit-transform: translate(-30%, -25%);
    transform: translate(-30%, -25%);
    -webkit-transition: all 0.3s;
    -moz-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s; }
  button:hover {
    background: #0072fd; }
    button:hover span {
      opacity: 0;
      -webkit-transform: translate(0px, 40px);
      transform: translate(0px, 40px); }
    button:hover:after {
      opacity: 1;
      -webkit-transform: translate(0, -25%);
      transform: translate(0, -25%); }

@media (max-width: 1199px) {
  .wrapper {
    background-position: center center; } }
@media (max-width: 991px) {
  .inner {
    width: 60%; } }
@media (max-width: 767px) {
  .inner {
    width: 100%;
    transform: translateY(0);
    position: static;
    padding: 0;
    box-shadow: none;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    -ms-box-shadow: none;
    -o-box-shadow: none; }

  .wrapper {
    background: none;
    display: block; }

  form {
    padding: 30px 20px; }

  .form-row {
    display: block; }
    .form-row .form-wrapper {
      width: 100%;
      margin-bottom: 25px; }
      .form-row .form-wrapper:first-child {
        margin-right: 0; } }

/*# sourceMappingURL=style.css.map */

        .wrapper2
            {
/*                float:right;*/
                color: black;
                 position: absolute;
  top: 45%;
  right: 11.07%;
  transform: translateY(-50%);
  width: 380px;
    height: auto;
                font-size: 20px;
/*
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -ms-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
  -o-box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
*/
/*  background: url("../images/bg-inner.png") repeat;*/
  padding: 7px;
            }
            input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
        </style>
	</head>

	<body>
            <?php
            include("nav.php");
        ?>
		<div class="wrapper">
			<div class="inner">
<!--				<form action="find_customer1.php" method="post">-->
                <div id="form">
					<h3>Search Customer </h3>
					<div class="form-row">
						<div class="form-wrapper" id="pk">
							<label for="">Phone Number*</label>
<!--							<input type="text" class="form-control" placeholder="Your Name">-->
                             <input  class="form-control" type="number" placeholder="Phone number" pattern="[6789]{1}[0-9]{9}" maxlength="10" name="phone" id="name" required> 
						</div>

					</div>

					<button name="submit" id="submit" data-text="SEARCH">
						<span>search</span>
					</button>
                    </div>
<!--				</form>-->
			</div>
            <div class="wrapper2" >
<!--                <form action="find_customer1.php" method="post">-->
                    <div id="details">
                    </div>
<!--                </form>-->
                    
       </div>
		</div>
		
         <?php
            include("footer.php");
        ?>

        <script>
            
                              $('#submit').click(function(){
                                  var phone=document.getElementById("name").value;
                                  var pattern = /^([6-9]{1}[0-9]{9})$/;
                                  if(phone.match(pattern)){
                                      
                                  var dstring='phone='+ phone;
                                 
                                  $.ajax({
                                      type: "POST",
                                      url:"fetch_details.php",
                                      data:dstring,
                                      cache:false,
                                      success:function(response){
                                          document.getElementById("details").innerHTML=response;
                                      }
                                  });
                                }else{
                                    alert('enter valid phone number');
                                }
                                  
                              });
                              
        </script>
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
