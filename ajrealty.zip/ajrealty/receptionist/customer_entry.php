<?php
include("../Db_Conn.php");
 $r=$_GET['val1'];
session_start();
date_default_timezone_set("Asia/Kolkata");
if(!isset($_SESSION['staff_id'])){
    header("location: ../login.php");
}else{
 $role = $_SESSION['role'];
 $staff_id = $_SESSION['staff_id'];
 $staff_phone = $_SESSION['staff_phone'];
    
    $sql1 = "SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
    $con = mysqli_query($conn,$sql1);
    $row1 = mysqli_fetch_array($con);
    $staff_name = $row1['staff_name'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
	<style type="text/css">
		#personal_information,
		#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
	</style>
</head>

<body>
     <?php
            include("nav.php");
        ?>
    <div class="page-wrapper bg-red p-t-60 p-b-60 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Customer Information</h2>
                    <form method="POST" action="customer_entry_insert.php" id="myform">
                        <input type="hidden" name="staff_id" value="<?php echo $staff_id;?>">
                        <input type="hidden" name="staff_name" value="<?php echo $staff_name;?>">
                        
                        <fieldset id="basic_information" class="">
                        <div class="input-group">Full Name
                            <input class="input--style-2" type="text" id="name" placeholder="Customer Fullname" name="name">
                            <span class="error"></span>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer Phone" name="phone" id="phone" value="<?php echo"$r";?>" maxlength="10" onblur="phoneExist()">
                                    <span id="exist_ph"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Alternative Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer alternative phone number" name="alt_phone" id="alt_phone" maxlength="10">
                                </div>
                            </div>
                        </div>
                            <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Office Number
                                    <input class="input--style-2" type="number" placeholder="Office Phone" name="off_phone" id="off_phone">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Residential Number
                                    <input class="input--style-2" type="number" placeholder="Residential Phone" name="residential" id="residential">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Email-id
                                    <input class="input--style-2" type="text" placeholder="Customer Email" name="email" id="email" onblur="mailExist()">
                                    <span id="exist_eml"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Gender
                                    <select name="gender" class="input--style-2">
                                        <option value="">Select Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                            <div class="input-group">Occupation
                                    <input class="input--style-2" type="text" placeholder="Occupation" name="occupation">
                                </div>
                            <div class="divbtn">
                            <button type="button" class="btn btn--radius btn--submit next">Next</button>
                          </div>
                        </fieldset>
                        <!--tab 2-->
                        <fieldset id="address_information" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address Line-1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="address_line1" id="address_line1">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address Line-2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="address_line2" id="address_line2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="street" id="street">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="number" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2" required>
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2" required>
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Attended Manager
                                    <select name="manager_id" id="manager_id" class="input--style-2">
                                        <option value="">Select Manager</option>
                                        <?php
                                           $sel = "SELECT staff_name, staff_id FROM `ajrealty_staffs` WHERE staff_role='Manager' GROUP BY staff_id";
                                           $selcon = mysqli_query($conn,$sel);
                                           while($fetch = mysqli_fetch_array($selcon)){
                                        ?>
                                        <option value="<?php echo $fetch['staff_id'];?>"><?php echo $fetch['staff_name'];?></option>
                                        <?php
                                           }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                            <div style="overflow:auto;">
                            <div style="float:right;">
                                <button type="button" id="previous" class="btn btn--radius btn--submit">Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="add">Submit</button>
                            </div>
                          </div>
                        </fieldset>
                          
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
            include("footer.php");
            ?>
   <script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 number");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
                        alt_phone : {
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
                            emailRegex: true,
						},
                        gender: {
							required: true,
						},
                        occupation: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
                        address_line1:{
                            required: true,
                        },
                        manager_id:{
                            required: true,
                        },
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
                        alt_phone : {
                            required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
                        address_line1:{
                            required: "required",
                        },
                        
                        manager_id:{
                            required: "required",
                        },
					}
				});
				if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#basic_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
			});

			$('#previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information');
				}else if ($('#basic_information').is(":visible")){
					current_fs = $('#basic_information');
					next_fs = $('#address_information');
				}
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script>
      <!--check phone number already existed or not-->
<script>  
$function phoneExist() {
    var phone = document.getElementById("phone").value;
    var dataString = 'phone='+ phone;

        $.ajax({
            type: "POST",
            url: "check_user_exist.php",
            cache: false,
            data: dataString,
            success: function (response) {
                if (response == 'exist' ) {
                  var text = 'Sorry... phone number already taken';
                    document.getElementById("exist_ph").innerHTML=text; 
                }else if (response == 'not_exist') {
                   var text = 'Sorry... phone number already taken';
                   document.getElementById("exist_ph").innerHTML=text;  
                }
              }
        });  
}   
 </script>  
    <!--check email already existed or not-->
<script>  
$function mailExist() {
    var email = document.getElementById("email").value;
    var dataString = 'email='+ email;

        $.ajax({
            type: "POST",
            url: "check_user_exist.php",
            cache: false,
            data: dataString,
            success: function (response) {
                if (response == 'exist' ) {
                  var text = 'Sorry... email already existed';
                    document.getElementById("exist_eml").innerHTML=text; 
                }else if (response == 'not_exist') {
                   var text = 'Sorry... email already existed';
                   document.getElementById("exist_eml").innerHTML=text;  
                }
              }
        });  
}   
 </script>
</body>
</html>