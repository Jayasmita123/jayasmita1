<?php
include("../Db_Conn.php");
if(isset($_POST['add'])){
    date_default_timezone_set("Asia/Kolkata");
    $staff_id = $_POST['staff_id'];
    $staff_name = $_POST['staff_name'];
    
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $alt_phone = $_POST['alt_phone'];
    $email = $_POST['email'];
    $occupation = $_POST['occupation'];
    $gender = $_POST['gender'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = $_POST['address_line2'];
    $landmark = $_POST['landmark'];
    $pincode = $_POST['pincode'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $country = $_POST['country'];
    $manager_id = $_POST['manager_id'];
    $residential = $_POST['residential'];
    $off_phone = $_POST['off_phone'];
    $street = $_POST['street'];
    $entry_date = date("Y-m-d H:i:s");
    
    $select = "SELECT * FROM `ajrealty_customer` WHERE `customer_phone`='$phone' AND `customer_email`='$email'";
    $selectcon = mysqli_query($conn,$select);
    if(mysqli_num_rows($selectcon) > 0){
        echo "<script>alert('Already this customer existed');window.location='customer_entry.php';</script>";
    }else{
    
        $sel = "SELECT staff_name FROM `ajrealty_staffs` WHERE staff_id='$manager_id'";
        $selcon = mysqli_query($conn,$sel);
        $fetch = mysqli_fetch_array($selcon);
        $manager_name = $fetch['staff_name'];

        $insert = "INSERT INTO `ajrealty_customer`(`gender`, `customer_name`, `customer_phone`, `alternative_phone`, `residence_phone`, `office_phone`, `customer_email`, `customer_occupation`, `customer_address_line1`, `customer_address_line2`, `street`, `customer_landmark`, `customer_city`, `customer_district`, `customer_state`, `customer_country`, `customer_pincode`, `manager_name`, `manager_id`, `entry_date`) VALUES ('$gender','$name','$phone','$alt_phone','$residential','$off_phone','$email','$occupation','$address_line1','$address_line2','$street','$landmark','$city','$district','$state','$country','$pincode','$manager_name','$manager_id','$entry_date')";
        $res = mysqli_query($conn,$insert);
        if($res){
            $sql = "SELECT * FROM `ajrealty_customer` WHERE `customer_phone`='$phone' AND `customer_email`='$email' ORDER BY `Sl.No` DESC LIMIT 1";
            $sqlcon = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($sqlcon);
            $slno = $row['Sl.No'];
            $cus_id = "aj_customer".$slno;
            
            $update = "UPDATE `ajrealty_customer` SET `customer_id`='$cus_id' WHERE `customer_phone`='$phone' AND `customer_email`='$email'";
            $updcon = mysqli_query($conn,$update);
            if($updcon){
                
                $remarks = "New customer registered and met ".$manager_name." (Manager)";
                $sql2 = "INSERT INTO `ajrealty_remarks`(`customer_id`, `role`, `staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$cus_id','receptionist','$staff_id','$staff_name','$remarks','$entry_date')";
                $con2 = mysqli_query($conn,$sql2);
                
                $qry = mysqli_query($conn,"INSERT INTO `notification_status`(`customer_id`, `assigned_staff_name`, `assigned_staff_id`, `message`, `role`, `status`, `customer`,`entry_date`,`remark_from`) VALUES ('$cus_id','$manager_name','$manager_id','new customer walkin','manager',0,'new','$entry_date','receptionist')");
                
                echo "<script>alert('Successfully inserted');window.location='index.php';</script>";                
            }else{
                echo "<script>alert('failed');window.location='customer_entry.php';</script>";
            }
        }
    }

    /*function customer_id_generate(){
        $result = substr($string, 0, 5);
    }
    function random_username($string) {
        $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0,3);
        $nrRand = rand(0, 100);

        $username = trim($firstPart).trim($nrRand);
        return $username;
    }*/
}
?>