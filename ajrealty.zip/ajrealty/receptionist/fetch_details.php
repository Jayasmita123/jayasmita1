<?php
include('../Db_Conn.php');
$phone=$_POST['phone'];

$query3 = "SELECT * FROM `ajrealty_customer` WHERE customer_phone= '$phone'";
$sql1 = mysqli_query($conn,$query3);
$n=mysqli_num_rows($sql1);
if($n>0){
    $row=mysqli_fetch_array($sql1);
       
        $cus_id = $row['customer_id'];
        $query = "SELECT property_id,assigned_staff_id FROM `assigned_manager` WHERE customer_id = '$cus_id'";
        $sql = mysqli_query($conn,$query);

     while($fetch = mysqli_fetch_array($sql)){
         $pid = $fetch['property_id'];
         $ass_staff_id = $fetch['assigned_staff_id'];
         
         $qry = "SELECT property,property_type,type,property_status FROM `ajrealty_survey` WHERE property_id='$pid' AND customer_id='$cus_id'";
         $res = mysqli_query($conn,$qry);
         $display = mysqli_fetch_array($res);
         $property = $display['property'];
         $type = $display['type'];
         $property_type = $display['property_type'];
         $property_status = $display['property_status'];
         if($property_status == '0'){
             $property_status = 'On process';
         }else{
             $property_status = 'sold';
         }
         
         $sel = "SELECT staff_name FROM `ajrealty_staffs` WHERE staff_id='$ass_staff_id'";
         $consel = mysqli_query($conn,$sel);
         $get = mysqli_fetch_array($consel);
         $stf_name = $get['staff_name'];
         
    ?>
    <form action="index.php" method="post">
    <input type="hidden" name="cid" value="<?php echo $cus_id;?>">
    <input type="hidden" name="pid" value="<?php echo $pid;?>">
    <input type="hidden" name="mg_id" value="<?php echo $ass_staff_id;?>">
    <input type="hidden" name="mg_name" value="<?php echo $stf_name;?>">
        
            <h5>Name: <?php echo $row['customer_name'];?></h5>
            <h5>Phone: <?php echo $row['customer_phone'];?></h5>
            <h5>Email: <?php echo $row['customer_email'];?></h5>
            <h5>Property: <?php echo $property;?></h5>
            <h5>Property Mode: <?php echo $type;?></h5>
            <h5>Property Type: <?php echo $property_type;?></h5>
            <h5>Status: <?php echo $property_status;?></h5>
            <h5>Manager:<?php echo $stf_name;?></h5>
            <input name="submit1" type="submit" value="WalkIn">
       
</form>
<?php
    }
}
else{
    
   ?>
    
<a href="customer_entry.php?val1=<?php echo "$phone"; ?>"><button>New Customer</button></a>
<?php
}
?> 
