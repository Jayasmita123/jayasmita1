var stateObject = {
"India": { "Andhra Pradesh": ["Anantapur","Chittoor","East Godavari","Guntur","Kadapa","Krishna","Kurnool","Prakasam","Srikakulam","SriPotti Sri Ramulu Nellore","Vishakhapatnam","Vizianagaram","West Godavari"],
"Arunachal Pradesh": ["Anjaw","Changlang","Dibang Valley","East Siang","East Kameng","Kurung Kumey","Kra Daadi","Lohit","Longding","Lower Dibang Valley","Lower Subansiri","Namsai","Papum Pare","Siang","Tawang","Tirap","Upper Siang","Upper Subansiri","West Kameng","West Siang"],
"Assam": ["Baksa","Barpeta","Bongaigaon","Biswanath","Cachar","Chirang","Charaideo","Darrang","Dhemaji","Dhubri","Dibrugarh","Dima Hasao","Goalpara","Golaghat","Hailakandi","Hojai","Jorhat","Kamrup","Kamrup Metropolitan","Karbi Anglong","Karimganj","Kokrajhar","Lakhimpur","Morigaon","Majuli","Nagaon","Nalbari","Sivasagar","Sonitpur","Tinsukia","Udalguri","West Karbi Anglong"],
"Bihar": ["Araria","Arwal","Aurangabad","Banka","Begusarai","Bhagalpur","Bhojpur","Buxar","Darbhanga","East Champaran","Gaya","Gopalganj","Jamui","Jehanabad","Kaimur","Katihar","Khagaria","Kishanganj","Lakhisarai","Madhepura","Madhubani","Munger","Muzaffarpur","Nalanda","Nawada","Patna","Purnia","Rohtas","Saharsa","Samastipur","Saran","Sheikhpura","Sheohar","Sitamarhi","Siwan","Supaul","Vaishali","West Champaran"],
"Chhattisgarh": ["Bastar","Bijapur","Bilaspur","Balod","Baloda Bazar","Balrampur","Bemetara","Dantewada","Dhamtari","Durg","Gariaband","Jashpur","Janjgir-Champa",
    "Jagdalpur (Madhya Bastar)","Kondagaon","Korba","Koriya","Kanker","Kabirdham (formerly Kawardha)","Mahasamund","Mungeli",
                                            "Narayanpur","Raigarh","Rajnandgaon","Raipur","Surajpur","Surguja","Sukma"],
"Delhi": ["Central Delhi","East Delhi","New Delhi","North Delhi","North West Delhi","North East Delhi","Shahdara","South Delhi","South Eest Delhi", "South West Delhi","West Delhi"],
"Goa": ["North Goa", "South Goa"],
"Gujarat": ["Ahmedabad","Amreli","Anand","Aravalli","Banaskantha","Bharuch","Bhavnagar","Botad","Chhota Udaipur","Dahod","Dang","Devbhoomi Dwarka","Gandhinagar","Gir Somnath","Jamnagar","Junagadh","Kutch","Kheda","Mehsana","Mahisagar","Morbi","Narmada","Navsari","Patan","Panchmahal","Porbandar","Rajkot","Sabarkantha","Surendranagar", "Surat","Tapi","Vadodara","Valsad"],
"Haryana": ["Ambala","Bhiwani","Charkhi Dadri","Faridabad","Fatehabad","Gurgaon","Hissar","Jhajjar","Jind","Karnal","Kaithal", "Kurukshetra","Mahendragarh","Nuh","Palwal","Panchkula","Panipat","Rewari","Rohtak","Sirsa","Sonipat","Yamuna Nagar"],
"Himachal Pradesh": ["Bilaspur","Chamba","Hamirpur","Kangra","Kinnaur","Kullu","Lahaul & Spiti","Mandi","Simla","Sirmaur","Solan","Una"],
"Jammu and Kashmir": ["Anantnag","Bandipora","Baramulla","Budgam","Ganderbal","Doda","Jammu","Kathua","Kishtwar","Kulgam","Kupwara","Kargil","Leh","Pulwama","Poonch","Rajouri","Ramban","Reasi","Samba","Srinagar","Shopian","Udhampur"],
"Jharkhand": ["Bokaro","Chatra","Deoghar","Dhanbad","Dumka","East Singhbhum","Garhwa","Giridih","Godda","Gumla","Hazaribag","Jamtara","Khunti","Koderma","Latehar","Lohardaga","Pakur","Palamu","Ramgarh","Ranchi","Sahibganj","Seraikela Kharsawan","Simdega","West Singhbhum"],
"Karnataka": ["Bagalkot","Bangalore","Bangalore Urban","Belgaum","Bellary","Bidar","Chamarajnagar","Chikkamagaluru","Chikkaballapur",
                                           "Chitradurga","Davanagere","Dharwad","Dakshina Kannada","Gadag","Hassan","Haveri district","Kodagu","Kalaburagi",
                                           "Kolar","Koppal","Mandya","Mysore","Raichur","Shimoga","Tumkur","Udupi","Vijayapur","Uttara Kannada","Ramanagara","Yadgir"],
"Kerala": ["Alappuzha","Ernakulam","Idukki","Kannur","Kasaragod","Kollam","Kottayam","Kozhikode","Malappuram","Palakkad","Pathanamthitta","Thrissur","Thiruvananthapuram","Wayanad"],
"Madhya Pradesh": ["Alirajpur","Agar Malwa","Anuppur","Ashoknagar","Balaghat","Barwani","Betul","Bhind","Bhopal","Burhanpur","Chhatarpur","Chhindwara","Damoh","Dewas","Dhar","Datia","Dindori","East Nimar","Guna","Gwalior","Hoshangabad",
                                    "Harda","Indore","Jhabua","Jabalpur","Katni","Mandla","Mandsaur","Morena","Narsinghpur","Neemuch","Panna","Raisen","Ratlam","Rajgarh",
                                    "Rewa","Sagar","Satna","Sehore","Seoni","Shahdol","Shajapur","Sheopur","Shivpuri","Sidhi","Singrauli","Tikamgarh","Umaria","Ujjain","Vidisha","West Nimar"],
"Maharashtra": ["Ahmednagar","Akola","Amaravati","Aurangabad","Beed","Bhandara","Buldhana","Chandrapur","Dhule","Gadchiroli","Gondia","Hingoli",
    "Jalna","Jalgaon","Kolhapur","Latur","Mumbai Suburban","Mumbai City","Nagpur","Nandurbar","Nanded","Nasik","Osmanabad","Palghar",
    "Parbhani","Pune","Raigad","Ratnagiri","Sangli","Sholapur","Satara","Sindhudurg","Thane","Wardha","Washim","Yavatmal"],
"Manipur": ["Bishnupur","Churachandpur","Chandel","Imphal East","Senapati","Tamenglong","Thoubal","Ukhrul","Imphal West",
    "Jiribam","Kangpokpi (Sadar Hills)","Kakching","Tengnoupal","Kamjong","Noney","Pherzawl"],
"Meghalaya": ["East Garo Hills","East Jaintia Hills","East Khasi Hills","North Garo Hills","Ri Bhoi","South Garo Hills","South West Garo Hills","South West Khasi Hills","West Garo Hills","West Jaintia Hills","West Khasi Hills"],
"Mizoram": ["Aizawl","Champhai","Kolasib","Lawngtlai","Lunglei","Mamit","Saiha","Serchhip"],
"Nagaland": ["Dimapur","Kiphire","Kohima","Longleng","Mokokchung","Mon","Noklak","Peren","Phek","Tuensang","Wokha","Zunheboto"],
"Odisha": ["Angul","Boudh (Baudh)","Balangir","Bargarh","Balasore (Baleswar)","Bhadrak","Cuttack","Deogarh (Debagarh)",
    "Dhenkanal","Ganjam","Gajapati","Jharsuguda","Jajpur","Jagatsinghapur","Khordha","Keonjhar (Kendujhar)","Kalahandi","Kandhamal","Koraput",
    "Kendrapara","Malkangiri","Mayurbhanj","Nabarangpur","Nuapada","Nayagarh","Puri","Rayagada","Sambalpur","Subarnapur (Sonepur)","Sundargarh"],
"Punjab": ["Amritsar","Barnala","Bathinda","Firozpur","Faridkot","Fatehgarh Sahib","Fazilka","Gurdaspur","Hoshiarpur","Jalandhar","Kapurthala","Ludhiana","Mansa","Moga","Sri Muktsar Sahib","Pathankot",
                                        "Patiala","Rupnagar","Sangrur","Shahid Bhagat Singh Nagar","Sahibzada Ajit Singh Nagar","Tarn Taran"],
"Rajasthan": ["Ajmer","Alwar","Banswara","Barmer","Baran","Bharatpur","Bhilwara","Bundi","Bikaner","Chittorgarh","Churu",
    "Dausa","Dholpur","Dungarpur","Hanumangarh","Jaipur","Jaisalmer","Jodhpur","Jhalawar","Jhunjhunu","Jalor","Karauli","Kota","Nagaur",
    "Pali","Pratapgarh","Rajsamand","Sawai Madhopur","Sikar","Sirohi","Sri Ganganagar","Tonk","Udaipur"],
"Sikkim": ["East Sikkim","North Sikkim","South Sikkim","West Sikkim"],
"Tamilnadu": ["Ariyalur","Chennai","Coimbatore","Cuddalore","Chengalpattu","Dharmapuri","Dindigul","Erode","Kanchipuram","Kanyakumari",
    "Kallakurichi","Karur","Krishnagiri","Madurai","Nagapattinam","Nilgiris","Namakkal","Perambalur","Pudukkottai","Ramanathapuram","Ranipet",
    "Salem","Sivaganga","Thanjavur","Tirunelveli","Tiruppur","Tiruchirapalli","Theni","Tenkasi","Thoothukudi","Tirupathur","Tiruvarur","Tiruvallur","Tiruvannamalai","Vellore","Villupuram","Virudhunagar"],
"Telangana": ["Adilabad","Bhadradri Kothagudem","Hyderabad","Jagitial","Jangaon","Jayashankar Bhupalapally","Jogulamba Gadwal",
    "Kamareddy","Karimnagar","Khammam","Kumarambheem Asifabad","Mahabubabad","Mahbubnagar","Mancherial district","Medak","Medchal–Malkajgiri","Mulugu",
    "Nagarkurnool","Narayanpet","Nalgonda","Nirmal","Nizamabad","Peddapalli","Rajanna Sircilla","Ranga Reddy","Sangareddy","Siddipet","Suryapet",
    "Vikarabad","Wanaparthy","Warangal Rural","Warangal Urban","Yadadri Bhuvanagiri"],
"Tripura": ["Dhalai","Gomati","Khowai","North Tripura","Sipahijala","South Tripura","Unakoti","West Tripura"],
"Uttar Pradesh": ["Agra","Aligarh","Allahabad","Ambedkar Nagar","Amethi","Amroha","Auraiya","Azamgarh","Badaun","Baghpat","Bahraich",
    "Ballia","Balrampur","Banda","Barabanki","Bareilly","Basti","Bijnor","Bulandshahr","Chandauli","Chitrakoot","Deoria","Etah","Etawah",
    "Faizabad","Farrukhabad","Fatehpur","Firozabad","Gautam Buddha Nagar","Ghazipur","Ghaziabad","Gorakhpur","Gonda","Hamirpur","Hapur",
    "Hardor","Hathras","Jalaun","Jaunpur","Jhansi","Kannauj","Kanpur Dehat","Kanpur Nagar","Kasganj","Kaushambi","Kushinagar","Lakhimpur Kheri","Lalitpur","Lucknow",
    "Maharajganj","Mahoba","Mainpuri","Mathura","Mau","Meerut","Moradabad","Mirzapur","Muzaffarnagar","Pilibhit","Pratapgarh","Rae Bareli","Rampur",
    "Sambhal","Saharanpur","Sant Kabir Nagar","Sant Ravidas Nagar","Shahjahanpur","Shamli","Shravasti","Siddharthnagar","Sitapur","Sonbhadra","Sultanpur","Unnao","Varanasi"],
"Uttarakhand": ["Almora","Bageshwar","Chamoli","Champawat","Dehradun","Haridwar","Nainital",
    "Pauri Garhwal","Pithoragarh","Rudraprayag","Tehri Garhwal","Udham Singh Nagar","Uttarkashi"],
"West Bengal": ["Alipurduar","Bankura","Birbhum","Cooch Behar","Dakshin Dinajpur","Darjeeling","Hooghly","Howrah",
                                    "Jalpaiguri","Jhargram","Kalimpong","Kolkata","Maldah","Murshidabad","Nadia","North 24 Parganas",
                                    "Paschim Medinipur","Purba Medinipur","Paschim Bardhaman","Purba Bardhaman","Purulia","South 24 Parganas","Uttar Dinajpur"]

}
}
window.onload = function () {
var countySel = document.getElementById("countrySel"),
stateSel = document.getElementById("stateSel"),
districtSel = document.getElementById("districtSel"),
    
countySel_work = document.getElementById("countrySel_work"),
stateSel_work = document.getElementById("stateSel_work"),
districtSel_work = document.getElementById("districtSel_work"),
    
countySel_rent = document.getElementById("countrySel_rent"),
stateSel_rent = document.getElementById("stateSel_rent"),
districtSel_rent = document.getElementById("districtSel_rent"),
    
countySel_lease = document.getElementById("countrySel_lease"),
stateSel_lease = document.getElementById("stateSel_lease"),
districtSel_lease = document.getElementById("districtSel_lease");

/*selecting country in company address*/
for (var countrywork in stateObject) {
countySel_work.options[countySel_work.options.length] = new Option(countrywork, countrywork);
}
countySel_work.onchange = function () {
stateSel_work.length = 1; // remove all options bar first
districtSel_work.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
for (var statework in stateObject[this.value]) {
stateSel_work.options[stateSel_work.options.length] = new Option(statework, statework);
}
}
countySel_work.onchange(); // reset in case page is reloaded
stateSel_work.onchange = function () {
districtSel_work.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var districtwork = stateObject[countySel_work.value][this.value];
for (var i = 0; i < districtwork.length; i++) {
districtSel_work.options[districtSel_work.options.length] = new Option(districtwork[i], districtwork[i]);
}
}

/*selecting country in interview address*/
for (var country in stateObject) {
countySel.options[countySel.options.length] = new Option(country, country);
}
countySel.onchange = function () {
stateSel.length = 1; // remove all options bar first
districtSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
for (var state in stateObject[this.value]) {
stateSel.options[stateSel.options.length] = new Option(state, state);
}
}
countySel.onchange(); // reset in case page is reloaded
stateSel.onchange = function () {
districtSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var district = stateObject[countySel.value][this.value];
for (var i = 0; i < district.length; i++) {
districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
}
}

/*selecting country in rent*/
for (var countryrent in stateObject) {
countySel_rent.options[countySel_rent.options.length] = new Option(countryrent, countryrent);
}
countySel_rent.onchange = function () {
stateSel_rent.length = 1; // remove all options bar first
districtSel_rent.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
for (var staterent in stateObject[this.value]) {
stateSel_rent.options[stateSel_rent.options.length] = new Option(staterent, staterent);
}
}
countySel_rent.onchange(); // reset in case page is reloaded
stateSel_rent.onchange = function () {
districtSel_rent.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var districtrent = stateObject[countySel_rent.value][this.value];
for (var i = 0; i < districtrent.length; i++) {
districtSel_rent.options[districtSel_rent.options.length] = new Option(districtrent[i], districtrent[i]);
}
}

/*selecting country in lease*/
for (var countrylease in stateObject) {
countySel_lease.options[countySel_lease.options.length] = new Option(countrylease, countrylease);
}
countySel_lease.onchange = function () {
stateSel_lease.length = 1; // remove all options bar first
districtSel_lease.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
for (var statelease in stateObject[this.value]) {
stateSel_lease.options[stateSel_lease.options.length] = new Option(statelease, statelease);
}
}
countySel_lease.onchange(); // reset in case page is reloaded
stateSel_lease.onchange = function () {
districtSel_lease.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var districtlease = stateObject[countySel_lease.value][this.value];
for (var i = 0; i < districtlease.length; i++) {
districtSel_lease.options[districtSel_lease.options.length] = new Option(districtlease[i], districtlease[i]);
}
}

}

/*window.onload = function () {
var stateSel = document.getElementById("stateSel"),
districtSel = document.getElementById("districtSel"),
stateSel_work = document.getElementById("stateSel_work"),
districtSel_work = document.getElementById("districtSel_work");
for (var state in stateObject) {
stateSel.options[stateSel.options.length] = new Option(state, state);
}

//countySel.onchange(); // reset in case page is reloaded
stateSel.onchange = function () {
districtSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var district = stateObject[this.value];
for (var i = 0; i < district.length; i++) {
districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
}
}

for (var state_work in stateObject) {
stateSel_work.options[stateSel_work.options.length] = new Option(state_work, state_work);
}

//countySel.onchange(); // reset in case page is reloaded
stateSel_work.onchange = function () {
districtSel_work.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done
var district_work = stateObject[this.value];
for (var i = 0; i < district_work.length; i++) {
districtSel_work.options[districtSel_work.options.length] = new Option(district_work[i], district_work[i]);
}
}

}*/