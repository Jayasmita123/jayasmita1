<!DOCTYPE html>
<html lang="en">
<head>
	<title>AJREALTY</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg4.png');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="login.php" method="post">
					<span class="login100-form-logo">
						<img src="images/logo.jpg" height="80" width="80">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Login
					</span>

					<div class="wrap-input100" data-validate = "Enter username">
						<input class="input100" type="text" name="username" placeholder="Username" required>
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>

					<div class="wrap-input100" data-validate="Enter password">
						<input class="input100" type="password" name="password" placeholder="Password" required>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="contact100-form-checkbox">
						<a class="txt1" href="forgot_password.php">
							Forgot Password?
						</a>
					</div>

					<div class="container-login100-form-btn">
						<input type="submit" name="login" value="Login" class="login100-form-btn">
					</div>
				</form>
			</div>
		</div>
	</div>
	
<?php
    if(isset($_POST['login'])){
    include("Db_Conn.php");
    session_start();
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM real_estate_login WHERE username='$username' AND password='$password'";
    $sqlcon = mysqli_query($conn, $sql);
        if(mysqli_num_rows($sqlcon) == 1){
            $fetch = mysqli_fetch_array($sqlcon);
            
            $role = $fetch['role'];
            echo "<script>alert($role);</script>";
            
            $_SESSION['role'] = $role;
            $_SESSION['staff_id'] = $fetch['user_id'];
            $_SESSION['staff_phone'] = $fetch['phone'];
            
            if($role == 'Proprietor'){
                echo "<script>window.location='proprietor/index.php';</script>";
            }else if($role == 'Manager'){
                echo "<script>window.location='manager/index.php';</script>";
            }else if($role == 'Receptionist'){
                echo "<script>window.location='receptionist/index.php';</script>";
            }else if($role == 'Call Center'){
                echo "<script>window.location='call_center/index.php';</script>";
            }

        }else{
            echo "<script>alert('username and password does not matched');</script>";
        }
    }
    ?>
    <script>
        window.history.forward();
        </script>
</body>
</html>