<?php
require_once("Db_Conn.php");      
if(isset($_POST['submit']))
    {
    
        $name=$_POST['name'];
        $phone=$_POST['contact']; 
        $alt_phone=$_POST['alt_phone']; 
        $email=$_POST['email'];
        $qual=$_POST['qualification'];
        $exp=$_POST['experience']; 
        $dob=$_POST['dob'];
        $s_jdate=$_POST['jdate'];
        $role=$_POST['role'];
        $add1=$_POST['add1']; 
        $add2=$_POST['add2'];
        $country=$_POST['country'];
        $state=$_POST['state']; 
        $street=$_POST['street']; 
        $district=$_POST['district'];
        $city=$_POST['city'];
        $pincode=$_POST['pincode']; 
        $landmark=$_POST['landmark'];
        $username = substr($name, 0, 4).substr($phone, 0, 2);
        $data = '1234567890abcefghijklmnopqrstuvwxyz';
        
        $password = substr(str_shuffle($data), 0, 6);
        
        date_default_timezone_set('Asia/Kolkata');
        $entry_date=date("Y-m-d h:i:s");
            
         
$file =$_FILES['photo']['name'];
$file_loc = $_FILES['photo']['tmp_name'];
 $file_size = $_FILES['photo']['size'];
 $file_type = $_FILES['photo']['type'];
 $folder="photos/";
 
 // new file size in KB
 $new_size = $file_size/1024;  
 // new file size in KB
 
 // make file name in lower case
 $new_file_name = strtolower($file);
 // make file name in lower case
 
 $final_file=str_replace(' ','-',$new_file_name);
 
 move_uploaded_file($file_loc,$folder.$final_file);
    
         $m="SELECT * FROM ajrealty_staffs WHERE staff_phone='$phone' AND staff_email='$email'";
         $c=mysqli_query($conn, $m);
         $n=mysqli_num_rows($c);
         if($n==0)
         {
             $s1="INSERT INTO `ajrealty_staffs`(`staff_name`, `staff_phone`, `staff_alternate_phone`, `staff_email`, `staff_qualification`, `staff_experience`, `staff_dob`, `staff_joining_date`, `staff_role`, `staff_address_line1`, `staff_address_line2`, `street`, `staff_landmark`, `staff_city`, `staff_district`, `staff_state`, `staff_country`, `staff_pincode`, `entry_date`, `staff_image`) VALUES ('$name','$phone','$alt_phone','$email','$qual','$exp','$dob','$s_jdate','$role','$add1','$add2','$street','$landmark','$city','$district','$state','$country','$pincode','$entry_date','$folder$final_file')";
              if(mysqli_query($conn, $s1))
              {
                $sql = "SELECT * FROM `ajrealty_staffs` WHERE staff_phone='$phone' AND staff_email='$email' AND `staff_role`='$role' ORDER BY `Sl.No` DESC LIMIT 1";
                $sqlcon = mysqli_query($conn,$sql);
                $row = mysqli_fetch_array($sqlcon);
                $slno = $row['Sl.No'];
                $staff_id = "aj_staff".$slno;
                  
                $update = "UPDATE `ajrealty_staffs` SET `staff_id`='$staff_id' WHERE staff_phone='$phone' AND staff_email='$email' AND `staff_role`='$role'";
                $updcon = mysqli_query($conn,$update);
                if($updcon){
                
                    $qry = mysqli_query($conn,"INSERT INTO `real_estate_login`(`user_id`, `role`, `username`, `password`, `email`, `phone`, `created_date`) VALUES ('$staff_id','$role','$username','$password','$email','$phone','$entry_date')");
                    if($qry){
                        $from = "connect@brainlift.in";
                        $to = $email;
                        $subject = "AJREALTY Login credential";
                        $message = "<h4>Dear Sir / Madam,</h4>";
                        $message.='<p>Use the following credential to get login into your panel</p>';
                        $message.='<h4>Username: '.$username.'</h4>';	
                        $message.='<h4>Password: '.$password.'</h4>';	
                        $message.='<p>You can change this password after login into your panel using change password option.</p>';   	
                        $message.='<p style="margin-top:60px;"><center>This is an auto generated email, please do not reply to this mail<center></p>';
                        $headers = "From:" . $from;
                        $headers  = "MIME-Version: 1.0" . "\r\n";
                        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
                        $headers .= "From: ". $from. "\r\n";
                        $headers .= "Reply-To: ". $from. "\r\n";
                        $headers .= "X-Mailer: PHP/";
                        $headers .= "X-Priority: 1" . "\r\n";

                        mail($to,$subject,$message,$headers);
                        echo"<script>alert('Successfull');</script>";
                        
                    }else{
                        echo "<script>alert('retry...');/script>";
                    }
                    
              }
         }
        
     }else{
            echo "<script>alert( 'Email or Phone Number exists');   window.location='staff_entry.php';</script>";
        }
   
}
?>



<html>
    <head><title>Staff Entry</title>
      <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Page-->
    <title>AJREALTY</title>
    <link href="fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="fonts/font-awesome-4.7.0/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="css/form.css" rel="stylesheet" media="all">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script type="text/JavaScript" src="js/country_state_district_dropdown.js"></script>
        
        
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>

        
   <style type="text/css">
		#basic_information2,#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
	</style> 
        
        
    </head>
    <body>
    <?php
        include("nav.php");
    ?>
        
    <div class="page-wrapper p-t-180 p-b-100 font-robo">
        <div class="wrapper wrapper--w960">
            <div class="card card-2">
                <div class="card-body">
                    <h2 class="title">Staff Info</h2>
                    <form action="staff_entry.php" method="POST" id="myform" enctype="multipart/form-data">
                         <fieldset id="basic_information" class="">
                        
                                <div class="input-group">Name
                                  <input class="input--style-2" type="text" placeholder="Name"  name="name" id="name">
                                </div>
                            
                           <div class="row row-space">
                               <div class="col-2">
                                <div class="input-group">Contact Number
                                 <input class="input--style-2"  type="number" id="phone" placeholder="Phone Number"  name="contact">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Alternative Phone Number
                                    <input class="input--style-2" type="number" placeholder="Customer alternative phone number" name="alt_phone" id="alt_phone" maxlength="10">
                                </div>
                            </div>
                        </div>
                           <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Email
                                  <input class="input--style-2" type="text" placeholder="Mail Id" id="email" name="email">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Experience
                                  <input class="input--style-2" id="exp" type="text" placeholder="Experience" name="experience">
                                </div>
                            </div>
                            </div>
                               <div class="input-group">Qualification
                                 <input class="input--style-2" type="text" placeholder="Qualification" name="qualification" id="qual">
                                </div>
                        
                               <div class="divbtn">
                            <button type="button" class="btn btn--radius btn--submit next2" >Next</button>
                            </div>
                        </fieldset>
                             
                       <fieldset id="basic_information2" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Date Of Birth
                                    
                                 <input class="input--style-2" type="date" id="dob" placeholder="Qualification" name="dob">
                                    <span class="error"></span>
                                    <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar" ></i>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Joining Date
                                    
                                  <input class="input--style-2" type="date" id="jdate" placeholder="Experience" name="jdate">
                                    <span class="error"></span>
                                    <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Role
                                    <select class="input--style-2" name="role" size="1">
                                    <option value="" >Select Role</option>
                                    <option value="Proprietor">Proprietor</option>
                                    <option value="Manager">Manager</option>
                                    <option value="Call Center">Call Center</option>
                                    <option value="Receptionist">Receptionist</option>
                                    </select>
                                    <span class="error"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Photo
                                   
                                  <input class="input--style-2" type="file" id="file"  name="photo">
                                    <span class="error"></span>
                                </div>
                            </div>
                           
                        </div>
                             <div style="overflow:auto;">
                            <div style="float:right;">
                                <button type="button" id="previous2" class="btn btn--radius btn--submit" >Previous</button>
                            <button type="button" class="btn btn--radius btn--submit next" >Next</button>
                            </div>
                          </div>
                        </fieldset>
                        
                    <fieldset id="address_information" class="">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Address 1
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="add1">
                                    <span class="error"></span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group"> Address 2
                                    <input class="input--style-2" type="text" placeholder="Address Line-2" name="add2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">Street/Road
                                    <input class="input--style-2" type="text" placeholder="Address Line-1" name="street" id="street">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">Landmark
                                    <input class="input--style-2" type="text" placeholder="Landmark" name="landmark">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                             <div class="col-2">
                                <div class="input-group">City
                                    <input class="input--style-2" type="text" placeholder="City" name="city">
                                </div>
                            </div>
                            <div class="col-2">
                               <div class="input-group">Pincode
                                    <input class="input--style-2" type="text" placeholder="Pincode" maxlength="6" name="pincode" id="pincode">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-3">
                                <div class="input-group">Country
                               <select name="country" id="countrySel_work" size="1" class="input--style-2">
                                        <option value="">Select Country</option>
                               </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">State
                                <select name="state" id="stateSel_work" size="1" class="input--style-2">
                                    <option value="">Select State</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">District
                               <select name="district" id="districtSel_work" size="1" class="input--style-2">
                                    <option value="">Select District</option>
                                </select>
                                </div>
                            </div>
                        </div>
                            <div class="divbtn">
                                <button type="button" id="previous" class="btn btn--radius btn--submit" >Previous</button>
                                <button type="submit" class="btn btn--radius btn--submit" id="add" name="submit" >Submit</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
 
        <?php
        include("footer.php");
        ?>
    
    </body>
     <script type="text/javascript">
		$(document).ready(function(){

			// Custom method to validate username
			$.validator.addMethod("usernameRegex", function(value, element) {
				return this.optional(element) || /^[a-zA-Z., ]*$/i.test(value);
			}, "Name must contain only letters and space");
            
             /** phone validation **/
    $.validator.addMethod("phoneRegex", function(value, element) {
				return this.optional(element) || /^([6-9]{1}[0-9]{9})*$/i.test(value);
			}, "Phone number must contain 10 digits start with 6 to 9 digit");
    
    /** email validation **/
    $.validator.addMethod("emailRegex", function(value, element) {
				return this.optional(element) || /^([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4})*$/i.test(value);
			}, "Enter Valid Email Ex.admin@gmail.com");
    
    /** pincode validation **/
    $.validator.addMethod("pincodeRegex", function(value, element) {
				return this.optional(element) || /^([0-9]{6})*$/i.test(value);
			}, "Pincode must contain 6 numbers");
            

			$(".next").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
							required: true,
                            emailRegex: true,
						},
                        qual: {
							required: true,
						},
                        exp: {
							required: true,
						},
                       dob: {
							required: true,
						},
                        jdate: {
							required: true,
						},
                        address1: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
						email: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        manager: {
							required: "required",
						},
                        address1: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
					}
				});
				if (form.valid() === true){
					if ($('#basic_information2').is(":visible")){
						current_fs = $('#basic_information2');
						next_fs = $('#address_information');
					}else if($('#address_information').is(":visible")){
						current_fs = $('#address_information');
						next_fs = $('#basic_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
                
			});

			$('#previous').click(function(){
				if($('#address_information').is(":visible")){
					current_fs = $('#address_information');
					next_fs = $('#basic_information2');
				}else if ($('#basic_information2').is(":visible")){
					current_fs = $('#basic_information2');
					next_fs = $('#address_information');
				}
				next_fs.show();
				current_fs.hide();
			});
            
            	$(".next2").click(function(){
				var form = $("#myform");
				form.validate({
					errorElement: 'span',
					errorClass: 'help-block',
					highlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').addClass("has-error");
					},
					unhighlight: function(element, errorClass, validClass) {
						$(element).closest('.input-group').removeClass("has-error");
					},
					rules: {
						name: {
							required: true,
							usernameRegex: true,
						},
						phone : {
							required: true,
                            phoneRegex: true,
                            minlength: 10,
                            maxlength: 10,
						},
						pincode : {
							required: true,
							minlength: 6,
                            maxlength: 6,
                            pincodeRegex: true,
						},
						email: {
							required: true,
                            emailRegex: true,
						},
                        staff_id: {
							required: true,
						},
                       qual: {
							required: true,
						},
                        exp: {
							required: true,
						},
                       dob: {
							required: true,
						},
                        jdate: {
							required: true,
						},
                        address1: {
							required: true,
						},
                        address2: {
							required: true,
						},
                        landmark: {
							required: true,
						},
                        city: {
							required: true,
						},
                        country: {
							required: true,
						},
                        state: {
							required: true,
						},
                        district: {
							required: true,
						},
						
					},
                    messages: {
						
						phone : {
							required: "required",
						},
						pincode : {
							required: "required",
						},
						name: {
							required: "required",
						},
						email: {
							required: "required",
						},
                        gender: {
							required: "required",
						},
                        occupation: {
							required: "required",
						},
                        manager: {
							required: "required",
						},
                        address1: {
							required: "required",
						},
                        address2: {
							required: "required",
						},
                        landmark: {
							required: "required",
						},
                        city: {
							required: "required",
						},
                        country: {
							required: "required",
						},
                        state: {
							required: "required",
						},
                        district: {
							required: "required",
						},
					}
				});
				if (form.valid() === true){
					if ($('#basic_information').is(":visible")){
						current_fs = $('#basic_information');
						next_fs = $('#basic_information2');
					}else if($('#basic_information2').is(":visible")){
						current_fs = $('#basic_information2');
						next_fs = $('address_information');
					}
					
					next_fs.show();
					current_fs.hide();
				}
                
			});

			$('#previous2').click(function(){
				if($('#basic_information2').is(":visible")){
					current_fs = $('#basic_information2');
					next_fs = $('#basic_information');
				}else if ($('#basic_information2').is(":visible")){
					current_fs = $('#basic_information2');
					next_fs = $('#basic_information');
				}
				next_fs.show();
				current_fs.hide();
			});
			
		});
	</script>
    
   
</html>