<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/4.0.6/sweetalert2.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/4.0.6/sweetalert2.min.css">
        <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">
<!--===============================================================================================-->
</head>
<body>
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg4.png');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="forgot_password.php" method="post">
					<span class="login100-form-logo">
						<img src="images/logo.jpg" height="80" width="80">
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Forgot Password?
					</span>

					<div class="wrap-input100" data-validate = "Enter Email">
						<input class="input100" type="text" name="email" pattern="[a-z]+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})" title="enter valid email address" required>
						<span class="focus-input100" data-placeholder="Email"></span>
					</div>

					<div class="contact100-form-checkbox">
						<a class="txt1" href="login.php">
							Back to login
						</a>
					</div>

					<div class="container-login100-form-btn">
						<input type="submit" name="send" value="Send" class="login100-form-btn">
					</div>
				</form>
			</div>
		</div>
	 </div>
    </body>
</html>

<?php
if(isset($_POST['send'])){
session_start();
require_once("Db_Conn.php");

$email=$_POST['email'];
    
date_default_timezone_set("Asia/Kolkata");
   $expFormat = mktime(date("H"), date("i")+5, date("s"), date("m") ,date("d"), date("Y"));
   $expDate = date("Y-m-d H:i:s",$expFormat);
   
$sql = "SELECT * FROM `real_estate_login` WHERE `email` = '$email'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result);
            
      $count = mysqli_num_rows($result);
      
      // If result matched $v1 and $v2, table row must be 1 row
		
      if($count == 1) {
          
          $n = 6; 
          $otp = otp_generate($n);
            
    $from = "connect@brainlift.in";
    $to = $email;
    $subject = "Reset your Real Estate panel password";
    $message = "<h4>Dear Sir / Madam,</h4>";
    $message.='<p>You can set a new one now! Please click on the below button to generate new password using following OTP code. </p>';
    $message.='<h4>OTP: '.$otp.'</h4>';
    $message.='<p>This OTP will expire after 5 minute. If you need a new one,
    you can request another on our forgot password page.</p>';
    $message.='<p>If you did not request a password reset, you can delete this email, your password will not be reset.</p>'; 
    $message.="<a href='https://www.jarvisgc.com/real_estate/reset_password.php?email=$email' class='button-link' style='background-color:#1673e6; border-radius:4px; color:#fff; display:inline-block; font-family:Helvetica, Arial, sans-serif; font-size:22px; font-weight:500; line-height:60px; text-align:center; text-decoration:none; white-space:nowrap; width:330px!important'
                                    bgcolor='#ff6347' align='center' width='330' target='_blank'> Reset your password </a>";
    $message.='<p style="margin-top:60px;"><center>This is an auto generated email, please do not reply to this mail<center></p>';
    $headers = "From:" . $from;
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
    $headers .= "From: ". $from. "\r\n";
    $headers .= "X-Mailer: PHP/";
    $headers .= "X-Priority: 1" . "\r\n"; 
    
    if(mail($to,$subject,$message,$headers)){
        mysqli_query($conn,"UPDATE real_estate_login SET otp='$otp', expiry_date='$expDate' WHERE email='$email'");
         echo "<script>
  swal({
    title: 'Forgot password reset link sent successfully',
    type: 'success',
  }).then(function() {
    window.location = 'login.php';
});
        </script>";
                        
      }else 
      {
         
         echo "<script>
  swal({
    title: 'Forgot password reset link sending failed',
    type: 'error',
  }).then(function() {
    window.location = 'login.php';
});
        </script>";
          
      }
} else {
             echo "<script>
  swal({
    title: 'This email does not existed',
    type: 'error',
  }).then(function() {
    window.location = 'login.php';
});
        </script>";
 
}
function otp_generate($chars) 
{
  $data = '1234567890';
  return substr(str_shuffle($data), 0, $chars);
}
}
          
?>