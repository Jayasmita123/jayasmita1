<?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}
#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover { background-color: #ddd; }

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #05147d;
  color: white;
}
#table_div{
min-height: 300px;
overflow-y: scroll;
}
select[name]{
   width: 20%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
}
.button {
  background-color: #05147d; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 2px;
  width:150px;
  height: 50px;
}
#table-th{
  position:fixed;
}
</style>
</head>
<body>
	<?php include("nav.php"); ?>
	<center><h1>Customer Details</h1></center>
<form action="add_callcenter_db.php" method="post">
<label for="staff">Select staff to be assigned : </label><select name="call_center" >
            <option style="display: none;">--SELECT STAFF--</option>
   <?php
include("Db_Conn.php");
$sql="SELECT * FROM  ajrealty_staffs WHERE staff_role='call center'";
$res = mysqli_query($conn, $sql);
$count=mysqli_num_rows($res);
if($count==0){
echo "";
}else {
while($row = $res->fetch_assoc()){ 
$staff_name=$row['staff_name'];
$staff_id=$row['staff_id'];

echo"<option value='$staff_id'>$staff_name</option>";
}
}
?>
</select><br><br>
<div id="table_div">
<table id="customers">
  <div id="table-th"><tr>
    <th>Customer name</th>
    <th>Contact</th>
    <th>Property type</th>
    <th>mode of buisness</th>
    <th>Assigned Manager</th>
    <th>Last visit</th>
    <th>Property_status</th>
    <th></th>
  </tr></div>
   <?php


    $sel6 = "SELECT * FROM `assigned_manager`";
    $con6 = mysqli_query($conn,$sel6);
    while($fetch6 = mysqli_fetch_array($con6)){
        $cid = $fetch6['customer_id'];

        $sel1 = "SELECT * FROM `ajrealty_callcenter` WHERE customer_id='$cid'";
    $con1 = mysqli_query($conn,$sel1);
        if(mysqli_num_rows($con1) == 0){
        
    $sel = "SELECT * FROM `ajrealty_customer` WHERE customer_id='$cid'";
    $con = mysqli_query($conn,$sel);
    while($fetch = mysqli_fetch_array($con)){
        $name = $fetch['customer_name'];
        $contact = $fetch['customer_phone'];
      }
 
        // $ass_mngr=$fetch['assigned_manager'];

    $sel2 = "SELECT * FROM `ajrealty_survey` WHERE customer_id='$cid'";
    $con2 = mysqli_query($conn,$sel2);
    while($fetch2 = mysqli_fetch_array($con2)){
        $property= $fetch2['property'];
        $type = $fetch2['type'];
        $pid = $fetch2['property_id'];
    }

  $sel3 = "SELECT * FROM `ajrealty_remarks` WHERE customer_id='$cid' AND property_id='$pid'";
    $con3 = mysqli_query($conn, $sel3);
    while($fetch3 = mysqli_fetch_array($con3)){
        $date= $fetch3['entry_date'];
  }

  $sel4 = "SELECT * FROM `ajrealty_survey` WHERE property_id='$pid' AND customer_id='$cid'";
    $con4 = mysqli_query($conn, $sel4);
    while($fetch4 = mysqli_fetch_array($con4)){
        $status= $fetch4['property_status'];
  }
    $sel5 = "SELECT * FROM `assigned_manager` WHERE property_id='$pid' AND customer_id='$cid'";
    $con5 = mysqli_query($conn, $sel5);
    while($fetch5 = mysqli_fetch_array($con5)){
       $ass_mngr= $fetch5['assigned_staff_id'];
  }
      $sel7 = "SELECT * FROM `ajrealty_staffs` WHERE staff_id='$ass_mngr'";
    $con7 = mysqli_query($conn, $sel7);
    while($fetch7 = mysqli_fetch_array($con7)){
       $ass_mngr_name= $fetch7['staff_name'];
  }
?>
  <tr>
    <td><?php echo $name; ?></td>
    <td><?php echo $contact; ?></td>
    <td><?php echo $property; ?></td>
    <td><?php echo $type; ?></td>
    <td><?php echo $ass_mngr_name; ?></td>
    <td><?php echo $date; ?></td>
    <?php if($status=='0'){
     echo "<td style='color:green;'>On Process</td>";
    } 
    else{
     echo "<td style='color:red;'>Sold</td>";
    } 
    ?>
    <td><center><input type="checkbox" name="add[]" value="<?php echo $pid ?>"></center></td>
  </tr>
<?php
}
    }
?>
</table>
</div>
<br>
<center><input type="submit" name="submit_callcenter" value="submit" class="button button1"></center>
</form>
<?php include("footer.php"); ?>
</body>
</html>