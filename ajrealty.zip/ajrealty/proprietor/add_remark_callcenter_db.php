<?php
include("Db_Conn.php");
session_start();
$staff_id=$_SESSION['staff_id'];

$cid=$_POST['cid'];
$remark=$_POST['remark'];
$date=date("Y-m-d H:i:s");

$sql_staff_name= "SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
$res_staff_name = mysqli_query($conn, $sql_staff_name);
$count2=mysqli_num_rows($res_staff_name);
if($count2==0){
echo "";
}else {
while($row_staff_name = $res_staff_name->fetch_assoc()){ 
$staff_name=$row_staff_name['staff_name'];
$staff_role=$row_staff_name['staff_role'];
}
}
$sql_insert="INSERT INTO `ajrealty_remarks`( `customer_id`,`staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$cid','$staff_id','$staff_name','$remark','$date')";

$res_insert=mysqli_query($conn, $sql_insert);
   if($res_insert){
                echo "<script>alert('Success');window.location='callcenter_remark_view.php?c_id=$cid';</script>";
            }else{
                echo "<script>alert('Error');window.location='callcenter_remark_view.php?c_id=$cid';</script>";
            }

?>