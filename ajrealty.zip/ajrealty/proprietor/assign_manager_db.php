<?php
include("Db_Conn.php");
session_start();
$staff_id=$_SESSION['staff_id'];

$cid=$_POST['cid'];
$pid=$_POST['pid'];
$ass_mngr=$_POST['assigned_manager'];
$msg=$_POST['message'];
date_default_timezone_set('Asia/Kolkata');
$date=date("Y-m-d H:i:s");

$sql_staff_name= "SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
$res_staff_name = mysqli_query($conn, $sql_staff_name);
$count2=mysqli_num_rows($res_staff_name);
if($count2==0){
echo "";
}else {
while($row_staff_name = $res_staff_name->fetch_assoc()){ 
$staff_name=$row_staff_name['staff_name'];
}
}

$sql_fetch_mngr="SELECT * FROM ajrealty_staffs WHERE staff_id='$ass_mngr'";
$res = mysqli_query($conn, $sql_fetch_mngr);
$count=mysqli_num_rows($res);
if($count==0){
echo "";
}else {
while($row = $res->fetch_assoc()){ 
$mngr_name = $row['staff_name'];
}
}
 $remark='Proprietor assigned assigned new customer';
$sql_insert = "INSERT INTO `notification_status` (`customer_id`,`property_id`,`assigned_staff_name`,`assigned_staff_id`,`message`,`role`,`entry_date`,`status`,`remark_from`) VALUES ('$cid','$pid','$mngr_name','$ass_mngr','$msg','Manager','$date','0','Propriator')";
$res_insert=mysqli_query($conn, $sql_insert);
 if($res_insert){

$sql_remark="INSERT INTO `ajrealty_remarks`( `customer_id`, `property_id`, `staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$cid','$pid','$staff_name','$staff_id','$msg','$date')";

$res_remark=mysqli_query($conn, $sql_remark);

$sql_insert_mangr="INSERT INTO `assigned_manager`( `assigned_staff_id`,`customer_id`,`property_id`,`entry_date`) VALUES('$ass_mngr','$cid','$pid','$date')";

$res_insert_mangr=mysqli_query($conn, $sql_insert_mangr);

  echo "<script>alert('Success');window.location='new_customer_view.php?c_id=$cid';</script>";
}else{
  echo "<script>alert('Error');window.location='new_customer_view.php?c_id=$cid';</script>";
}
?>                                                                                                                                                                                                                                                                                                                                                                        