<?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>

<!--validation-->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<style type="text/css">
		#address_information{
			display:none;
		}
        .has-error{
            color: crimson;
            border: none;
        }
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  text-align: left;
  padding-left: 2%;
  background-color: #f1f1f1;
  width: 85%;
}
.button {
  background-color: #05147d; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 2px;
  width:150px;
  height: 50px;
}
#details_table{
width:100%;
}
table, td, th {
border: 1px solid black;
}
table {
  border-collapse: collapse;
  width: 100%;
}
td {
  height: 50px;
  vertical-align:center;
}
</style>
</head>
<body>
<?php include("nav.php"); ?>
<?php
include("Db_Conn.php");
$c_id=$_GET['c_id'];

// $update_status="UPDATE notification_status SET status='1' WHERE customer_id='$c_id' AND role='propriator'";
// $res_status=mysqli_query($conn,$update_status);


$sel = "SELECT * FROM  ajrealty_customer WHERE customer_id='$c_id'";
$res = mysqli_query($conn, $sel);
    while($fetch = mysqli_fetch_array($res)){
$c_name = $fetch['customer_name'];
$c_phone = $fetch['customer_phone'];
$c_district = $fetch['customer_district'];
$c_state = $fetch['customer_state'];
$c_gender = $fetch['gender'];
$c_email= $fetch['customer_email'];
$c_occupation = $fetch['customer_occupation'];
$c_addr1= $fetch['customer_address_line1'];
$c_addr2 = $fetch['customer_address_line2'];
$c_addr3 = $fetch['customer_landmark'];
$c_addr4 = $fetch['customer_city'];
$c_addr5 = $fetch['customer_district'];
$c_addr7 = $fetch['customer_country'];
$c_addrpin = $fetch['customer_pincode'];
$c_state = $fetch['customer_state'];
$c_contactalt = $fetch['alternative_phone'];
$c_contactres = $fetch['residence_phone'];
$c_contactoff = $fetch['office_phone'];
// $c_ass_mngr  = $fetch['assigned_manager'];

$sql_mngr="SELECT * FROM `assigned_manager` WHERE `customer_id`='$c_id'";
$res_mngr= mysqli_query($conn, $sql_mngr);
    while($fetch_mngr= mysqli_fetch_array($res_mngr)){
$c_ass_mngr=$fetch_mngr['assigned_staff_id'];
}

$sql_staffname="SELECT * FROM ajrealty_staffs WHERE staff_id='$c_ass_mngr'";
$res_staffname= mysqli_query($conn, $sql_staffname);
    while($fetch_staff = mysqli_fetch_array($res_staffname)){
$c_mangr_name=$fetch_staff['staff_name'];
}

$sql_nxt_call="SELECT * FROM ajrealty_callcenter WHERE customer_id='$c_id'";
$res_nxt_call= mysqli_query($conn, $sql_nxt_call);
    while($fetch_nxt_call= mysqli_fetch_array($res_nxt_call)){
$c_nxt_call=$fetch_nxt_call['next_call_date'];
$c_nxt_call2=date("d-m-Y", strtotime($c_nxt_call));
}


?>

<center><div class="column">
<div class="card">
<h3><u>Customer Details</u></h3>
<br>
<table id="details_table">
<tr><td>Customer name : <?php echo $c_name ?><td>
<td>Contact number : <?php echo "$c_phone, $c_contactalt" ?></td>
<td>Residential number : <?php echo $c_contactres ?></td></tr>

<tr><td>Office number : <?php echo $c_contactoff ?><td>
<td>Email-id : <?php echo $c_email ?></td>
<td>Address : <?php echo "$c_addr1 $c_addr2 $c_addr3 $c_addr4, $c_addr5, $c_state, $c_addr7 - $c_addrpin"; ?></td></tr>

<tr><td>Assigned Manager : <?php echo $c_mangr_name ?><td>
  <td>Next call date : <?php if($c_nxt_call!=''){
    echo $c_nxt_call2;
    } else {
echo "";
    } ?><td>
</tr>
</table>
<h4><u>Remarks :</u></h4> 
<ul>
<?php
$sql_remark="SELECT * FROM `ajrealty_remarks` WHERE `customer_id`='$c_id'";
$res_remark= mysqli_query($conn, $sql_remark);
while($fetch_remark = mysqli_fetch_array($res_remark)){
$remarks=$fetch_remark['remarks'];
$enter_date=$fetch_remark['entry_date'];
$staff_id=$fetch_remark['staff_id'];
$staff_name=$fetch_remark['staff_name'];


$sql_staf="SELECT * FROM `ajrealty_staffs` WHERE `staff_id`='$staff_id'";
$res_staf= mysqli_query($conn, $sql_staf);
while($fetch_staf = mysqli_fetch_array($res_staf)){
$role=$fetch_staf['staff_role'];
}
echo "<li>By $staff_name($role) on $enter_date :- $remarks. </li>";
}
?>
</ul>
<br>
<center><a href="index.php"><button class="button button1">Back</button></a>
  <a href="add_remark_callcenter.php?c_id=<?php echo $c_id ?>"><button class="button button1">Add Remark</button></a>
    </div>
  </div></center>
<?php
}
?>
<?php include("footer.php"); ?>
</body>
</html>
