<?php
include("Db_Conn.php");
session_start();
$staff_id=$_SESSION['staff_id']; 

$cid=$_POST['cid'];
$pid=$_POST['pid'];
$msg=$_POST['remark'];
$date=date("Y-m-d H:i:s");

// echo "<script>alert('$cid, $pid, $msg, $date');</script>";

$sql_staff_name= "SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
$res_staff_name = mysqli_query($conn, $sql_staff_name);
$count2=mysqli_num_rows($res_staff_name);
if($count2==0){
echo "";
}else {
while($row_staff_name = $res_staff_name->fetch_assoc()){ 
$staff_name=$row_staff_name['staff_name'];
$staff_role=$row_staff_name['staff_role'];
}
}
// echo "<script>alert('$staff_name, $staff_id');</script>";

// $sql_fetch_mngr="SELECT * FROM ajrealty_customer WHERE customer_id='$cid'";
// $res = mysqli_query($conn, $sql_fetch_mngr);
// $count=mysqli_num_rows($res);
// if($count==0){
// echo "";
// }else {
// while($row = $res->fetch_assoc()){ 
// $mngr_id = $row['assigned_manager'];
// }
// }

$sql_fetch_mngr="SELECT * FROM assigned_manager WHERE customer_id='$cid' AND property_id='$pid'";
$res = mysqli_query($conn, $sql_fetch_mngr);
$count=mysqli_num_rows($res);
if($count==0){
echo "";
}else {
while($row = $res->fetch_assoc()){ 
$mngr_id = $row['assigned_staff_id'];
}
}

$sql_fetch_mngr2="SELECT * FROM ajrealty_staffs WHERE staff_id='$mngr_id'";
$res2 = mysqli_query($conn, $sql_fetch_mngr2);
$count2=mysqli_num_rows($res2);
if($count2==0){
echo "";
}else {
while($row2 = $res2->fetch_assoc()){ 
$mngr_name = $row2['staff_name'];
}
}

$sql_insert = "INSERT INTO `notification_status` (`customer_id`,`property_id`,`assigned_staff_name`,`assigned_staff_id`,`message`,`role`,`entry_date`,`status`,`remark_from`) VALUES ('$cid','$pid','$mngr_name',
'$mngr_id','$msg','manager','$date','0','propriator')";
$res_insert=mysqli_query($conn, $sql_insert);
   if($res_insert){

   	$remark='Property sold';

$sql_remark="INSERT INTO `ajrealty_remarks`( `customer_id`, `property_id`, `staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$cid','$pid','$staff_id','$staff_name','$remark','$date','$staff_role')";

$res_remark=mysqli_query($conn, $sql_remark);


$sql_mngr_up="UPDATE ajrealty_survey SET property_status='1' WHERE customer_id='$cid' AND property_id='$pid'";
$res_remark2=mysqli_query($conn, $sql_mngr_up);

           echo "<script>alert('Success');window.location='old_customer_view.php?c_id=$cid';</script>";
            }else{
          echo "<script>alert('Error');window.location='old_customer_view.php?c_id=$cid';</script>";
            }

?>