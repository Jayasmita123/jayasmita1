<?php
session_start();
unset($_SESSION['role']);
unset($_SESSION['staff_id']);
unset($_SESSION['staff_phone']);

session_destroy();
echo "<script type='text/javascript'>
location.href='../login.php';</script>";
?>