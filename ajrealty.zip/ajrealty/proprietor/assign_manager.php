<?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
  .modal {
  display:block;
  margin-top:2%;
}
.content_display{
margin-right:50%;
}
#cancel_button{
float: right;
}
</style>
</head>
<body>

<?php
include("Db_Conn.php");
$c_id=$_GET['c_id'];
$p_id=$_GET['p_id'];

$sql="SELECT * FROM  ajrealty_customer WHERE customer_id='$c_id'";
$res = mysqli_query($conn, $sql);
$count=mysqli_num_rows($res);
if($count==0){
echo "";
}else {
while($row = $res->fetch_assoc()){ 
$c_name=$row['customer_name'];
$c_phone=$row['customer_phone'];
$c_email=$row['customer_email'];
}
}
?>
<div id="myModal" class="modal show" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <a href="new_customer_view.php?c_id=<?php echo $c_id ?>" class="close" >&times;</a><br>
      </div>
          <center> <h4 class="modal-title"><u>Assign Manager</u></h4></center>
                  <form action="assign_manager_db.php" method="post">
              <input type="hidden" name="cid" value="<?php echo $c_id ?>">
              <input type="hidden" name="pid" value="<?php echo $p_id ?>">
      <div class="modal-body">
        <p><b>Customer name</b> : <?php echo $c_name ?></p>
        <p><b>Contact number</b> : <?php echo $c_phone ?></p>
        <br>

          <label for="assign">Assign manager to <?php echo $c_name ?></label>
          <select name="assigned_manager" >
            <option style="display:none;">--SELECT MANAGER--</option>
            <?php
$sql="SELECT * FROM  ajrealty_staffs WHERE staff_role='Manager'";
$res = mysqli_query($conn, $sql);
$count=mysqli_num_rows($res);
if($count==0){
echo "";
}else {
while($row = $res->fetch_assoc()){ 
$staff_name=$row['staff_name'];
$staff_id=$row['staff_id'];

echo"<option value='$staff_id'>$staff_name</option>";
}
}
            ?>
          </select>
<textarea name="message" placeholder="any message ???"></textarea>
      </div>
      <div class="modal-footer">
  <input type="submit" name="submit" class="button button1" value="Assign">
        <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
      </div>
    </form>

  </div>

  </div>
</div>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>

<!--validation-->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
  <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <style type="text/css">
    #address_information{
      display:none;
    }
        .has-error{
            color: crimson;
            border: none;
        }
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  text-align: left;
  padding-left: 2%;
  background-color: #f1f1f1;
  width: 85%;
}
.button {
  background-color: #05147d; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 2px;
  width:150px;
  height: 50px;
}
#details_table{
width:100%;
}
table, td, th {
  border: 1px solid black;
}
table {
  border-collapse: collapse;
  width: 100%;
}
td {
  height: 50px;
  vertical-align:center;
}
  </style>
</head>
<body>
  <?php include("nav.php"); ?>
<center><h2>Customer Details</h2></center><br>
<?php
include("Db_Conn.php");
$c_id=$_GET['c_id'];

// $update_status="UPDATE notification_status SET status='1' WHERE customer_id='$c_id' AND role='propriator'";
// $res_status=mysqli_query($conn,$update_status);



$sel = "SELECT * FROM  ajrealty_customer WHERE customer_id='$c_id'";
$res = mysqli_query($conn, $sel);
    while($fetch = mysqli_fetch_array($res)){
$c_name = $fetch['customer_name'];
$c_phone = $fetch['customer_phone'];
$c_district = $fetch['customer_district'];
$c_state = $fetch['customer_state'];
$c_gender = $fetch['gender'];
$c_email= $fetch['customer_email'];
$c_occupation = $fetch['customer_occupation'];
$c_addr1= $fetch['customer_address_line1'];
$c_addr2 = $fetch['customer_address_line2'];
$c_addr3 = $fetch['customer_landmark'];
$c_addr4 = $fetch['customer_city'];
$c_addr5 = $fetch['customer_district'];
$c_addr7 = $fetch['customer_country'];
$c_addrpin = $fetch['customer_pincode'];
$c_state = $fetch['customer_state'];
$c_contactalt = $fetch['alternative_phone'];
$c_contactres = $fetch['residence_phone'];
$c_contactoff = $fetch['office_phone'];


$sql1="SELECT * FROM ajrealty_survey WHERE customer_id='$c_id'";
$res1= mysqli_query($conn, $sql1);
    while($fetch1 = mysqli_fetch_array($res1)){
$c_property=$fetch1['property'];
$c_type=$fetch1['type'];
$c_property_type=$fetch1['property_type'];
$c_property_id=$fetch1['property_id'];
$c_source=$fetch1['source'];
$c_inspected=$fetch1['inspected'];
$c_listed=$fetch1['listed'];
$c_hrr_board=$fetch1['hrr_board'];
$c_keys_collected=$fetch1['keys_collected'];
$c_web_hosting=$fetch1['website_hosting'];
$c_entry_date=$fetch1['entry_date'];
}

$sql2="SELECT * FROM  ajrealty_survey_table2 WHERE property_id='$c_property_id'";
$res2= mysqli_query($conn, $sql2);
    while($fetch2 = mysqli_fetch_array($res2)){
$c_ins_personname=$fetch2['inspection_person_name'];
$c_ins_personctc=$fetch2['inspection_person_phone'];
$c_ins_personemail=$fetch2['inspection_person_email'];
$c_building_name=$fetch2['building_name'];
$c_builders_name=$fetch2['builders_name'];    
$c_architect_name=$fetch2['architect_name'];
$c_building_age=$fetch2['age_of_building'];
$c_built_area=$fetch2['built_area'];
$c_florrs_num=$fetch2['floors_num'];
$c_bedrooms=$fetch2['bedrooms'];
$c_rooms=$fetch2['rooms'];
$c_bathrooms=$fetch2['bathrooms'];
$c_flooring=$fetch2['flooring'];
$c_generator=$fetch2['generator'];
$c_furnished=$fetch2['furnished'];
$c_pfacility=$fetch2['power_supply'];
$c_wfacility=$fetch2['water_facility'];
$c_elevators=$fetch2['elevators'];
$c_garden=$fetch2['garden/terrace'];
$c_carpark=$fetch2['car_park'];
$c_ammenties=$fetch2['amenties'];
$c_totalflat=$fetch2['total_flats'];
$c_price=$fetch2['price'];
$c_land_rate=$fetch2['land_sqft_rate'];
$c_land_area=$fetch2['land_area'];
$c_entry_date=$fetch2['entry_date'];
$c_remarks=$fetch2['remarks'];
}
?>
<center><div class="column">
    <div class="card">
<table id="details_table">
<tr><td>Customer name : <?php echo $c_name ?></td>
<td>Contact number : <?php echo "$c_phone, $c_contactalt" ?></td>
<td>Residential number : <?php echo $c_contactres ?></td></tr>

<tr><td>Office number : <?php echo $c_contactoff ?></td>
<td>Email-id : <?php echo $c_email ?></td>
<td>Address : <?php echo "$c_addr1 $c_addr2 $c_addr3 $c_addr4, $c_addr5, $c_state, $c_addr7 - $c_addrpin"; ?></td></tr>

<tr><td>Property: <?php echo $c_property ?></td>
<td>Mode of Buisness : <?php echo $c_type ?></td>
<td>Property type : <?php echo $c_property_type ?></td></tr>

<tr><td>Source : <?php echo $c_source ?></td>
<td>Inspected : <?php echo $c_inspected ?></td>
<td>Listed : <?php echo $c_listed ?></td></tr>

<tr><td>hrr board : <?php echo $c_hrr_board ?></td>
<td>keys collected : <?php echo $c_keys_collected ?></td>
<td>Web hosting : <?php echo $c_web_hosting ?></td></tr>

<tr><td>Inspection Person name : <?php echo $c_ins_personname ?></td>
<td>Inspection person contact number : <?php echo $c_ins_personctc ?></td>
<td>Inspection person email : <?php echo $c_ins_personemail ?></td></tr>

<tr><td>Building name : <?php echo $c_building_name ?></td>
<td>Builder name : <?php echo $c_builders_name ?></td>
<td>Architect name : <?php echo $c_architect_name ?></td></tr>

<tr><td>Building age: <?php echo $c_building_age ?></td>
<td>Built area: <?php echo $c_built_area ?></td>
<td>Number of floors: <?php echo $c_florrs_num ?></td></tr>

<tr><td>Bedroom : <?php echo $c_bedrooms ?></td>
<td>Rooms : <?php echo $c_rooms ?></td>
<td>Bathrooms : <?php echo $c_bathrooms ?></td></tr>

<tr><td>Flooring : <?php echo $c_flooring ?></td>
<td>Generator : <?php echo $c_generator ?></td>
<td>Furnished : <?php echo $c_furnished ?></td></tr>

<tr><td>Power facility : <?php echo $c_pfacility ?></td>
<td>Water facility : <?php echo $c_wfacility ?></td>
<td>Elevators : <?php echo $c_elevators ?></td></tr>

<tr><td>Gardening : <?php echo $c_garden ?></td>
<td>Car Parking : <?php echo $c_carpark ?></td>
<td>Amenties : <?php echo $c_ammenties ?></td></tr>

<tr><td>Total flat : <?php echo $c_totalflat ?></td>
<td>Price : <?php echo $c_price ?></td>
<td>Land rate : <?php echo $c_land_rate ?></td></tr>

<tr>
<td>Land area : <?php echo $c_land_area ?></td>
<td>Remarks : <?php echo $c_remarks ?></td></tr>

</table>
<center><a href="index.php"><button class="button button1">Back</button></a>
   <a href="assign_manager.php?c_id=<?php echo $c_id ?>&p_id=<?php echo $c_property_id ?>"><button class="button button1">Assign Manager</button></a>
  <a href="add_remark.php?c_id=<?php echo $c_id ?>&p_id=<?php echo $c_property_id ?>"><button class="button button1">Add Remark</button></a></center>
    </div>
  </div></center>
<?php
}
?>
<div style="margin-top:5%;">
<?php include("footer.php"); ?>
</div>
</body>
</html>

