<?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}

?><!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>AJREALTY</title>

    <!-- Icons font CSS-->
    <link href="../fonts/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
    
    <!-- Main CSS-->
    <link href="../css/form.css" rel="stylesheet" media="all">
    <!--country, state, district select dropdown-->
    <script type="text/JavaScript" src="../js/country_state_district_dropdown.js"></script>

<!--validation-->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
	<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<style type="text/css">
#address_information{
display:none;
}
.has-error{
color: crimson;
border: none;
}
#part1{
    float: left;
    width:33.33%;
}
#part2{
    float: left;
    width:33.33%;
}
#part3{
    float: left;
    width:33.33%;
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
  margin:1%;
  height: 200px;
}
.tag{
float:left;
margin-left:-5%;
    }
.customer_name{

}
.page_footer{
margin-top:10%;
}
</style>
</head>
<body>
<?php include("nav.php"); ?>
<div id="part1">
<center><h2>New customer</h2></center>
<?php
include("Db_Conn.php");
$sql1="SELECT * FROM notification_status WHERE role='propriator' AND status='0' AND customer='new'";
$res1 = mysqli_query($conn, $sql1);
while($fetch1 = mysqli_fetch_array($res1)){
$c_id1 = $fetch1['customer_id'];  

$sel = "SELECT * FROM  ajrealty_customer WHERE customer_id='$c_id1'";
$res = mysqli_query($conn, $sel);
while($fetch = mysqli_fetch_array($res)){
$c_name = $fetch['customer_name'];
$c_phone = $fetch['customer_phone'];
$c_district = $fetch['customer_district'];
$c_state = $fetch['customer_state'];
$c_id=$fetch['customer_id'];
?>
<a href="new_customer_view.php?c_id=<?php echo $c_id ?>" style="text-decoration:none;"><div class="column">
    <div class="card">
    <div class="w3-container">
  <span class="w3-tag w3-padding w3-red tag" style="transform:rotate(-10deg)">
    New
</span>
</div>
  <h3 class="customer_name"><u><?php echo $c_name ?></u></h3>
      <p><u>Contact number  </u> : <?php echo $c_phone ?></p>
      <p><?php echo "$c_district, $c_state"; ?></p>
    </div>
  </div></a>
<?php
}
}
?>
</div>
<div id="part2"><center><h2>Old customer</h2></center>
<?php
$sql12="SELECT * FROM notification_status WHERE role='propriator' AND status='0' AND customer='old'";
$res12 = mysqli_query($conn, $sql12);
while($fetch12 = mysqli_fetch_array($res12)){
$c_id12 = $fetch12['customer_id'];  

$sel2 = "SELECT * FROM  ajrealty_customer WHERE customer_id='$c_id12'";
$res2 = mysqli_query($conn, $sel2);
while($fetch2 = mysqli_fetch_array($res2)){
$c_name2 = $fetch2['customer_name'];
$c_phone2 = $fetch2['customer_phone'];
$c_district2 = $fetch2['customer_district'];
$c_state2 = $fetch2['customer_state'];
$c_id2=$fetch2['customer_id'];
?>
<a href="old_customer_view.php?c_id=<?php echo $c_id2 ?>" style="text-decoration:none;"><div class="column">
    <div class="card">
    <div class="w3-container">
  <span class="w3-tag w3-padding w3-red tag" style="transform:rotate(-10deg)">
    Re-entry
</span>
</div>
  <h3 class="customer_name"><u><?php echo $c_name2 ?></u></h3>
      <p><u>Contact number</u> : <?php echo $c_phone2 ?></p>
      <p><?php echo "$c_district2, $c_state2"; ?></p>
    </div>
  </div></a>
<?php
}
}
?>
</div>
<div id="part3"><center><h2>call center</h2></center>
<?php
    $sql13="SELECT * FROM `notification_status` WHERE `role`='propriator' AND `status`='0' AND `remark_from`='callcenter'";
    $res13 = mysqli_query($conn, $sql13);
    while($fetch_callcenter = mysqli_fetch_array($res13)){
    $c_id_callcenter = $fetch_callcenter['customer_id']; 
    $c_message_callcenter = $fetch_callcenter['message'];  

    $sel_callcenter ="SELECT * FROM `ajrealty_customer` WHERE `customer_id`='$c_id_callcenter'";
    $res_callcenter = mysqli_query($conn, $sel_callcenter);
    $fetch_callcenter = mysqli_fetch_array($res_callcenter);
    $c_name_callcenter = $fetch_callcenter['customer_name'];
    $c_phone_callcenter  = $fetch_callcenter['customer_phone'];
    $c_district_callcenter  = $fetch_callcenter['customer_district'];
    $c_state_callcenter  = $fetch_callcenter['customer_state'];
 ?>

<a href="callcenter_remark_view.php?c_id=<?php echo $c_id_callcenter;?>" style="text-decoration: none;"><div class="column">
    <div class="card">
    <div class="w3-container">
  <span class="w3-tag w3-padding w3-red tag" style="transform:rotate(-10deg)">
    New
</span>
</div>
<h3 class="customer_name"><u><?php echo $c_name_callcenter ?></u></h3> 
      <p><u>Contact number</u> : <?php echo $c_phone_callcenter ?></p>
      <p><?php echo $c_district_callcenter.",". $c_state_callcenter; ?></p>
      <p><u>Message </u> :  <?php echo $c_message_callcenter ?></p>
</div>
  </div></a>
<?php
}
?>
</div>
<div class="page_footer" style="margin-top:10%;">
<?php include("footer.php"); ?>
</div>
</body>
</html>
