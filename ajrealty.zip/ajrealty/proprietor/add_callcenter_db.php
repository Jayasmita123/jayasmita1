<?php
session_start();
if(!isset($_SESSION['staff_id'])){
    header('Location: ../login.php');
}
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/4.0.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/4.0.6/sweetalert2.min.css">
</head>
</html>
<?php
require_once("Db_Conn.php");
$staff_id_login=$_SESSION['staff_id'];

$p_id=$_POST['add'];
$staff_id=$_POST['call_center'];

date_default_timezone_set("Asia/Kolkata");

$date=date("Y-m-d") ;
$date2=date("Y-m-d H:i:s");


$sql_staff_name= "SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id_login'";
$res_staff_name = mysqli_query($conn, $sql_staff_name);
$count2=mysqli_num_rows($res_staff_name);
if($count2==0){
echo "";
}else {
while($row_staff_name = $res_staff_name->fetch_assoc()){ 
$staff_name_login=$row_staff_name['staff_name'];
}
}
$dbCheckbox = "";
if(isset($_POST['add'])){
  $dbCheckbox = implode(',',$_POST['add']);
}
// echo "<script>alert('$dbCheckbox');</script>";
for($i=0;$i<count($p_id);$i++){
$pid=$p_id[$i];

  $sql3="SELECT * FROM ajrealty_survey WHERE property_id='$pid'";
    $result3=mysqli_query($conn,$sql3);
while($user3=mysqli_fetch_assoc($result3)){
$cid=$user3['customer_id'];
}
  $sql2="SELECT * FROM ajrealty_staffs WHERE staff_id='$staff_id'";
    $result=mysqli_query($conn,$sql2);
while($user=mysqli_fetch_assoc($result)){
$staff_name=$user['staff_name'];

$sql="INSERT INTO ajrealty_callcenter (staff_id,staff_name,customer_id,property_id,date) VALUES ('$staff_id','$staff_name','$cid','$pid','$date')";
$res=mysqli_query($conn,$sql);

$remarks=$staff_name_login. '(Proprietor) assigned this customer to call center';
$sql_remark="INSERT INTO `ajrealty_remarks`( `customer_id`,`property_id`,`role`,`staff_id`, `staff_name`, `remarks`, `entry_date`) VALUES ('$cid','$pid','Propriator',$staff_id_login','$staff_name_login','$remarks','$date2')";
$res_remark=mysqli_query($conn, $sql_remark);


$msg=$staff_name_login.'(Proprietor) assigned new customers to ' .$staff_name. '(call center)';
$sql_insert = "INSERT INTO `notification_status` (`customer_id`,`property_id`,`assigned_staff_name`,`assigned_staff_id`,`message`,`role`,`entry_date`,`status`,`remark_from`) VALUES ('$cid','$pid','$staff_name','$staff_id','$msg','call center','$date2','0','propriator')";
$res_insert=mysqli_query($conn, $sql_insert);
}
}
if($res){
  echo"<script>alert('assigned to $staff_name successfully');
  window.location='addcustomer_callcenter.php';</script>";
}
else{
   echo"<script>alert('Retry..');
  window.location='addcustomer_callcenter.php';</script>"; 
}
?>